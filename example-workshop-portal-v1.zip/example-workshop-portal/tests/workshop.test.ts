import assert from "node:assert/strict";
import test from "node:test";

import { demoStart, isOverdue, operatorId, requesterId, slotMs } from "../src/domain";
import type { Reservation, ReservationAction, Resource, Workshop } from "../src/domain";
import { createMockApi } from "../src/mock/api";

type Api = ReturnType<typeof createMockApi>;
const vrKitId = "example_resource_01";
const secondRequesterId = "example_requester_02";

function request(api: Api, path: string, actor = operatorId, method = "GET", body?: unknown) {
  return api(new Request(`http://example_mock_api.invalid/api/${path}`, {
    method,
    headers: { "x-example-actor": actor, "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  }));
}

async function read<T>(pending: Promise<Response>, expectedStatus = 200): Promise<T> {
  const response = await pending;
  assert.equal(response.status, expectedStatus);
  return await response.json() as T;
}

function snapshot(api: Api) {
  return read<Workshop>(request(api, "example_workshop"));
}

function book(api: Api, startSlot: number, endSlot: number, actor = requesterId) {
  return request(api, "example_reservations", actor, "POST", {
    example_resource_id: vrKitId,
    example_start: demoStart + startSlot * slotMs,
    example_end: demoStart + endSlot * slotMs,
    example_note: "example_Headset trial",
  });
}

function action(api: Api, id: string, value: ReservationAction, actor = operatorId) {
  return request(api, `example_reservations/${id}`, actor, "PATCH", { example_action: value });
}

function advance(api: Api) {
  return read<{ example_now: number }>(request(api, "example_clock", operatorId, "POST"));
}

test("the prefixed demo has 14 resources, 8 identities, and 40 isolated reservations", async () => {
  const api = createMockApi();
  const seed = await snapshot(api);
  assert.equal(seed.example_resources.length, 14);
  assert.equal(seed.example_users.length, 8);
  assert.equal(seed.example_reservations.length, 40);
  assert.equal(seed.example_now, demoStart);

  function verifyPrefixes(value: unknown): void {
    if (typeof value === "string") assert.match(value, /^example_/);
    if (Array.isArray(value)) value.forEach(verifyPrefixes);
    else if (value && typeof value === "object") {
      for (const [key, child] of Object.entries(value)) {
        assert.match(key, /^example_/);
        verifyPrefixes(child);
      }
    }
  }

  verifyPrefixes(seed);
  const item = await read<Resource>(request(api, "example_resources", operatorId, "POST", {
    example_name: "example_Review Kit",
    example_category: "example_Immersive equipment",
    example_location: "example_XR Studio",
    example_description: "example_Demo item",
  }), 201);
  assert.ok((await snapshot(api)).example_resources.some(resource => resource.example_id === item.example_id));
  assert.deepEqual(await snapshot(createMockApi()), seed);
});

test("overlapping requests can wait, and approvals allow only nonoverlapping slots", async () => {
  const api = createMockApi();
  const first = await read<Reservation>(book(api, 1, 2), 201);
  const overlapping = await read<Reservation>(book(api, 1, 3, secondRequesterId), 201);
  assert.equal(first.example_status, "example_requested");
  assert.equal(overlapping.example_status, "example_requested");

  await read<Reservation>(action(api, first.example_id, "example_approve"));
  assert.equal((await action(api, overlapping.example_id, "example_approve")).status, 409);
  assert.equal((await book(api, 1, 2)).status, 409);

  const adjacent = await read<Reservation>(book(api, 2, 3), 201);
  const approved = await read<Reservation>(action(api, adjacent.example_id, "example_approve"));
  assert.equal(approved.example_status, "example_approved");
  const unchanged = (await snapshot(api)).example_reservations.find(item => item.example_id === overlapping.example_id);
  assert.equal(unchanged?.example_status, "example_requested");
});

test("the API checks roles, ownership, and reservation windows before changing data", async () => {
  const api = createMockApi();
  assert.equal((await book(api, 2, 2)).status, 400);
  assert.equal((await book(api, -1, 1)).status, 400);
  assert.equal((await book(api, 1, 3, operatorId)).status, 403);
  assert.equal((await request(api, "example_clock", requesterId, "POST")).status, 403);
  const reservation = await read<Reservation>(book(api, 1, 3), 201);
  assert.equal((await action(api, reservation.example_id, "example_approve", requesterId)).status, 403);
  assert.equal((await action(api, reservation.example_id, "example_cancel", secondRequesterId)).status, 403);
  const cancelled = await read<Reservation>(action(api, reservation.example_id, "example_cancel", requesterId));
  assert.equal(cancelled.example_status, "example_cancelled");
  assert.equal((await snapshot(api)).example_now, demoStart);
});

test("checkout opens at the start, becomes overdue at the end, and records a return", async () => {
  const api = createMockApi();
  const reservation = await read<Reservation>(book(api, 1, 3), 201);
  await read<Reservation>(action(api, reservation.example_id, "example_approve"));
  assert.equal((await action(api, reservation.example_id, "example_checkout")).status, 409);
  const { example_now: start } = await advance(api);
  assert.equal(start, reservation.example_start);
  const checkedOut = await read<Reservation>(action(api, reservation.example_id, "example_checkout"));
  assert.equal(checkedOut.example_status, "example_checked_out");
  assert.equal(checkedOut.example_checked_out_at, start);
  assert.equal(isOverdue(checkedOut, start), false);

  await advance(api);
  const { example_now: end } = await advance(api);
  assert.equal(end, reservation.example_end);
  assert.equal(isOverdue(checkedOut, end), true);
  const returned = await read<Reservation>(action(api, reservation.example_id, "example_return"));
  assert.equal(returned.example_status, "example_returned");
  assert.equal(returned.example_returned_at, end);
  assert.equal(isOverdue(returned, end), false);
});

test("an overdue checkout keeps custody until return without cancelling the next booking", async () => {
  const api = createMockApi();
  const { example_reservations, example_now } = await snapshot(api);
  const overdue = example_reservations.find(item => item.example_resource_id === "example_resource_02" && isOverdue(item, example_now));
  assert.ok(overdue);
  const next = example_reservations.find(item => item.example_resource_id === overdue.example_resource_id
    && item.example_status === "example_approved" && item.example_start === demoStart + slotMs);
  assert.ok(next);

  await advance(api);
  assert.equal((await action(api, next.example_id, "example_checkout")).status, 409);
  const pending = (await snapshot(api)).example_reservations.find(item => item.example_id === next.example_id);
  assert.equal(pending?.example_status, "example_approved");

  await read<Reservation>(action(api, overdue.example_id, "example_return"));
  const checkedOut = await read<Reservation>(action(api, next.example_id, "example_checkout"));
  assert.equal(checkedOut.example_status, "example_checked_out");
});
