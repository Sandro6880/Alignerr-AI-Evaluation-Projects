import assert from "node:assert/strict";
import { once } from "node:events";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { createServer } from "vite";

const note = "example_Browser smoke booking";
const server = await createServer({
  root: fileURLToPath(new URL("../", import.meta.url)),
  server: { hmr: false },
  logLevel: "warn",
});
let browser;

try {
  assert.ok(server.httpServer, "The mock API needs an HTTP server.");
  const listening = once(server.httpServer, "listening");
  server.httpServer.listen(0, "127.0.0.1");
  await listening;
  const address = server.httpServer.address();
  assert.ok(address && typeof address === "object");

  browser = await chromium.launch({ executablePath: process.env.EXAMPLE_CHROMIUM_EXECUTABLE || undefined });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  page.setDefaultTimeout(10_000);
  await page.goto(`http://127.0.0.1:${address.port}/`);

  const button = (name) => page.getByRole("button", { name, exact: true });
  const select = (name) => page.getByRole("combobox", { name, exact: true });
  const card = page.getByRole("article").filter({ hasText: note });
  const action = (name) => card.getByRole("button", { name, exact: true });
  const status = (text) => page.getByRole("status").getByText(text, { exact: true }).waitFor();

  await button("Booking calendar").click();
  await select("Equipment").selectOption("example_resource_01");
  await select("Start time").selectOption({ label: "09:30" });
  await select("End time").selectOption({ label: "10:30" });
  await page.getByRole("textbox", { name: "Booking note", exact: true }).fill(note);
  await button("Request booking").click();
  await status("Booking requested. It is ready for operator review.");

  await select("Demo identity").selectOption("example_operator_01");
  await button("Reservations").click();
  await action("Approve").click();
  await card.getByText("Approved", { exact: true }).waitFor();
  await button("Checkout desk").click();
  await action("Check out").waitFor();
  assert.equal(await action("Check out").isEnabled(), false, "Early checkout must be blocked.");

  await button("Advance 30 minutes").click();
  await action("Check out").click();
  await status("Equipment checked out.");
  await action("Record return").click();
  await status("Return recorded.");
  await button("Reservations").click();
  await card.getByText("Returned", { exact: true }).waitFor();

  await page.reload();
  await page.getByRole("heading", { name: "Workshop overview", exact: true }).waitFor();
  assert.match(await page.locator(".clock-value").innerText(), /09:00/);
  await button("Reservations").click();
  assert.equal(await card.count(), 0, "Refreshing must restore the seed reservations.");

  await page.setViewportSize({ width: 390, height: 844 });
  await button("Booking calendar").click();
  await button("Request booking").waitFor();
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  console.log("Workshop portal browser smoke test passed.");
} finally {
  try {
    await browser?.close();
  } finally {
    await server.close();
  }
}
