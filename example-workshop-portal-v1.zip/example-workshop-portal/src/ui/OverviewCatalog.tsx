import { useState, type FormEvent } from "react";

import { post } from "../api-client";
import { dateKey, formatDateTime, formatTime, isOverdue, type Reservation, type Resource } from "../domain";
import type { ViewProps } from "./BookingViews";

const displayStatus = {
  example_requested: "Requested",
  example_approved: "Approved",
  example_declined: "Declined",
  example_cancelled: "Cancelled",
  example_checked_out: "Checked out",
  example_returned: "Returned",
};

function StatusBadge({ reservation, now }: { reservation: Reservation; now: number }) {
  const overdue = isOverdue(reservation, now);
  const tone = overdue ? "overdue" : reservation.example_status.slice("example_".length);
  return <span className={`badge tone-${tone}`}>{overdue ? "Overdue" : displayStatus[reservation.example_status]}</span>;
}

export function Overview({ workshop, actor, onNavigate }: ViewProps) {
  const { example_now: now, example_reservations: reservations, example_resources: resources, example_users: users } = workshop;
  const operator = actor.example_role === "example_operator";
  const scope = operator ? reservations : reservations.filter((item) => item.example_requester_id === actor.example_id);
  const day = dateKey(now);
  const today = scope.filter((item) =>
    item.example_status !== "example_cancelled" && item.example_status !== "example_declined"
      && dateKey(item.example_start) <= day && dateKey(item.example_end - 1) >= day);
  const pending = scope.filter((item) => item.example_status === "example_requested");
  const active = scope.filter((item) => item.example_status === "example_checked_out");
  const overdue = active.filter((item) => isOverdue(item, now));
  const attention = [...overdue, ...pending].slice(0, 5);
  const upcoming = today
    .filter((item) => item.example_end > now && item.example_status === "example_approved")
    .sort((left, right) => left.example_start - right.example_start)
    .slice(0, 5);
  const metrics = [
    { label: "Today's bookings", value: today.length, detail: "Reservations on this date" },
    { label: "Pending requests", value: pending.length, detail: "Awaiting approval" },
    { label: "Active checkouts", value: active.length, detail: "Equipment currently held" },
    { label: "Overdue returns", value: overdue.length, detail: "Checked out past the due time" },
  ];

  function list(items: Reservation[], empty: string) {
    if (!items.length) return <p className="empty-state">{empty}</p>;
    return (
      <ul className="record-list">
        {items.map((item) => {
          const resource = resources.find((candidate) => candidate.example_id === item.example_resource_id);
          const requester = users.find((candidate) => candidate.example_id === item.example_requester_id);
          const checkedOut = item.example_status === "example_checked_out";
          return (
            <li className="record-card" key={item.example_id}>
              <div>
                <strong>{resource?.example_name ?? item.example_resource_id}</strong>
                <p className="record-meta">
                  {checkedOut ? `Due ${formatDateTime(item.example_end)}` : formatDateTime(item.example_start)}
                  {" · "}{requester?.example_name ?? item.example_requester_id}
                </p>
                {item.example_note && <p className="record-meta">{item.example_note}</p>}
              </div>
              <div className="record-actions">
                <StatusBadge reservation={item} now={now} />
                <button className="button button-secondary" type="button"
                  onClick={() => onNavigate(checkedOut && operator ? "desk" : "reservations", item.example_resource_id)}>
                  {checkedOut && operator ? "Open checkout desk" : "View reservation"}
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    );
  }

  return (
    <>
      <header className="page-heading">
        <div>
          <p className="eyebrow">{operator ? "Operator workspace" : "Requester workspace"}</p>
          <h1>Workshop overview</h1>
          <p className="page-description">{operator ? "Review bookings, pending decisions, and equipment custody." : "Find equipment and follow your requests and checkouts."}</p>
        </div>
        <div className="page-actions">
          <button className="button button-primary" type="button" onClick={() => onNavigate("calendar")}>Open booking calendar</button>
        </div>
      </header>
      <section className="stats-grid" aria-label="Workshop metrics">
        {metrics.map(({ label, value, detail }) => (
          <article className="stat-card" key={label}>
            <h2 className="stat-label">{label}</h2>
            <p className="stat-value">{value}</p>
            <p className="stat-detail">{detail}</p>
          </article>
        ))}
      </section>
      <div className="dashboard-grid">
        <section className="panel" aria-labelledby="example_attention">
          <header className="panel-heading">
            <div><p className="eyebrow">Workshop activity</p><h2 id="example_attention">Needs attention</h2></div>
            <span className="attention-count">{overdue.length + pending.length}</span>
          </header>
          <div className="panel-body">{list(attention, "There are no pending requests or overdue returns in this view.")}</div>
        </section>
        <section className="panel" aria-labelledby="example_upcoming">
          <header className="panel-heading"><div><p className="eyebrow">Calendar</p><h2 id="example_upcoming">Today’s confirmed bookings</h2></div></header>
          <div className="panel-body">{list(upcoming, "There are no confirmed bookings left today in this view.")}</div>
        </section>
      </div>
    </>
  );
}

export function Catalog({ workshop, actor, resourceId, onResource, onChanged, onNavigate }: ViewProps) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const { example_resources: resources, example_reservations: reservations, example_now: now } = workshop;
  const operator = actor.example_role === "example_operator";
  const categories = [...new Set(resources.map((item) => item.example_category))].sort();
  const locations = [...new Set(resources.map((item) => item.example_location))].sort();
  const needle = query.trim().toLowerCase();
  const visible = resources.filter((item) =>
    (!category || item.example_category === category) && (!location || item.example_location === location)
      && [item.example_name, item.example_description, item.example_id].some((value) => value.toLowerCase().includes(needle)));
  const selected = visible.find((item) => item.example_id === resourceId) ?? visible[0];
  const forItem = reservations.filter((item) => item.example_resource_id === selected?.example_id);
  const currentCheckout = forItem.find((item) => item.example_status === "example_checked_out");
  const confirmed = forItem
    .filter((item) => item.example_status === "example_approved" && item.example_end > now)
    .sort((left, right) => left.example_start - right.example_start);
  const currentBooking = confirmed.find((item) => item.example_start <= now);
  const nextBooking = confirmed.find((item) => item.example_start > now);

  async function addEquipment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const item = await post<Resource>("example_resources", actor.example_id, {
        example_name: data.get("example_name"),
        example_category: data.get("example_category"),
        example_location: data.get("example_location"),
        example_description: data.get("example_description"),
      });
      await onChanged();
      setQuery("");
      setCategory("");
      setLocation("");
      onResource(item.example_id);
      setMessage(`Added ${item.example_name}.`);
      setAdding(false);
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : "Could not add equipment.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <header className="page-heading">
        <div>
          <p className="eyebrow">Workshop inventory</p>
          <h1>Equipment catalog</h1>
          <p className="page-description">Browse individual items by category or location and check their schedules.</p>
        </div>
        {operator && (
          <div className="page-actions">
            <button className="button button-primary" type="button" onClick={() => { setAdding(!adding); setError(""); }}>
              {adding ? "Close equipment form" : "Add equipment"}
            </button>
          </div>
        )}
      </header>
      {message && <p className="notice notice-success" role="status">{message}</p>}
      {operator && adding && (
        <section className="panel" aria-labelledby="example_add_equipment">
          <header className="panel-heading"><h2 id="example_add_equipment">Add demo equipment</h2></header>
          <form className="panel-body" onSubmit={addEquipment}>
            {error && <p className="notice notice-error" role="alert">{error}</p>}
            <div className="form-grid">
              <label className="field">Equipment name<input name="example_name" required placeholder="example_Inspection Camera" /></label>
              <label className="field">Category<input name="example_category" required list="example_categories" placeholder="example_Cameras" /></label>
              <label className="field">Location<input name="example_location" required list="example_locations" placeholder="example_Imaging Room" /></label>
              <label className="field">Description<textarea name="example_description" rows={2} required placeholder="example_Inspection kit with a table mount." /></label>
              <datalist id="example_categories">{categories.map((item) => <option key={item} value={item} />)}</datalist>
              <datalist id="example_locations">{locations.map((item) => <option key={item} value={item} />)}</datalist>
            </div>
            <div className="form-actions">
              <button className="button button-primary" disabled={saving} type="submit">{saving ? "Creating…" : "Create equipment"}</button>
            </div>
          </form>
        </section>
      )}
      <section className="panel" aria-label="Equipment filters">
        <div className="panel-body filters">
          <label className="field">Search equipment<input name="example_query" type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Name, description, or ID" /></label>
          <label className="field">Category<select name="example_category_filter" value={category} onChange={(event) => setCategory(event.target.value)}>
            <option value="">All categories</option>
            {categories.map((item) => <option key={item} value={item}>{item}</option>)}
          </select></label>
          <label className="field">Location<select name="example_location_filter" value={location} onChange={(event) => setLocation(event.target.value)}>
            <option value="">All locations</option>
            {locations.map((item) => <option key={item} value={item}>{item}</option>)}
          </select></label>
        </div>
      </section>
      <div className="catalog-layout">
        <section className="panel" aria-labelledby="example_equipment_list">
          <header className="panel-heading">
            <h2 id="example_equipment_list">Equipment</h2>
            <span className="filter-result">{visible.length} of {resources.length} items</span>
          </header>
          <div className="panel-body">
            {visible.length ? (
              <ul className="catalog-list">
                {visible.map((item) => (
                  <li key={item.example_id}>
                    <button type="button" className={`catalog-list-item ${selected?.example_id === item.example_id ? "is-active" : ""}`}
                      aria-pressed={selected?.example_id === item.example_id} onClick={() => onResource(item.example_id)}>
                      <strong>{item.example_name}</strong><span className="record-meta">{item.example_category} · {item.example_location}</span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : <p className="empty-state">No equipment matches these filters.</p>}
          </div>
        </section>
        <section className="panel catalog-detail" aria-labelledby="example_equipment_details">
          <header className="panel-heading"><h2 id="example_equipment_details">Equipment details</h2></header>
          <div className="panel-body">
            {selected ? (
              <>
                <h3>{selected.example_name}</h3>
                <p className="page-description">{selected.example_description}</p>
                <dl className="catalog-facts">
                  <div><dt>Category</dt><dd>{selected.example_category}</dd></div>
                  <div><dt>Location</dt><dd>{selected.example_location}</dd></div>
                  <div><dt>Current status</dt><dd>
                    {currentCheckout ? <StatusBadge reservation={currentCheckout} now={now} />
                      : currentBooking ? <span className="badge tone-approved">Reserved now</span> : <span className="badge tone-returned">Available now</span>}
                  </dd></div>
                  <div><dt>Next confirmed booking</dt><dd>
                    {nextBooking ? `${formatDateTime(nextBooking.example_start)} to ${formatTime(nextBooking.example_end)}` : "None scheduled"}
                  </dd></div>
                </dl>
                <button className="button button-primary" type="button" onClick={() => onNavigate("calendar", selected.example_id)}>View schedule</button>
              </>
            ) : <p className="empty-state">Select an item to view its details and schedule.</p>}
          </div>
        </section>
      </div>
    </>
  );
}
