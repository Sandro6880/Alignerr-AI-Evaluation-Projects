import { useRef, useState, type FormEvent, type ReactNode } from "react";
import { patch, post } from "../api-client";
import {
  dateKey, formatDateTime, formatDay, formatTime, isOverdue, slotMs, workshopTimeZone,
  type Page, type Reservation, type ReservationAction, type ReservationStatus,
  type Resource, type User, type Workshop,
} from "../domain";

export type ViewProps = {
  workshop: Workshop;
  actor: User;
  resourceId: string;
  onResource: (id: string) => void;
  onChanged: () => Promise<void>;
  onNavigate: (page: Page, resourceId?: string) => void;
};

const statusLabels: Record<ReservationStatus, string> = {
  example_requested: "Requested",
  example_approved: "Approved",
  example_declined: "Declined",
  example_cancelled: "Cancelled",
  example_checked_out: "Checked out",
  example_returned: "Returned",
};

const actionMessages: Record<ReservationAction, string> = {
  example_approve: "Booking approved.",
  example_decline: "Booking declined.",
  example_cancel: "Booking cancelled.",
  example_checkout: "Equipment checked out.",
  example_return: "Return recorded.",
};

const offsetFormat = new Intl.DateTimeFormat("en-GB", {
  timeZone: workshopTimeZone, timeZoneName: "shortOffset", hour: "2-digit",
});
const dayMs = 24 * 60 * 60 * 1000;

function workshopTime(day: string, hour: number) {
  const wallTime = Date.parse(`${day}T${String(hour).padStart(2, "0")}:00:00Z`);
  const offsetName = offsetFormat.formatToParts(wallTime).find((part) => part.type === "timeZoneName")?.value;
  const match = offsetName?.match(/^GMT([+-])(\d{1,2})(?::(\d{2}))?$/);
  if (!match) return wallTime;
  const minutes = Number(match[2]) * 60 + Number(match[3] ?? 0);
  return wallTime - (match[1] === "+" ? 1 : -1) * minutes * 60_000;
}

function shiftDay(day: string, amount: number) {
  const noon = Date.parse(`${day}T12:00:00Z`);
  return dateKey(noon + amount * dayMs);
}

function timeRange(reservation: Reservation) {
  const start = reservation.example_start;
  const end = reservation.example_end;
  return dateKey(start) === dateKey(end)
    ? `${formatTime(start)} to ${formatTime(end)}`
    : `${formatDateTime(start)} to ${formatDateTime(end)}`;
}

function statusBadge(status: ReservationStatus) {
  return <span className={`badge tone-${status.slice("example_".length)}`}>{statusLabels[status]}</span>;
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="field"><span>{label}</span>{children}</label>;
}

function EquipmentSelect({
  resources, value, onChange, all = false,
}: {
  resources: Resource[];
  value: string;
  onChange: (id: string) => void;
  all?: boolean;
}) {
  return <Field label="Equipment">
    <select name="example_resource_id" value={value} onChange={(event) => onChange(event.currentTarget.value)}>
      {all && <option value="">All equipment</option>}
      {resources.map((resource) => <option key={resource.example_id} value={resource.example_id}>{resource.example_name}</option>)}
    </select>
  </Field>;
}

function useMutation(onChanged: ViewProps["onChanged"]) {
  const locked = useRef(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ message: string; error: boolean }>();
  async function run(action: () => Promise<unknown>, message: string, onSuccess?: () => void) {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setNotice(undefined);
    try {
      await action();
      await onChanged();
      onSuccess?.();
      setNotice({ message, error: false });
    } catch (error) {
      setNotice({ message: error instanceof Error ? error.message : "The request failed.", error: true });
    } finally {
      locked.current = false;
      setBusy(false);
    }
  }
  return {
    busy,
    run,
    feedback: notice && (
      <p role={notice.error ? "alert" : "status"} className={`notice ${notice.error ? "notice-error" : "notice-success"}`}>
        {notice.message}
      </p>
    ),
  };
}

function useBookingAction({ actor, onChanged }: ViewProps) {
  const mutation = useMutation(onChanged);
  function change(booking: Reservation, action: ReservationAction) {
    void mutation.run(
      () => patch<Reservation>("example_reservations", actor.example_id, booking.example_id, { example_action: action }),
      actionMessages[action],
    );
  }
  return { ...mutation, change };
}

function bookingNames(workshop: Workshop, booking: Reservation) {
  return {
    equipment: workshop.example_resources.find((item) => item.example_id === booking.example_resource_id)?.example_name
      ?? booking.example_resource_id,
    requester: workshop.example_users.find((user) => user.example_id === booking.example_requester_id)?.example_name
      ?? booking.example_requester_id,
  };
}

function BookingCard({
  workshop, booking, children,
}: {
  workshop: Workshop;
  booking: Reservation;
  children?: ReactNode;
}) {
  const names = bookingNames(workshop, booking);
  return (
    <article className="record-card" aria-label={`Booking ${booking.example_id}`}>
      <div className="record-meta">
        <h3>{names.equipment}</h3>
        {statusBadge(booking.example_status)}
        {isOverdue(booking, workshop.example_now) && <span className="badge tone-overdue">Overdue</span>}
      </div>
      <p className="record-meta">{names.requester} · {formatDay(booking.example_start)} · {timeRange(booking)}</p>
      {booking.example_note && <p>{booking.example_note}</p>}
      {children && <div className="record-actions">{children}</div>}
    </article>
  );
}

function DayTimeline({ opening, closing, bookings }: {
  opening: number;
  closing: number;
  bookings: Reservation[];
}) {
  const length = closing - opening;
  const positions = bookings.filter((booking) => booking.example_start < closing && booking.example_end > opening);
  return (
    <div className="schedule-grid">
      <div className="schedule-scale" aria-hidden="true">
        {Array.from({ length: 6 }, (_, index) => (
          <span key={index}>{formatTime(opening + length * index / 5)}</span>
        ))}
      </div>
      <div className="schedule-track" aria-label="Confirmed booking times from 08:00 to 18:00">
        {positions.map((booking) => {
          const start = Math.max(booking.example_start, opening);
          const end = Math.min(booking.example_end, closing);
          return (
            <span
              key={booking.example_id}
              className={`schedule-hold tone-${booking.example_status.slice("example_".length)}`}
              style={{ left: `${100 * (start - opening) / length}%`, width: `${100 * (end - start) / length}%` }}
              title={timeRange(booking)}
            />
          );
        })}
      </div>
    </div>
  );
}

export function Calendar(props: ViewProps) {
  const { workshop, actor, resourceId, onResource, onChanged } = props;
  const { example_now: now, example_resources: resources, example_reservations: reservations } = workshop;
  const resource = resources.find((item) => item.example_id === resourceId) ?? resources[0];
  const [chosenDay, setChosenDay] = useState("");
  const [chosenStart, setChosenStart] = useState("");
  const [chosenEnd, setChosenEnd] = useState("");
  const [note, setNote] = useState("");
  const mutation = useMutation(onChanged);
  const day = chosenDay || dateKey(now);
  const opening = workshopTime(day, 8);
  const closing = workshopTime(day, 18);
  const midnight = workshopTime(day, 0);
  const nextMidnight = workshopTime(shiftDay(day, 1), 0);
  const slots = Array.from({ length: 21 }, (_, index) => opening + index * slotMs);
  const starts = slots.filter((slot) => slot >= now && slot < closing);
  const start = starts.find((slot) => String(slot) === chosenStart) ?? starts[0];
  const ends = slots.filter((slot) => slot > start);
  const end = ends.find((slot) => String(slot) === chosenEnd) ?? ends[0];
  const dayBookings = reservations.filter((booking) =>
    booking.example_resource_id === resource?.example_id &&
    booking.example_start < nextMidnight && booking.example_end > midnight,
  ).sort((left, right) => left.example_start - right.example_start);
  const confirmed = dayBookings.filter((booking) =>
    booking.example_status === "example_approved" || booking.example_status === "example_checked_out",
  );
  const pendingCount = dayBookings.filter((booking) => booking.example_status === "example_requested").length;

  function selectDay(value: string) {
    if (value && (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(`${value}T12:00:00Z`)))) return;
    setChosenDay(value);
    setChosenStart("");
    setChosenEnd("");
  }

  function request(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!resource || start === undefined || end === undefined) return;
    void mutation.run(
      () => post<Reservation>("example_reservations", actor.example_id, {
        example_resource_id: resource.example_id,
        example_start: start,
        example_end: end,
        example_note: note,
      }),
      "Booking requested. It is ready for operator review.",
      () => setNote(""),
    );
  }

  return <>
    <header className="page-heading">
      <div>
        <p className="eyebrow">Equipment schedule</p>
        <h1>Booking calendar</h1>
        <p className="page-description">Pick an item and day to see confirmed holds and request a time in Vienna.</p>
      </div>
    </header>
    <section className="panel" aria-labelledby="example_calendar_filters_heading">
      <div className="panel-heading"><h2 id="example_calendar_filters_heading">Day and equipment</h2></div>
      <div className="panel-body filters">
        <EquipmentSelect resources={resources} value={resource?.example_id ?? ""} onChange={onResource} />
        <Field label="Booking day">
          <input name="example_booking_day" type="date" value={day} onChange={(event) => selectDay(event.currentTarget.value)} />
        </Field>
        <div className="record-actions">
          <button className="button button-secondary" type="button" onClick={() => selectDay(shiftDay(day, -1))}>Previous day</button>
          <button className="button button-secondary" type="button" onClick={() => selectDay(shiftDay(day, 1))}>Next day</button>
          <button className="button button-secondary" type="button" onClick={() => selectDay("")}>Demo day</button>
        </div>
      </div>
    </section>
    <section className="panel" aria-labelledby="example_timeline_heading">
      <div className="panel-heading">
        <div>
          <h2 id="example_timeline_heading">Confirmed holds</h2>
          <p className="record-meta">{resource?.example_name} · {formatDay(opening)} · Vienna time</p>
        </div>
        <span className="badge tone-requested">{pendingCount} pending</span>
      </div>
      <div className="panel-body">
        <DayTimeline opening={opening} closing={closing} bookings={confirmed} />
        {confirmed.length === 0
          ? <p className="empty-state">There are no confirmed holds for this item on this day.</p>
          : <ul className="schedule-list">
            {confirmed.map((booking) => <li className="schedule-row" key={booking.example_id}>
              <strong>{timeRange(booking)}</strong>
              <span>{bookingNames(workshop, booking).requester}</span>
              {statusBadge(booking.example_status)}
            </li>)}
          </ul>}
        <p className="record-meta">Approved bookings hold calendar time. The operator checks conflicts at approval.</p>
      </div>
    </section>
    <section className="panel" aria-labelledby="example_request_heading">
      <div className="panel-heading"><h2 id="example_request_heading">Request a booking</h2></div>
      <div className="panel-body">
        {mutation.feedback}
        {actor.example_role === "example_operator" ? (
          <p className="empty-state">Select a requester in the demo identity menu to make a booking.</p>
        ) : start === undefined ? (
          <p className="empty-state">Select a day with a future slot between 08:00 and 18:00.</p>
        ) : <form onSubmit={request} aria-label="Booking request">
          <div className="form-grid">
            <Field label="Start time">
              <select name="example_start" value={start} onChange={(event) => {
                setChosenStart(event.currentTarget.value);
                setChosenEnd("");
              }}>
                {starts.map((slot) => <option key={slot} value={slot}>{formatTime(slot)}</option>)}
              </select>
            </Field>
            <Field label="End time">
              <select name="example_end" value={end} onChange={(event) => setChosenEnd(event.currentTarget.value)}>
                {ends.map((slot) => <option key={slot} value={slot}>{formatTime(slot)}</option>)}
              </select>
            </Field>
          </div>
          <Field label="Booking note">
            <input name="example_note" maxLength={408} value={note} onChange={(event) => setNote(event.currentTarget.value)} placeholder="example_Preview session" />
          </Field>
          <div className="form-actions">
            <button className="button button-primary" type="submit" disabled={mutation.busy}>Request booking</button>
          </div>
        </form>}
      </div>
    </section>
  </>;
}

export function Reservations(props: ViewProps) {
  const { workshop, actor, resourceId, onResource } = props;
  const operator = actor.example_role === "example_operator";
  const { example_reservations: reservations, example_resources: resources, example_now: now } = workshop;
  const mutation = useBookingAction(props);
  const [status, setStatus] = useState("");
  const matching = reservations.filter((booking) =>
    (operator || booking.example_requester_id === actor.example_id) &&
    (!resourceId || booking.example_resource_id === resourceId) &&
    (!status || booking.example_status === status),
  ).sort((left, right) => {
    const leftPending = left.example_status === "example_requested";
    const rightPending = right.example_status === "example_requested";
    return Number(rightPending) - Number(leftPending) || right.example_created_at - left.example_created_at;
  });

  return <>
    <header className="page-heading">
      <div>
        <p className="eyebrow">Requests and decisions</p>
        <h1>{operator ? "Reservation queue" : "My reservations"}</h1>
        <p className="page-description">
          {operator ? "Review pending requests and confirm time on the calendar." : "Track requests, approved bookings, and their outcomes."}
        </p>
      </div>
      {!operator && <button className="button button-primary" type="button" onClick={() => props.onNavigate("calendar")}>Open calendar</button>}
    </header>
    <section className="panel" aria-labelledby="example_reservation_filter_heading">
      <div className="panel-heading"><h2 id="example_reservation_filter_heading">Filter reservations</h2></div>
      <div className="panel-body filters">
        <EquipmentSelect resources={resources} value={resourceId} onChange={onResource} all />
        <Field label="Status">
          <select name="example_status" value={status} onChange={(event) => setStatus(event.currentTarget.value)}>
            <option value="">All statuses</option>
            {Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
        </Field>
      </div>
    </section>
    {mutation.feedback}
    <section className="record-list" aria-label="Reservations">
      {matching.length === 0 && <p className="empty-state">No reservations match these filters.</p>}
      {matching.map((booking) => {
        const pending = booking.example_status === "example_requested";
        const eligible = booking.example_end > now;
        const canCancel = !operator && eligible && (pending || booking.example_status === "example_approved");
        return <BookingCard key={booking.example_id} workshop={workshop} booking={booking}>
          {operator && pending && <>
            <button className="button button-primary" type="button" disabled={!eligible || mutation.busy}
              onClick={() => mutation.change(booking, "example_approve")}>Approve</button>
            <button className="button button-secondary" type="button" disabled={mutation.busy}
              onClick={() => mutation.change(booking, "example_decline")}>Decline</button>
          </>}
          {canCancel && <button className="button button-secondary" type="button" disabled={mutation.busy}
            onClick={() => mutation.change(booking, "example_cancel")}>Cancel booking</button>}
        </BookingCard>;
      })}
    </section>
  </>;
}

export function CheckoutDesk(props: ViewProps) {
  const { workshop, actor, resourceId, onResource } = props;
  const operator = actor.example_role === "example_operator";
  const { example_reservations: reservations, example_resources: resources, example_now: now } = workshop;
  const mutation = useBookingAction(props);
  const inCustody = new Set(reservations
    .filter((booking) => booking.example_status === "example_checked_out")
    .map((booking) => booking.example_resource_id));
  const visible = reservations.filter((booking) =>
    (operator || booking.example_requester_id === actor.example_id) &&
    (!resourceId || booking.example_resource_id === resourceId),
  );
  const active = visible.filter((booking) => booking.example_status === "example_checked_out")
    .sort((left, right) => left.example_end - right.example_end);
  const upcoming = visible.filter((booking) => booking.example_status === "example_approved" && booking.example_end > now)
    .sort((left, right) => left.example_start - right.example_start);

  return <>
    <header className="page-heading">
      <div>
        <p className="eyebrow">Equipment custody</p>
        <h1>Checkout desk</h1>
        <p className="page-description">Hand over approved equipment, check due times, and record returns.</p>
      </div>
    </header>
    <section className="panel" aria-labelledby="example_desk_filter_heading">
      <div className="panel-heading"><h2 id="example_desk_filter_heading">Desk filters</h2></div>
      <div className="panel-body filters">
        <EquipmentSelect resources={resources} value={resourceId} onChange={onResource} all />
        <span className="badge tone-overdue">{active.filter((booking) => isOverdue(booking, now)).length} overdue</span>
      </div>
    </section>
    {mutation.feedback}
    <section className="panel" aria-labelledby="example_custody_heading">
      <div className="panel-heading"><h2 id="example_custody_heading">Active checkouts</h2></div>
      <div className="panel-body record-list">
        {active.length === 0 && <p className="empty-state">No items are checked out for this selection.</p>}
        {active.map((booking) => <BookingCard key={booking.example_id} workshop={workshop} booking={booking}>
          <span className="record-meta">Due {formatDateTime(booking.example_end)}</span>
          {operator && <button className="button button-secondary" type="button" disabled={mutation.busy}
            onClick={() => mutation.change(booking, "example_return")}>Record return</button>}
        </BookingCard>)}
      </div>
    </section>
    <section className="panel" aria-labelledby="example_handover_heading">
      <div className="panel-heading"><h2 id="example_handover_heading">Approved handovers</h2></div>
      <div className="panel-body record-list">
        {upcoming.length === 0 && <p className="empty-state">No approved bookings are waiting for handover.</p>}
        {upcoming.map((booking) => {
          const ready = booking.example_start <= now;
          const occupied = inCustody.has(booking.example_resource_id);
          return <BookingCard key={booking.example_id} workshop={workshop} booking={booking}>
            <span className="record-meta">
              {occupied ? "Waiting for the previous borrower to return this item."
                : ready ? "Ready for handover." : `Handover opens ${formatDateTime(booking.example_start)}.`}
            </span>
            {operator && <button className="button button-primary" type="button" disabled={!ready || occupied || mutation.busy}
              onClick={() => mutation.change(booking, "example_checkout")}>Check out</button>}
          </BookingCard>;
        })}
      </div>
    </section>
  </>;
}
