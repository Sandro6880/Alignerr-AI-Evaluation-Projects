type Resource = "example_workshop" | "example_resources" | "example_reservations" | "example_clock";

const sessionBytes = crypto.getRandomValues(new Uint8Array(16));
const sessionId = `example_session_${Array.from(sessionBytes, byte => byte.toString(16).padStart(2, "0")).join("")}`;

async function request<T>(
  method: "GET" | "POST" | "PATCH",
  resource: Resource,
  actor: string,
  body?: unknown,
  id?: string,
): Promise<T> {
  const item = id ? `/${encodeURIComponent(id)}` : "";
  const response = await fetch(`/api/${resource}${item}`, {
    method,
    headers: {
      "x-example-session": sessionId,
      "x-example-actor": actor,
      ...(body === undefined ? {} : { "content-type": "application/json" }),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.example_error ?? "The workshop request could not be completed.");
  return result as T;
}

export function get<T>(resource: Resource, actor: string): Promise<T> {
  return request<T>("GET", resource, actor);
}

export function post<T>(resource: Resource, actor: string, body?: unknown): Promise<T> {
  return request<T>("POST", resource, actor, body);
}

export function patch<T>(resource: Resource, actor: string, id: string, body: unknown): Promise<T> {
  return request<T>("PATCH", resource, actor, body, id);
}
