import { useEffect, useRef, useState } from "react";

import { get, post } from "./api-client";
import { formatDateTime, requesterId, type Page, type Workshop } from "./domain";
import { Calendar, CheckoutDesk, Reservations } from "./ui/BookingViews";
import { Catalog, Overview } from "./ui/OverviewCatalog";

const pages: { id: Page; label: string; icon: string }[] = [
  { id: "overview", label: "Overview", icon: "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z" },
  { id: "catalog", label: "Equipment catalog", icon: "M4 7l8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4M12 11v10M8 5l8 4" },
  { id: "calendar", label: "Booking calendar", icon: "M4 5h16v16H4zM4 10h16M8 3v4M16 3v4M8 14h2M14 14h2M8 17h2" },
  { id: "reservations", label: "Reservations", icon: "M6 3h12v18H6zM9 8h6M9 12h6M9 16h4" },
  { id: "desk", label: "Checkout desk", icon: "M4 11h16v9H4zM7 11V6h10v5M9 15h6" },
];

function Icon({ path }: { path: string }) {
  return <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"
    strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={path} /></svg>;
}

export default function App() {
  const [actorId, setActorId] = useState(requesterId);
  const [page, setPage] = useState<Page>("overview");
  const [resourceId, setResourceId] = useState("");
  const [workshop, setWorkshop] = useState<Workshop | null>(null);
  const [loadError, setLoadError] = useState("");
  const [clockError, setClockError] = useState("");
  const [advancing, setAdvancing] = useState(false);
  const requestVersion = useRef(0);

  async function refresh(identity: string) {
    const version = ++requestVersion.current;
    setLoadError("");
    try {
      const snapshot = await get<Workshop>("example_workshop", identity);
      if (version === requestVersion.current) setWorkshop(snapshot);
    } catch (error) {
      if (version === requestVersion.current) {
        setLoadError(error instanceof Error ? error.message : "Could not load the workshop.");
      }
    }
  }

  useEffect(() => {
    void refresh(requesterId);
    return () => { requestVersion.current += 1; };
  }, []);

  const actor = workshop?.example_users.find((user) => user.example_id === actorId);
  const operator = actor?.example_role === "example_operator";
  const selection = resourceId || workshop?.example_resources[0]?.example_id || "";

  function navigate(next: Page, item?: string) {
    if (item !== undefined || next === "reservations" || next === "desk") setResourceId(item ?? "");
    setPage(next);
    window.scrollTo(0, 0);
  }

  async function advanceClock() {
    setAdvancing(true);
    setClockError("");
    try {
      await post<{ example_now: number }>("example_clock", actorId);
      await refresh(actorId);
    } catch (error) {
      setClockError(error instanceof Error ? error.message : "Could not advance the demo clock.");
    } finally {
      setAdvancing(false);
    }
  }

  function renderPage() {
    if (!workshop || !actor) return null;
    const props = {
      workshop, actor, resourceId: page === "reservations" || page === "desk" ? resourceId : selection,
      onResource: setResourceId, onChanged: () => refresh(actorId), onNavigate: navigate,
    };
    switch (page) {
      case "overview": return <Overview key={actorId} {...props} />;
      case "catalog": return <Catalog key={actorId} {...props} />;
      case "calendar": return <Calendar key={actorId} {...props} />;
      case "reservations": return <Reservations key={actorId} {...props} />;
      case "desk": return <CheckoutDesk key={actorId} {...props} />;
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <span className="brand-mark"><Icon path="M3 11l9-7 9 7v9H3zM9 20v-6h6v6M10 9h4" /></span>
          <div className="brand-text">Workshop Portal<small>Equipment operations</small></div>
        </div>
        <p className="nav-label">Workspace</p>
        <nav className="sidebar-nav" aria-label="Workshop navigation">
          {pages.map((item) => (
            <button type="button" key={item.id} className={`nav-item ${item.id === page ? "is-active" : ""}`}
              aria-current={item.id === page ? "page" : undefined} onClick={() => navigate(item.id)}>
              <Icon path={item.icon} /><span>{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <p className="demo-note"><strong>Demo workspace</strong><br />Refreshing the page restores example records.</p>
        </div>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <div className="topbar-title">Equipment workshop<small>{operator ? "Operator view" : "Requester view"}</small></div>
          <div className="clock-control">
            <span id="example_clock_label">Demo clock · Vienna</span>
            <time className="clock-value" aria-labelledby="example_clock_label" aria-live="polite"
              dateTime={workshop ? new Date(workshop.example_now).toISOString() : undefined}>
              {workshop ? formatDateTime(workshop.example_now) : "Loading time…"}
            </time>
            {operator && (
              <button className="button button-secondary" type="button" disabled={advancing} onClick={() => void advanceClock()}>
                Advance 30 minutes
              </button>
            )}
          </div>
          <label className="identity-switch">
            <span>Demo identity</span>
            <select name="example_actor_id" aria-label="Demo identity" value={actorId} disabled={!workshop || advancing}
              onChange={(event) => { setActorId(event.target.value); setClockError(""); }}>
              {workshop ? workshop.example_users.map((user) => (
                <option value={user.example_id} key={user.example_id}>
                  {user.example_name} · {user.example_role === "example_operator" ? "Operator" : "Requester"}
                </option>
              )) : <option value={requesterId}>Loading identities…</option>}
            </select>
          </label>
        </header>

        <main className="main-content">
          {!workshop && !loadError && <p className="notice" role="status">Loading the workshop…</p>}
          {loadError && (
            <div className="notice notice-error" role="alert">
              <span>{loadError}</span>
              <button className="button button-secondary" type="button" onClick={() => void refresh(actorId)}>Retry</button>
            </div>
          )}
          {clockError && <p className="notice notice-error" role="alert">{clockError}</p>}
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
