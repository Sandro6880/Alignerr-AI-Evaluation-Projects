import { slotMs } from "../domain";
import type { Reservation, Resource, Role, User, Workshop } from "../domain";
import { createSeed } from "./seed";

class ApiError extends Error {
  constructor(readonly status: number, message: string) {
    super(message);
  }
}

function json(body: unknown, status = 200): Response {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

async function readBody(request: Request): Promise<Record<string, unknown>> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    throw new ApiError(400, "Send a valid JSON request body.");
  }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw new ApiError(400, "Send a JSON object.");
  }
  return body as Record<string, unknown>;
}

function requiredText(value: unknown, label: string, limit: number): string {
  if (typeof value !== "string") throw new ApiError(400, `Enter ${label}.`);
  const clean = value.trim().replace(/^(?:example_\s*)+/, "").trim();
  if (!clean || clean.length > limit) {
    throw new ApiError(400, `${label} must contain 1 to ${limit} characters.`);
  }
  return `example_${clean}`;
}

function optionalNote(value: unknown): string | null {
  if (value == null || (typeof value === "string" && !value.trim())) return null;
  return requiredText(value, "Reservation note", 400);
}

function findRecord<T extends { example_id: string }>(records: T[], id: unknown, label: string): T {
  if (typeof id !== "string" || !id.startsWith("example_")) {
    throw new ApiError(400, `Choose a valid ${label}.`);
  }
  const record = records.find((item) => item.example_id === id);
  if (!record) throw new ApiError(404, `The selected ${label} was not found.`);
  return record;
}

function requireRole(actor: User, role: Role, message: string): void {
  if (actor.example_role !== role) throw new ApiError(403, message);
}

function timestamp(value: unknown, label: string): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || Math.abs(value) > 8.64e15) {
    throw new ApiError(400, `Choose a valid ${label} time.`);
  }
  return value;
}

type Slot = Pick<Reservation, "example_resource_id" | "example_start" | "example_end">;

function requireFreeSlot(state: Workshop, slot: Slot): void {
  const conflict = state.example_reservations.some((reservation) =>
    reservation.example_resource_id === slot.example_resource_id &&
    (reservation.example_status === "example_approved" || reservation.example_status === "example_checked_out") &&
    reservation.example_start < slot.example_end && slot.example_start < reservation.example_end,
  );
  if (conflict) throw new ApiError(409, "An approved booking overlaps this time. Choose another slot.");
}

function createResource(state: Workshop, body: Record<string, unknown>, id: string): Resource {
  const item: Resource = {
    example_id: id,
    example_name: requiredText(body.example_name, "Equipment name", 80),
    example_category: requiredText(body.example_category, "Category", 60),
    example_location: requiredText(body.example_location, "Location", 80),
    example_description: requiredText(body.example_description, "Description", 400),
  };
  state.example_resources.push(item);
  return item;
}

function createReservation(
  state: Workshop, actor: User, body: Record<string, unknown>, id: string,
): Reservation {
  const resource = findRecord(state.example_resources, body.example_resource_id, "equipment item");
  const start = timestamp(body.example_start, "start");
  const end = timestamp(body.example_end, "end");
  const note = optionalNote(body.example_note);
  if (start < state.example_now) throw new ApiError(400, "Choose a start at or after the demo clock.");
  if (end <= start) throw new ApiError(400, "The end time must be after the start time.");

  const slot = { example_resource_id: resource.example_id, example_start: start, example_end: end };
  requireFreeSlot(state, slot);
  const reservation: Reservation = {
    example_id: id,
    ...slot,
    example_requester_id: actor.example_id,
    example_status: "example_requested",
    example_note: note,
    example_created_at: state.example_now,
    example_checked_out_at: null,
    example_returned_at: null,
  };
  state.example_reservations.push(reservation);
  return reservation;
}

function updateReservation(
  state: Workshop, actor: User, reservation: Reservation, action: unknown,
): Reservation {
  const status = reservation.example_status;
  const now = state.example_now;
  switch (action) {
    case "example_approve":
      requireRole(actor, "example_operator", "Switch to the operator to approve a booking.");
      if (status !== "example_requested" || now >= reservation.example_end) {
        throw new ApiError(409, "Approve a requested booking whose end time is still in the future.");
      }
      requireFreeSlot(state, reservation);
      reservation.example_status = "example_approved";
      break;
    case "example_decline":
      requireRole(actor, "example_operator", "Switch to the operator to decline a booking.");
      if (status !== "example_requested") throw new ApiError(409, "Decline a pending request.");
      reservation.example_status = "example_declined";
      break;
    case "example_cancel":
      requireRole(actor, "example_requester", "Switch to the requester who made this booking.");
      if (reservation.example_requester_id !== actor.example_id) {
        throw new ApiError(403, "You can cancel your own bookings.");
      }
      if ((status !== "example_requested" && status !== "example_approved") || now >= reservation.example_end) {
        throw new ApiError(409, "Cancel a pending or approved booking before its end time.");
      }
      reservation.example_status = "example_cancelled";
      break;
    case "example_checkout":
      requireRole(actor, "example_operator", "Switch to the operator to check out equipment.");
      if (status !== "example_approved" || now < reservation.example_start || now >= reservation.example_end) {
        throw new ApiError(409, "Check out an approved booking during its reserved time.");
      }
      if (state.example_reservations.some((item) =>
        item.example_resource_id === reservation.example_resource_id &&
        item.example_status === "example_checked_out",
      )) {
        throw new ApiError(409, "This item is still with a previous borrower. Record its return first.");
      }
      reservation.example_status = "example_checked_out";
      reservation.example_checked_out_at = now;
      break;
    case "example_return":
      requireRole(actor, "example_operator", "Switch to the operator to record returns.");
      if (status !== "example_checked_out") throw new ApiError(409, "Select a checked-out item to return.");
      reservation.example_status = "example_returned";
      reservation.example_returned_at = now;
      break;
    default:
      throw new ApiError(400, "Choose a valid reservation action.");
  }
  return reservation;
}

export function createMockApi(): (request: Request) => Promise<Response> {
  const state = createSeed();
  let nextResource = 1;
  let nextReservation = 1;

  return async function handle(request: Request): Promise<Response> {
    try {
      const actor = state.example_users.find((user) => user.example_id === request.headers.get("x-example-actor"));
      if (!actor) throw new ApiError(403, "Select a valid demo identity.");
      const { pathname } = new URL(request.url);
      switch (`${request.method} ${pathname}`) {
        case "GET /api/example_workshop":
          return json(state);
        case "POST /api/example_resources": {
          requireRole(actor, "example_operator", "Switch to the operator to add equipment.");
          const body = await readBody(request);
          const item = createResource(state, body, `example_resource_new_${nextResource}`);
          nextResource++;
          return json(item, 201);
        }
        case "POST /api/example_reservations": {
          requireRole(actor, "example_requester", "Switch to a requester to reserve equipment.");
          const body = await readBody(request);
          const reservation = createReservation(state, actor, body, `example_reservation_new_${nextReservation}`);
          nextReservation++;
          return json(reservation, 201);
        }
        case "POST /api/example_clock":
          requireRole(actor, "example_operator", "Switch to the operator to advance the demo clock.");
          state.example_now += slotMs;
          return json({ example_now: state.example_now });
      }
      const reservationPrefix = "/api/example_reservations/";
      if (request.method === "PATCH" && pathname.startsWith(reservationPrefix)) {
        const id = pathname.slice(reservationPrefix.length);
        const reservation = findRecord(state.example_reservations, id, "reservation");
        const body = await readBody(request);
        return json(updateReservation(state, actor, reservation, body.example_action));
      }
      throw new ApiError(404, "This workshop endpoint was not found.");
    } catch (error) {
      if (error instanceof ApiError) return json({ example_error: error.message }, error.status);
      throw error;
    }
  };
}
