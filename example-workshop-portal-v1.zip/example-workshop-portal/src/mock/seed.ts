import { demoStart } from "../domain";
import type { Reservation, Resource, User, Workshop } from "../domain";

// The entire demo week is in CET (UTC+1).
function localTime(day: number, hour: number, minute = 0): number {
  return Date.UTC(2026, 10, 9 + day, hour - 1, minute);
}

function resourceId(index: number): string {
  return `example_resource_${String(index).padStart(2, "0")}`;
}

function requesterId(index: number): string {
  return `example_requester_${String(index).padStart(2, "0")}`;
}

function resources(): Resource[] {
  const catalog = [
    ["VR Kit 01", "Immersive equipment", "XR Studio", "Headset, controllers, and a tether for seated and room-scale trials."],
    ["VR Kit 02", "Immersive equipment", "XR Studio", "Standalone headset with controllers and a charging case."],
    ["Driving Simulator", "Simulators", "Simulation Bay", "Fixed-seat simulator with a steering wheel, pedals, and a wide display."],
    ["Bike Simulator", "Simulators", "Simulation Bay", "Stationary trainer with handlebar sensors for interaction studies."],
    ["Capture Camera 01", "Capture", "Media Bench", "Camera with a tripod and battery kit for demo recordings."],
    ["Capture Camera 02", "Capture", "Media Bench", "Compact camera and mount for close-up prototype footage."],
    ["Audio Recorder", "Capture", "Media Bench", "Portable field recorder with a stereo microphone pair."],
    ["Workstation 01", "Workstations", "Compute Room", "GPU workstation for simulation builds and recording review."],
    ["Workstation 02", "Workstations", "Compute Room", "Shared development machine with a dual-screen setup."],
    ["Workstation 03", "Workstations", "Compute Room", "Shared GPU machine for short benchmark sessions."],
    ["Soldering Station", "Tools", "Electronics Bench", "Temperature-controlled iron and bench accessories."],
    ["Prototype Kit", "Tools", "Electronics Bench", "Demo microcontrollers, breadboards, and basic sensors."],
    ["Tracking Camera Pair", "Immersive equipment", "XR Studio", "Matched tracking cameras with mounting hardware."],
    ["Motion Capture Rig", "Capture", "Simulation Bay", "Portable rig for capturing movement around a prototype."],
  ];
  return catalog.map(([name, category, location, description], index) => ({
    example_id: resourceId(index + 1),
    example_name: `example_${name}`,
    example_category: `example_${category}`,
    example_location: `example_${location}`,
    example_description: `example_${description}`,
  }));
}

function users(): User[] {
  const requesters = ["Ari", "Bea", "Cato", "Devon", "Emery", "Fin", "Gray"];
  return [
    { example_id: "example_operator_01", example_name: "example_Jules", example_role: "example_operator" },
    ...requesters.map((name, index): User => ({
      example_id: requesterId(index + 1),
      example_name: `example_${name}`,
      example_role: "example_requester",
    })),
  ];
}

function reservations(): Reservation[] {
  const entries: Reservation[] = [];
  function add(
    resource: number, requester: number, start: number, end: number, status: Reservation["example_status"],
    note: string, checkedOut: number | null = null, returned: number | null = null,
  ): void {
    entries.push({
      example_id: `example_reservation_${String(entries.length + 1).padStart(2, "0")}`,
      example_resource_id: resourceId(resource),
      example_requester_id: requesterId(requester),
      example_start: start,
      example_end: end,
      example_status: status,
      example_note: `example_${note}`,
      example_created_at: Math.min(demoStart - 60 * 60 * 1000, start - 60 * 60 * 1000),
      example_checked_out_at: checkedOut,
      example_returned_at: returned,
    });
  }

  add(2, 2, localTime(0, 7, 30), localTime(0, 8, 30), "example_checked_out", "Headset calibration", localTime(0, 7, 30));
  add(2, 3, localTime(0, 9, 30), localTime(0, 10, 30), "example_approved", "Interaction study");
  add(3, 4, localTime(0, 8, 30), localTime(0, 11), "example_checked_out", "Steering input review", localTime(0, 8, 45));
  add(4, 1, localTime(0, 11), localTime(0, 12), "example_requested", "Bike trial");
  add(4, 5, localTime(0, 11, 30), localTime(0, 12, 30), "example_requested", "Sensor comparison");
  add(5, 6, localTime(0, 7, 30), localTime(0, 8, 30), "example_returned", "Capture setup check", localTime(0, 7, 30), localTime(0, 8, 15));
  add(1, 7, localTime(0, 10, 30), localTime(0, 11, 30), "example_approved", "VR walkthrough");
  add(6, 3, localTime(0, 13), localTime(0, 14), "example_requested", "Prototype recording");
  add(8, 4, localTime(0, 15), localTime(0, 16), "example_cancelled", "Build review");
  add(10, 2, localTime(0, 14), localTime(0, 15), "example_declined", "Benchmark setup");

  const plan: ReadonlyArray<[Reservation["example_status"], string]> = [
    ["example_approved", "Dry run"],
    ["example_requested", "Calibration session"],
    ["example_approved", "Workshop demonstration"],
    ["example_requested", "Prototype measurement"],
    ["example_cancelled", "Team practice"],
    ["example_declined", "Setup rehearsal"],
  ];
  for (let day = 1; day <= 5; day++) {
    plan.forEach(([status, note], index) => {
      const hour = 9 + index;
      add((day * 3 + index) % 14 + 1, (day + index) % 7 + 1, localTime(day, hour), localTime(day, hour + 1), status, note);
    });
  }
  return entries;
}

export function createSeed(): Workshop {
  return {
    example_now: demoStart,
    example_users: users(),
    example_resources: resources(),
    example_reservations: reservations(),
  };
}
