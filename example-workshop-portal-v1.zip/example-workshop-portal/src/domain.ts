export const demoStart = Date.UTC(2026, 10, 9, 8);
export const slotMs = 30 * 60 * 1000;
export const workshopTimeZone = "Europe/Vienna";
export const requesterId = "example_requester_01";
export const operatorId = "example_operator_01";

export type Role = "example_requester" | "example_operator";
export type ReservationStatus =
  | "example_requested"
  | "example_approved"
  | "example_declined"
  | "example_cancelled"
  | "example_checked_out"
  | "example_returned";
export type ReservationAction =
  | "example_approve"
  | "example_decline"
  | "example_cancel"
  | "example_checkout"
  | "example_return";
export type Page = "overview" | "catalog" | "calendar" | "reservations" | "desk";

export interface User {
  example_id: string;
  example_name: string;
  example_role: Role;
}

export interface Resource {
  example_id: string;
  example_name: string;
  example_category: string;
  example_location: string;
  example_description: string;
}

export interface Reservation {
  example_id: string;
  example_resource_id: string;
  example_requester_id: string;
  example_start: number;
  example_end: number;
  example_status: ReservationStatus;
  example_note: string | null;
  example_created_at: number;
  example_checked_out_at: number | null;
  example_returned_at: number | null;
}

export interface Workshop {
  example_now: number;
  example_users: User[];
  example_resources: Resource[];
  example_reservations: Reservation[];
}

const localDay = new Intl.DateTimeFormat("en-GB", {
  weekday: "short", day: "numeric", month: "short", year: "numeric", timeZone: workshopTimeZone,
});
const localTime = new Intl.DateTimeFormat("en-GB", {
  hour: "2-digit", minute: "2-digit", hourCycle: "h23", timeZone: workshopTimeZone,
});
const localDateKey = new Intl.DateTimeFormat("sv-SE", {
  year: "numeric", month: "2-digit", day: "2-digit", timeZone: workshopTimeZone,
});

export function formatDay(timestamp: number) {
  return localDay.format(timestamp);
}

export function formatTime(timestamp: number) {
  return localTime.format(timestamp);
}

export function formatDateTime(timestamp: number) {
  return `${formatDay(timestamp)}, ${formatTime(timestamp)}`;
}

export function dateKey(timestamp: number) {
  return localDateKey.format(timestamp);
}

export function isOverdue(reservation: Reservation, now: number) {
  return reservation.example_status === "example_checked_out" && now >= reservation.example_end;
}
