import assert from "node:assert/strict";
import test from "node:test";

import { clientId, freelancerId, projectProgress } from "../src/domain";
import type { Delivery, IntakeRequest, Milestone, ReviewAction, Workspace } from "../src/domain";
import { createMockApi } from "../src/mock/api";

type Api = ReturnType<typeof createMockApi>;
const secondClientId = "example_client_02";
const target = Date.UTC(2026, 11, 8, 12);
const due = Date.UTC(2026, 11, 4, 12);

function request(api: Api, path: string, actor = freelancerId, method = "GET", body?: unknown) {
  return api(new Request(`http://example_mock_api.invalid/api/${path}`, {
    method,
    headers: { "x-example-actor": actor, "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  }));
}

async function read<T>(pending: Promise<Response>, expectedStatus = 200): Promise<T> {
  const response = await pending;
  const payload = await response.json();
  assert.equal(response.status, expectedStatus, payload.example_error);
  return payload as T;
}

function snapshot(api: Api, actor = freelancerId) {
  return read<Workspace>(request(api, "example_workspace", actor));
}

function submitRequest(api: Api, actor = clientId, date: number | null = target) {
  return request(api, "example_requests", actor, "POST", {
    example_title: "example_Release checklist",
    example_description: "example_Create a checklist for the next demo release.",
    example_target_date: date,
  });
}

function accept(api: Api, id: string, actor = freelancerId) {
  return request(api, `example_requests/${id}`, actor, "PATCH", { example_action: "example_accept" });
}

async function createProject(api: Api) {
  const draft = await read<IntakeRequest>(submitRequest(api), 201);
  const accepted = await read<IntakeRequest>(accept(api, draft.example_id));
  assert.ok(accepted.example_project_id);
  return accepted.example_project_id;
}

function createMilestone(api: Api, projectId: string, title = "example_Demo checklist draft") {
  return read<Milestone>(request(api, "example_milestones", freelancerId, "POST", {
    example_project_id: projectId,
    example_title: title,
    example_description: "example_Draft one checklist for review.",
    example_due_date: due,
  }), 201);
}

function start(api: Api, id: string, actor = freelancerId) {
  return request(api, `example_milestones/${id}`, actor, "PATCH", { example_action: "example_start" });
}

function deliver(api: Api, milestoneId: string, preview = "example_First checklist preview") {
  return request(api, "example_deliveries", freelancerId, "POST", {
    example_milestone_id: milestoneId,
    example_title: "example_Review package",
    example_release_notes: "example_Ready for a client review.",
    example_preview: preview,
  });
}

function review(api: Api, id: string, action: ReviewAction, note?: string, actor = clientId) {
  return request(api, `example_deliveries/${id}`, actor, "PATCH", {
    example_action: action,
    example_note: note,
  });
}

test("the prefixed workspace has consistent seed records and resets across sessions", async () => {
  const api = createMockApi();
  const seed = await snapshot(api);
  assert.equal(seed.example_users.length, 6);
  assert.equal(seed.example_requests.length, 12);
  assert.equal(seed.example_projects.length, 6);
  assert.equal(seed.example_milestones.length, 18);
  assert.equal(seed.example_deliveries.length, 10);

  function verifyPrefixes(value: unknown): void {
    if (typeof value === "string") assert.match(value, /^example_/);
    if (Array.isArray(value)) value.forEach(verifyPrefixes);
    else if (value && typeof value === "object") {
      for (const [key, child] of Object.entries(value)) {
        assert.match(key, /^example_/);
        verifyPrefixes(child);
      }
    }
  }

  verifyPrefixes(seed);
  assert.ok(seed.example_requests.some(item => item.example_status === "example_submitted"));
  assert.ok(seed.example_deliveries.some(item => item.example_status === "example_submitted"));
  assert.ok(seed.example_deliveries.some(item => item.example_status === "example_changes_requested"));

  const draft = await read<IntakeRequest>(submitRequest(api), 201);
  assert.equal(draft.example_client_id, clientId);
  assert.equal(draft.example_status, "example_submitted");
  assert.equal(draft.example_project_id, null);
  assert.equal((await snapshot(api)).example_requests.length, 13);
  assert.deepEqual(await snapshot(createMockApi()), seed);
});

test("clients see only their work and only an owning client can review a delivery", async () => {
  const api = createMockApi();
  const projectId = await createProject(api);
  const milestone = await createMilestone(api, projectId);
  await read<Milestone>(start(api, milestone.example_id));
  const delivery = await read<Delivery>(deliver(api, milestone.example_id), 201);

  for (const actor of [clientId, secondClientId]) {
    const scoped = await snapshot(api, actor);
    assert.ok(scoped.example_projects.length > 0);
    assert.ok(scoped.example_requests.every(item => item.example_client_id === actor));
    assert.ok(scoped.example_projects.every(item => item.example_client_id === actor));
    assert.ok(scoped.example_milestones.every(item =>
      scoped.example_projects.some(project => project.example_id === item.example_project_id)));
    assert.ok(scoped.example_deliveries.every(item =>
      scoped.example_milestones.some(step => step.example_id === item.example_milestone_id)));
    assert.equal(scoped.example_deliveries.some(item => item.example_id === delivery.example_id), actor === clientId);
  }

  assert.equal((await review(api, delivery.example_id, "example_approve", undefined, secondClientId)).status, 403);
  assert.equal((await review(api, delivery.example_id, "example_approve", undefined, freelancerId)).status, 403);
  assert.equal((await start(api, milestone.example_id, clientId)).status, 403);
  const untouched = (await snapshot(api, clientId)).example_deliveries.find(item => item.example_id === delivery.example_id);
  assert.equal(untouched?.example_status, "example_submitted");
});

test("competing acceptance attempts create exactly one project linked to its request", async () => {
  const api = createMockApi();
  const draft = await read<IntakeRequest>(submitRequest(api), 201);
  assert.equal((await accept(api, draft.example_id, clientId)).status, 403);
  const decisions = await Promise.all([accept(api, draft.example_id), accept(api, draft.example_id)]);
  assert.deepEqual(decisions.map(item => item.status).sort(), [200, 409]);

  const state = await snapshot(api);
  const accepted = state.example_requests.find(item => item.example_id === draft.example_id);
  assert.ok(accepted);
  assert.equal(accepted.example_status, "example_accepted");
  assert.ok(accepted.example_project_id);
  const projects = state.example_projects.filter(item => item.example_request_id === draft.example_id);
  assert.equal(projects.length, 1);
  assert.equal(projects[0].example_id, accepted.example_project_id);
  assert.equal(projects[0].example_client_id, clientId);
  assert.equal(projects[0].example_title, draft.example_title);
  assert.equal(projects[0].example_target_date, target);
});

test("invalid inputs and out-of-order transitions leave the current delivery in review", async () => {
  const api = createMockApi();
  assert.equal((await submitRequest(api, freelancerId)).status, 403);
  assert.equal((await submitRequest(api, clientId, null)).status, 400);

  const milestone = await createMilestone(api, await createProject(api));
  assert.equal(milestone.example_status, "example_planned");
  assert.equal((await deliver(api, milestone.example_id)).status, 409);
  await read<Milestone>(start(api, milestone.example_id));
  assert.equal((await start(api, milestone.example_id)).status, 409);
  const submitted = await read<Delivery>(deliver(api, milestone.example_id), 201);
  assert.equal((await deliver(api, milestone.example_id)).status, 409);
  assert.equal((await review(api, submitted.example_id, "example_request_changes")).status, 400);
  assert.equal((await review(api, submitted.example_id, "example_comment", "")).status, 400);

  const state = await snapshot(api);
  const current = state.example_deliveries.filter(item => item.example_milestone_id === milestone.example_id);
  assert.equal(current.length, 1);
  assert.equal(current[0].example_status, "example_submitted");
  assert.equal(current[0].example_comments.length, 0);
  assert.equal(state.example_milestones.find(item => item.example_id === milestone.example_id)?.example_status, "example_in_review");
});

test("comments, requested changes, and revision approval keep milestone progress synchronized", async () => {
  const api = createMockApi();
  const projectId = await createProject(api);
  const milestone = await createMilestone(api, projectId);
  await createMilestone(api, projectId, "example_Release handoff");
  await read<Milestone>(start(api, milestone.example_id));
  const first = await read<Delivery>(deliver(api, milestone.example_id), 201);

  const note = "example_Add the smoke test command.";
  const commented = await read<Delivery>(review(api, first.example_id, "example_comment", note));
  assert.equal(commented.example_status, "example_submitted");
  assert.equal(commented.example_comments[0].example_text, note);
  assert.equal(commented.example_comments[0].example_author_id, clientId);

  const changes = await read<Delivery>(review(api, first.example_id, "example_request_changes", note));
  assert.equal(changes.example_status, "example_changes_requested");
  assert.equal(changes.example_comments.length, 2);
  const reopened = await snapshot(api);
  assert.equal(reopened.example_milestones.find(item => item.example_id === milestone.example_id)?.example_status, "example_in_progress");
  assert.deepEqual(projectProgress(reopened.example_milestones, projectId), { approved: 0, total: 2, complete: false });

  const revision = await read<Delivery>(deliver(api, milestone.example_id, "example_Checklist with smoke test command"), 201);
  assert.notEqual(revision.example_id, first.example_id);
  const approved = await read<Delivery>(review(api, revision.example_id, "example_approve"));
  assert.equal(approved.example_status, "example_approved");

  const final = await snapshot(api, clientId);
  assert.equal(final.example_milestones.find(item => item.example_id === milestone.example_id)?.example_status, "example_approved");
  assert.equal(final.example_deliveries.find(item => item.example_id === first.example_id)?.example_status, "example_changes_requested");
  assert.deepEqual(projectProgress(final.example_milestones, projectId), { approved: 1, total: 2, complete: false });
});
