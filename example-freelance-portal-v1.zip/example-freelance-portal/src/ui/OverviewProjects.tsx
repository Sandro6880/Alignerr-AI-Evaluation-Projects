import { useState } from "react";

import { formatDate, projectProgress, type MilestoneStatus } from "../domain";
import type { ViewProps } from "./FlowViews";

const milestoneLabels: Record<MilestoneStatus, string> = {
  example_planned: "Planned",
  example_in_progress: "In progress",
  example_in_review: "In review",
  example_approved: "Approved",
};

function Progress({ approved, total }: { approved: number; total: number }) {
  return (
    <>
      <p className="record-meta">{approved} / {total} approved</p>
      {total > 0 && (
        <progress className="project-progress" value={approved} max={total}
          aria-label={`${approved} of ${total} milestones approved`} />
      )}
    </>
  );
}

export function Overview({ workspace, actor, onNavigate }: ViewProps) {
  const freelancer = actor.example_role === "example_freelancer";
  const { example_requests: requests, example_projects: projects, example_milestones: milestones,
    example_deliveries: deliveries, example_users: users } = workspace;
  const pending = requests.filter((request) => request.example_status === "example_submitted");
  const active = projects.filter((project) => !projectProgress(milestones, project.example_id).complete);
  const inReview = deliveries.filter((delivery) => delivery.example_status === "example_submitted");
  const approvedCount = milestones.filter((milestone) => milestone.example_status === "example_approved").length;
  const reviewRows = [...inReview].sort((left, right) => right.example_submitted_at - left.example_submitted_at).slice(0, 4);
  const requestRows = [...pending].sort((left, right) => right.example_created_at - left.example_created_at).slice(0, 4);
  const projectRows = [...active].sort((left, right) => left.example_target_date - right.example_target_date).slice(0, 4);
  const metrics = [
    { label: "Pending requests", count: pending.length, detail: "Awaiting a decision" },
    { label: "Active projects", count: active.length, detail: "Work still in progress" },
    { label: "Deliveries in review", count: inReview.length, detail: "Awaiting client feedback" },
    { label: "Approved milestones", count: approvedCount, detail: "Completed work" },
  ];

  return (
    <>
      <header className="page-heading">
        <div>
          <p className="eyebrow">{freelancer ? "Freelancer workspace" : "Client workspace"}</p>
          <h1>Project overview</h1>
          <p className="page-description">{freelancer
            ? "Review incoming briefs and follow work from its first milestone to delivery."
            : "Track your work requests, project progress, and deliveries awaiting your review."}</p>
        </div>
        <div className="page-actions">
          <button className="button button-primary" type="button" onClick={() => onNavigate("requests")}>Open requests</button>
        </div>
      </header>

      <section className="stats-grid" aria-label="Project metrics">
        {metrics.map(({ label, count, detail }) => (
          <article key={label} className="stat-card">
            <h2 className="stat-label">{label}</h2>
            <p className="stat-value">{count}</p>
            <p className="stat-detail">{detail}</p>
          </article>
        ))}
      </section>

      <div className="dashboard-grid">
        <section className="panel" aria-labelledby="example_requests_overview">
          <header className="panel-heading">
            <div><p className="eyebrow">Intake</p><h2 id="example_requests_overview">Pending requests</h2></div>
            <span className="attention-count">{pending.length}</span>
          </header>
          <div className="panel-body">
            {requestRows.length ? (
              <ul className="record-list">
                {requestRows.map((request) => (
                  <li className="record-card" key={request.example_id}>
                    <strong>{request.example_title}</strong>
                    <p className="record-meta">
                      {users.find((user) => user.example_id === request.example_client_id)?.example_name ?? request.example_client_id}
                      {" · Target "}{formatDate(request.example_target_date)}
                    </p>
                    <div className="record-actions">
                      <span className="badge tone-requested">Submitted</span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : <p className="empty-state">There are no requests awaiting a decision in this view.</p>}
          </div>
        </section>

        <section className="panel" aria-labelledby="example_review_overview">
          <header className="panel-heading">
            <div><p className="eyebrow">Delivery</p><h2 id="example_review_overview">Awaiting review</h2></div>
            <span className="attention-count">{inReview.length}</span>
          </header>
          <div className="panel-body">
            {reviewRows.length ? (
              <ul className="record-list">
                {reviewRows.map((delivery) => {
                  const milestone = milestones.find((item) => item.example_id === delivery.example_milestone_id);
                  const project = projects.find((item) => item.example_id === milestone?.example_project_id);
                  return (
                    <li className="record-card" key={delivery.example_id}>
                      <strong>{delivery.example_title}</strong>
                      <p className="record-meta">{project?.example_title ?? delivery.example_id} · {formatDate(delivery.example_submitted_at)}</p>
                      <div className="record-actions">
                        <button className="button button-secondary" type="button"
                          onClick={() => onNavigate("deliveries", project?.example_id)}>View delivery review</button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : <p className="empty-state">There are no deliveries awaiting review in this view.</p>}
          </div>
        </section>
      </div>

      <section className="panel" aria-labelledby="example_active_overview">
        <header className="panel-heading">
          <div><p className="eyebrow">In progress</p><h2 id="example_active_overview">Active projects</h2></div>
          <button className="button button-secondary" type="button" onClick={() => onNavigate("projects")}>Open projects</button>
        </header>
        <div className="panel-body">
          {projectRows.length ? (
            <ul className="record-list">
              {projectRows.map((project) => {
                const progress = projectProgress(milestones, project.example_id);
                return (
                  <li className="record-card" key={project.example_id}>
                    <strong>{project.example_title}</strong>
                    <p className="record-meta">Target {formatDate(project.example_target_date)} · {progress.approved} / {progress.total} approved</p>
                    <div className="record-actions">
                      <button className="button button-secondary" type="button"
                        onClick={() => onNavigate("projects", project.example_id)}>View project</button>
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : <p className="empty-state">There are no active projects in this view.</p>}
        </div>
      </section>
    </>
  );
}

export function Projects({ workspace, actor, projectId, onProject, onNavigate }: ViewProps) {
  const [query, setQuery] = useState("");
  const [client, setClient] = useState("");
  const [status, setStatus] = useState("");
  const { example_projects: projects, example_milestones: milestones, example_users: users } = workspace;
  const freelancer = actor.example_role === "example_freelancer";
  const clients = users.filter((user) => user.example_role === "example_client");
  const needle = query.trim().toLowerCase();
  const visible = projects.filter((project) => {
    const { complete } = projectProgress(milestones, project.example_id);
    const projectStatus = complete ? "example_complete" : "example_active";
    return (!client || project.example_client_id === client) && (!status || status === projectStatus)
      && [project.example_title, project.example_description, project.example_id]
        .some((value) => value.toLowerCase().includes(needle));
  });
  const selected = visible.find((project) => project.example_id === projectId) ?? visible[0];
  const selectedMilestones = milestones.filter((milestone) => milestone.example_project_id === selected?.example_id);
  const progress = selected && projectProgress(milestones, selected.example_id);
  const selectedClient = clients.find((user) => user.example_id === selected?.example_client_id);

  return (
    <>
      <header className="page-heading">
        <div>
          <p className="eyebrow">Project portfolio</p>
          <h1>Projects</h1>
          <p className="page-description">Browse briefs, target dates, and progress based on approved milestones.</p>
        </div>
      </header>

      <section className="panel" aria-label="Project filters">
        <div className="panel-body filters">
          <label className="field">Search projects
            <input type="search" name="example_query" value={query} onChange={(event) => setQuery(event.currentTarget.value)}
              placeholder="Title, brief, or ID" />
          </label>
          {freelancer && (
            <label className="field">Client
              <select name="example_client_filter" value={client} onChange={(event) => setClient(event.currentTarget.value)}>
                <option value="">All clients</option>
                {clients.map((user) => <option key={user.example_id} value={user.example_id}>{user.example_name}</option>)}
              </select>
            </label>
          )}
          <label className="field">Status
            <select name="example_project_status" value={status} onChange={(event) => setStatus(event.currentTarget.value)}>
              <option value="">All statuses</option>
              <option value="example_active">Active</option>
              <option value="example_complete">Complete</option>
            </select>
          </label>
        </div>
      </section>

      <div className="catalog-layout">
        <section className="panel" aria-labelledby="example_project_list">
          <header className="panel-heading">
            <h2 id="example_project_list">Project list</h2>
            <span className="filter-result">{visible.length} of {projects.length} projects</span>
          </header>
          <div className="panel-body">
            {visible.length ? (
              <ul className="catalog-list">
                {visible.map((project) => {
                  const itemProgress = projectProgress(milestones, project.example_id);
                  return (
                    <li key={project.example_id}>
                      <button className={`catalog-list-item ${selected?.example_id === project.example_id ? "is-active" : ""}`}
                        type="button" aria-pressed={selected?.example_id === project.example_id}
                        onClick={() => onProject(project.example_id)}>
                        <strong>{project.example_title}</strong>
                        <span className={`badge ${itemProgress.complete ? "tone-approved" : "tone-requested"}`}>
                          {itemProgress.complete ? "Complete" : "Active"}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            ) : <p className="empty-state">No projects match these filters.</p>}
          </div>
        </section>

        <section className="panel catalog-detail" aria-labelledby="example_project_details">
          <header className="panel-heading"><h2 id="example_project_details">Project details</h2></header>
          <div className="panel-body">
            {selected && progress ? (
              <>
                <h3>{selected.example_title}</h3>
                <p className="page-description">{selected.example_description}</p>
                <dl className="catalog-facts">
                  <div><dt>Client</dt><dd>{selectedClient?.example_name ?? selected.example_client_id}</dd></div>
                  <div><dt>Target date</dt><dd>{formatDate(selected.example_target_date)}</dd></div>
                </dl>
                <Progress approved={progress.approved} total={progress.total} />
                {selectedMilestones.length > 0 && (
                  <ul className="record-list" aria-label="Project milestones">
                    {selectedMilestones.map((milestone) => (
                      <li className="record-card" key={milestone.example_id}>
                        <strong>{milestone.example_title}</strong>
                        <p className="record-meta">Due {formatDate(milestone.example_due_date)} · {milestoneLabels[milestone.example_status]}</p>
                      </li>
                    ))}
                  </ul>
                )}
                <div className="record-actions">
                  <button className="button button-primary" type="button" onClick={() => onNavigate("milestones", selected.example_id)}>
                    View milestones
                  </button>
                  <button className="button button-secondary" type="button" onClick={() => onNavigate("deliveries", selected.example_id)}>
                    Review deliveries
                  </button>
                </div>
              </>
            ) : <p className="empty-state">Select a project to view its details.</p>}
          </div>
        </section>
      </div>
    </>
  );
}
