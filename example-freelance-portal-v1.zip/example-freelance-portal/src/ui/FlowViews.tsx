import { useRef, useState, type FormEvent, type ReactNode } from "react";
import { patch, post } from "../api-client";
import {
  formatDate, parseDateInput, type Delivery, type IntakeRequest, type Milestone,
  type Page, type Project, type ReviewAction, type User, type Workspace,
} from "../domain";

export type ViewProps = {
  workspace: Workspace;
  actor: User;
  projectId: string;
  onProject: (id: string) => void;
  onChanged: () => Promise<void>;
  onNavigate: (page: Page, projectId?: string) => void;
};

const labels = {
  example_submitted: "Submitted",
  example_accepted: "Accepted",
  example_declined: "Declined",
  example_planned: "Planned",
  example_in_progress: "In progress",
  example_in_review: "In review",
  example_approved: "Approved",
  example_changes_requested: "Changes requested",
};

const reviewLabels: Record<ReviewAction, string> = {
  example_comment: "Comment",
  example_request_changes: "Change request",
  example_approve: "Approval",
};

const reviewMessages: Record<ReviewAction, string> = {
  example_comment: "Comment posted.",
  example_request_changes: "Changes requested.",
  example_approve: "Delivery approved. Milestone completed.",
};

function Field({ label, wide = false, children }: { label: string; wide?: boolean; children: ReactNode }) {
  return <label className={wide ? "field field-wide" : "field"}><span>{label}</span>{children}</label>;
}

function Badge({ status }: { status: keyof typeof labels }) {
  return <span className={`badge tone-${status.slice("example_".length)}`}>{labels[status]}</span>;
}

function personName(workspace: Workspace, id: string) {
  return workspace.example_users.find(user => user.example_id === id)?.example_name ?? id;
}

function useMutation(refresh: ViewProps["onChanged"]) {
  const locked = useRef(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ message: string; error: boolean }>();

  async function run<T>(action: () => Promise<T>, message: string, onSuccess?: (result: T) => void) {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setNotice(undefined);
    try {
      const result = await action();
      await refresh();
      onSuccess?.(result);
      setNotice({ message, error: false });
    } catch (error) {
      setNotice({ message: error instanceof Error ? error.message : "The request failed.", error: true });
    } finally {
      locked.current = false;
      setBusy(false);
    }
  }

  return {
    busy,
    run,
    feedback: notice && (
      <p className={`notice ${notice.error ? "notice-error" : "notice-success"}`} role={notice.error ? "alert" : "status"}>
        {notice.message}
      </p>
    ),
  };
}

function ProjectSelect({
  projects, current, onSelect,
}: { projects: Project[]; current: Project | undefined; onSelect: (id: string) => void }) {
  if (projects.length === 0) return null;
  return <Field label="Project">
    <select name="example_project_id" value={current?.example_id ?? ""} onChange={event => onSelect(event.currentTarget.value)}>
      {projects.map(project => <option key={project.example_id} value={project.example_id}>{project.example_title}</option>)}
    </select>
  </Field>;
}

export function Requests({ workspace, actor, onChanged, onProject, onNavigate }: ViewProps) {
  const freelancer = actor.example_role === "example_freelancer";
  const [showForm, setShowForm] = useState(false);
  const [status, setStatus] = useState("");
  const mutation = useMutation(onChanged);
  const requests = workspace.example_requests.filter(request => !status || request.example_status === status)
    .sort((a, b) => b.example_created_at - a.example_created_at);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    void mutation.run(() => post<IntakeRequest>("example_requests", actor.example_id, {
      example_title: String(data.get("example_title")),
      example_description: String(data.get("example_description")),
      example_target_date: parseDateInput(String(data.get("example_target_date"))),
    }), "Request submitted.", () => {
      setStatus("");
      setShowForm(false);
    });
  }

  function decide(request: IntakeRequest, action: "example_accept" | "example_decline") {
    void mutation.run(() => patch<IntakeRequest>("example_requests", actor.example_id, request.example_id, {
      example_action: action,
    }), action === "example_accept" ? "Request accepted. Project created." : "Request declined.", updated => {
      setStatus("");
      if (updated.example_project_id) onProject(updated.example_project_id);
    });
  }

  return <>
    <header className="page-heading">
      <div>
        <p className="eyebrow">Client intake</p>
        <h1>Requests</h1>
        <p className="page-description">
          {freelancer ? "Review incoming briefs and turn accepted requests into projects." : "Send a brief and follow its progress into a project."}
        </p>
      </div>
      {!freelancer && !showForm && <button type="button" className="button button-primary" onClick={() => setShowForm(true)}>New request</button>}
    </header>
    {mutation.feedback}
    {!freelancer && showForm && <section className="panel">
      <div className="panel-heading"><h2>New request</h2></div>
      <div className="panel-body">
        <form aria-label="New request" onSubmit={submit}>
          <div className="form-grid">
            <Field label="Request title"><input name="example_title" required /></Field>
            <Field label="Target date"><input name="example_target_date" type="date" required /></Field>
            <Field label="Brief" wide><textarea name="example_description" required /></Field>
          </div>
          <div className="form-actions">
            <button type="submit" className="button button-primary" disabled={mutation.busy}>Submit request</button>
            <button type="button" className="button button-secondary" disabled={mutation.busy} onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </form>
      </div>
    </section>}
    <div className="filters">
      <Field label="Request status">
        <select name="example_request_status" value={status} onChange={event => setStatus(event.currentTarget.value)}>
          <option value="">All statuses</option>
          <option value="example_submitted">Submitted</option>
          <option value="example_accepted">Accepted</option>
          <option value="example_declined">Declined</option>
        </select>
      </Field>
    </div>
    <section className="record-list" aria-label="Request list">
      {requests.length === 0 && <p className="empty-state">No requests match this view.</p>}
      {requests.map(request => <article className="record-card" key={request.example_id} aria-label={request.example_title}>
        <div className="record-meta"><h3>{request.example_title}</h3><Badge status={request.example_status} /></div>
        <p className="record-meta">{personName(workspace, request.example_client_id)} · Target {formatDate(request.example_target_date)}</p>
        <p>{request.example_description}</p>
        {freelancer && request.example_status === "example_submitted" && <div className="record-actions">
          <button type="button" className="button button-primary" disabled={mutation.busy} onClick={() => decide(request, "example_accept")}>Accept request</button>
          <button type="button" className="button button-secondary" disabled={mutation.busy} onClick={() => decide(request, "example_decline")}>Decline request</button>
        </div>}
        {request.example_project_id && <div className="record-actions">
          <button type="button" className="button button-secondary" onClick={() => onNavigate("projects", request.example_project_id ?? undefined)}>View project</button>
        </div>}
      </article>)}
    </section>
  </>;
}

export function Milestones({ workspace, actor, projectId, onProject, onChanged, onNavigate }: ViewProps) {
  const freelancer = actor.example_role === "example_freelancer";
  const project = workspace.example_projects.find(item => item.example_id === projectId) ?? workspace.example_projects[0];
  const milestones = workspace.example_milestones.filter(item => item.example_project_id === project?.example_id)
    .sort((a, b) => a.example_due_date - b.example_due_date);
  const [showForm, setShowForm] = useState(false);
  const mutation = useMutation(onChanged);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!project) return;
    const data = new FormData(event.currentTarget);
    void mutation.run(() => post<Milestone>("example_milestones", actor.example_id, {
      example_project_id: project.example_id,
      example_title: String(data.get("example_title")),
      example_description: String(data.get("example_description")),
      example_due_date: parseDateInput(String(data.get("example_due_date"))),
    }), "Milestone created.", () => setShowForm(false));
  }

  return <>
    <header className="page-heading">
      <div>
        <p className="eyebrow">Project progress</p>
        <h1>Milestones</h1>
        <p className="page-description">Follow scheduled work, delivery review, and approved outcomes for a project.</p>
      </div>
      {freelancer && project && !showForm && <button type="button" className="button button-primary" onClick={() => setShowForm(true)}>Add milestone</button>}
    </header>
    {mutation.feedback}
    <div className="filters">
      <ProjectSelect projects={workspace.example_projects} current={project} onSelect={id => {
        setShowForm(false);
        onProject(id);
      }} />
    </div>
    {freelancer && project && showForm && <section className="panel">
      <div className="panel-heading"><h2>Add milestone</h2></div>
      <div className="panel-body">
        <form aria-label="Add milestone" onSubmit={submit}>
          <div className="form-grid">
            <Field label="Milestone title"><input name="example_title" required /></Field>
            <Field label="Due date"><input name="example_due_date" type="date" required /></Field>
            <Field label="Description" wide><textarea name="example_description" required /></Field>
          </div>
          <div className="form-actions">
            <button type="submit" className="button button-primary" disabled={mutation.busy}>Create milestone</button>
            <button type="button" className="button button-secondary" disabled={mutation.busy} onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </form>
      </div>
    </section>}
    <section className="record-list" aria-label="Milestone list">
      {milestones.length === 0 && <p className="empty-state">{project ? "This project has no milestones yet." : "Milestones will appear when a project is created."}</p>}
      {milestones.map(milestone => <article className="record-card" key={milestone.example_id} aria-label={milestone.example_title}>
        <div className="record-meta"><h3>{milestone.example_title}</h3><Badge status={milestone.example_status} /></div>
        <p className="record-meta">Due {formatDate(milestone.example_due_date)}</p>
        <p>{milestone.example_description}</p>
        {freelancer && milestone.example_status === "example_planned" && <div className="record-actions">
          <button type="button" className="button button-primary" disabled={mutation.busy} onClick={() => void mutation.run(
            () => patch<Milestone>("example_milestones", actor.example_id, milestone.example_id, { example_action: "example_start" }),
            "Milestone started.",
          )}>Start milestone</button>
        </div>}
        {((freelancer && milestone.example_status === "example_in_progress") || milestone.example_status === "example_in_review") && <div className="record-actions">
          <button type="button" className="button button-secondary" onClick={() => onNavigate("deliveries", milestone.example_project_id)}>
            {milestone.example_status === "example_in_review" ? "Review deliveries" : "Open delivery review"}
          </button>
        </div>}
      </article>)}
    </section>
  </>;
}

function DeliveryCard({
  workspace, delivery, milestone, canReview, busy, onReview,
}: {
  workspace: Workspace;
  delivery: Delivery;
  milestone: Milestone;
  canReview: boolean;
  busy: boolean;
  onReview: (deliveryId: string, action: ReviewAction, note: string, clear: () => void) => void;
}) {
  const [note, setNote] = useState("");
  const review = (action: ReviewAction) => onReview(delivery.example_id, action, note, () => setNote(""));

  return <article className="record-card" aria-label={delivery.example_title}>
    <div className="record-meta"><h3>{delivery.example_title}</h3><Badge status={delivery.example_status} /></div>
    <p className="record-meta">{milestone.example_title} · Submitted {formatDate(delivery.example_submitted_at)}</p>
    <p>{delivery.example_release_notes}</p>
    <details className="delivery-preview">
      <summary>Delivery preview</summary>
      <p>{delivery.example_preview}</p>
    </details>
    {delivery.example_comments.length > 0 && <section className="review-notes" aria-label="Review notes">
      <h4>Review notes</h4>
      <ul className="comment-list">
        {delivery.example_comments.map(comment => <li key={comment.example_id}>
          <p className="record-meta">{reviewLabels[comment.example_kind]} · {personName(workspace, comment.example_author_id)} · {formatDate(comment.example_created_at)}</p>
          <p>{comment.example_text}</p>
        </li>)}
      </ul>
    </section>}
    {canReview && delivery.example_status === "example_submitted" && <>
      <Field label="Review note">
        <textarea name="example_note" value={note} onChange={event => setNote(event.currentTarget.value)} placeholder="example_Feedback for this delivery" />
      </Field>
      <div className="record-actions">
        <button type="button" className="button button-secondary" disabled={busy || !note.trim()} onClick={() => review("example_comment")}>Post comment</button>
        <button type="button" className="button button-secondary" disabled={busy || !note.trim()} onClick={() => review("example_request_changes")}>Request changes</button>
        <button type="button" className="button button-primary" disabled={busy} onClick={() => review("example_approve")}>Approve delivery</button>
      </div>
    </>}
  </article>;
}

export function Deliveries({ workspace, actor, projectId, onProject, onChanged }: ViewProps) {
  const freelancer = actor.example_role === "example_freelancer";
  const project = workspace.example_projects.find(item => item.example_id === projectId) ?? workspace.example_projects[0];
  const milestones = workspace.example_milestones.filter(item => item.example_project_id === project?.example_id);
  const milestoneById = new Map(milestones.map(item => [item.example_id, item]));
  const eligible = milestones.filter(item => item.example_status === "example_in_progress");
  const deliveries = workspace.example_deliveries.filter(item => milestoneById.has(item.example_milestone_id))
    .sort((a, b) => b.example_submitted_at - a.example_submitted_at);
  const [showForm, setShowForm] = useState(false);
  const mutation = useMutation(onChanged);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    void mutation.run(() => post<Delivery>("example_deliveries", actor.example_id, {
      example_milestone_id: String(data.get("example_milestone_id")),
      example_title: String(data.get("example_title")),
      example_release_notes: String(data.get("example_release_notes")),
      example_preview: String(data.get("example_preview")),
    }), "Delivery submitted for review.", () => setShowForm(false));
  }

  function review(deliveryId: string, action: ReviewAction, note: string, clear: () => void) {
    void mutation.run(() => patch<Delivery>("example_deliveries", actor.example_id, deliveryId, {
      example_action: action,
      ...(note.trim() ? { example_note: note } : {}),
    }), reviewMessages[action], clear);
  }

  return <>
    <header className="page-heading">
      <div>
        <p className="eyebrow">Handoff and feedback</p>
        <h1>Delivery review</h1>
        <p className="page-description">Preview delivered work, review revisions, and follow client decisions.</p>
      </div>
      {freelancer && eligible.length > 0 && !showForm && <button type="button" className="button button-primary" onClick={() => setShowForm(true)}>Submit delivery</button>}
    </header>
    {mutation.feedback}
    <div className="filters">
      <ProjectSelect projects={workspace.example_projects} current={project} onSelect={id => {
        setShowForm(false);
        onProject(id);
      }} />
    </div>
    {freelancer && showForm && eligible.length > 0 && <section className="panel">
      <div className="panel-heading"><h2>Submit delivery</h2></div>
      <div className="panel-body">
        <form aria-label="Submit delivery" onSubmit={submit}>
          <div className="form-grid">
            <Field label="Milestone">
              <select name="example_milestone_id" required>
                {eligible.map(item => <option key={item.example_id} value={item.example_id}>{item.example_title}</option>)}
              </select>
            </Field>
            <Field label="Delivery title"><input name="example_title" required /></Field>
            <Field label="Release notes" wide><textarea name="example_release_notes" required /></Field>
            <Field label="Preview text" wide><textarea name="example_preview" required /></Field>
          </div>
          <div className="form-actions">
            <button type="submit" className="button button-primary" disabled={mutation.busy}>Publish delivery</button>
            <button type="button" className="button button-secondary" disabled={mutation.busy} onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </form>
      </div>
    </section>}
    <section className="record-list" aria-label="Delivery list">
      {deliveries.length === 0 && <p className="empty-state">{project ? "Submitted deliveries will appear here." : "Deliveries will appear when a project is created."}</p>}
      {deliveries.map(delivery => {
        const milestone = milestoneById.get(delivery.example_milestone_id);
        if (!milestone) return null;
        return <DeliveryCard key={delivery.example_id} workspace={workspace} delivery={delivery} milestone={milestone}
          canReview={!freelancer && project?.example_client_id === actor.example_id} busy={mutation.busy} onReview={review} />;
      })}
    </section>
  </>;
}
