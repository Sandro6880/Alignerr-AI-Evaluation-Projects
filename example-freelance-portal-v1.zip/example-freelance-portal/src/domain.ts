export const clientId = "example_client_01";
export const freelancerId = "example_freelancer_01";

export type Role = "example_client" | "example_freelancer";
export type Page = "overview" | "requests" | "projects" | "milestones" | "deliveries";
export type RequestStatus = "example_submitted" | "example_accepted" | "example_declined";
export type MilestoneStatus = "example_planned" | "example_in_progress" | "example_in_review" | "example_approved";
export type DeliveryStatus = "example_submitted" | "example_changes_requested" | "example_approved";
export type ReviewAction = "example_comment" | "example_request_changes" | "example_approve";

export interface User {
  example_id: string;
  example_name: string;
  example_role: Role;
}

export interface IntakeRequest {
  example_id: string;
  example_client_id: string;
  example_title: string;
  example_description: string;
  example_target_date: number;
  example_status: RequestStatus;
  example_project_id: string | null;
  example_created_at: number;
}

export interface Project {
  example_id: string;
  example_client_id: string;
  example_request_id: string;
  example_title: string;
  example_description: string;
  example_target_date: number;
  example_created_at: number;
}

export interface Milestone {
  example_id: string;
  example_project_id: string;
  example_title: string;
  example_description: string;
  example_due_date: number;
  example_status: MilestoneStatus;
  example_created_at: number;
}

export interface DeliveryComment {
  example_id: string;
  example_author_id: string;
  example_text: string;
  example_kind: ReviewAction;
  example_created_at: number;
}

export interface Delivery {
  example_id: string;
  example_milestone_id: string;
  example_title: string;
  example_release_notes: string;
  example_preview: string;
  example_status: DeliveryStatus;
  example_submitted_at: number;
  example_comments: DeliveryComment[];
}

export interface Workspace {
  example_users: User[];
  example_requests: IntakeRequest[];
  example_projects: Project[];
  example_milestones: Milestone[];
  example_deliveries: Delivery[];
}

const dateFormat = new Intl.DateTimeFormat("en-GB", {
  day: "numeric", month: "short", year: "numeric", timeZone: "Europe/Vienna",
});

export function formatDate(timestamp: number) {
  return dateFormat.format(timestamp);
}

export function parseDateInput(value: string) {
  return Date.parse(`${value}T12:00:00Z`);
}

export function projectProgress(milestones: Milestone[], projectId: string) {
  const items = milestones.filter(item => item.example_project_id === projectId);
  const approved = items.filter(item => item.example_status === "example_approved").length;
  return { approved, total: items.length, complete: items.length > 0 && approved === items.length };
}
