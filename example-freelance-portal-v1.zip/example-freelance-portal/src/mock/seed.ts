import { clientId, freelancerId } from "../domain";
import type { Delivery, IntakeRequest, Milestone, Project, User, Workspace } from "../domain";

const date = (day: number, hour = 12) => Date.UTC(2026, 10, day, hour);
const numbered = (type: string, index: number) => `example_${type}_${String(index + 1).padStart(2, "0")}`;

const users: User[] = [
  { example_id: freelancerId, example_name: "example_Riley", example_role: "example_freelancer" },
  { example_id: clientId, example_name: "example_Mira", example_role: "example_client" },
  { example_id: "example_client_02", example_name: "example_Noor", example_role: "example_client" },
  { example_id: "example_client_03", example_name: "example_Eli", example_role: "example_client" },
  { example_id: "example_client_04", example_name: "example_Tess", example_role: "example_client" },
  { example_id: "example_client_05", example_name: "example_Bo", example_role: "example_client" },
];

const requestSamples: readonly [string, string, string, number, IntakeRequest["example_status"]][] = [
  [clientId, "example_Studio metrics dashboard", "example_Replace a static studio report with a filterable dashboard for the demo team.", 23, "example_accepted"],
  ["example_client_02", "example_Workshop landing page", "example_Design a compact landing page with an example workshop schedule and signup preview.", 20, "example_accepted"],
  ["example_client_03", "example_Inventory export tool", "example_Build a sample export workflow that validates synthetic inventory rows before download.", 9, "example_accepted"],
  [clientId, "example_Catalog finder", "example_Create a search interface for a synthetic product catalog with category filters.", 27, "example_accepted"],
  ["example_client_04", "example_Member onboarding", "example_Prototype the welcome steps, checklist, and confirmation view for a fictional member.", 25, "example_accepted"],
  ["example_client_05", "example_Status page refresh", "example_Update the layout for sample service health, incident entries, and maintenance notices.", 29, "example_accepted"],
  [clientId, "example_Report scheduling mockup", "example_Show how a sample team could pick and review scheduled reports.", 26, "example_submitted"],
  ["example_client_02", "example_Course directory", "example_Explore a browsable directory of fictional courses with two filters.", 28, "example_submitted"],
  ["example_client_04", "example_Asset review checklist", "example_Create a concise checklist for evaluating example design assets.", 30, "example_submitted"],
  ["example_client_05", "example_Incident summary cards", "example_Prepare a layout for comparing sample incident summaries at a glance.", 26, "example_submitted"],
  ["example_client_03", "example_Legacy spreadsheet migration", "example_Review the effort for a migration of a fictional archive.", 19, "example_declined"],
  [clientId, "example_Forum redesign", "example_Explore a visual refresh of a synthetic community forum.", 24, "example_declined"],
];

const milestoneSamples: readonly [number, string, string, number, Milestone["example_status"]][] = [
  [1, "example_Dashboard brief", "example_Summarize the metrics and user journeys for client review.", 7, "example_approved"],
  [1, "example_Dashboard preview", "example_Deliver a filterable overview with representative sample metrics.", 14, "example_in_review"],
  [1, "example_Dashboard handoff", "example_Prepare the approved dashboard preview and a concise handoff.", 23, "example_planned"],
  [2, "example_Page structure", "example_Draft a mobile layout with schedule and signup blocks.", 12, "example_in_progress"],
  [2, "example_Workshop schedule", "example_Add the event list and show how featured events are grouped.", 16, "example_in_progress"],
  [2, "example_Signup preview", "example_Prepare the final confirmation screen for review.", 20, "example_planned"],
  [3, "example_Column mapping", "example_Map example inventory fields to the export format.", 5, "example_approved"],
  [3, "example_Validation rules", "example_Check synthetic inventory rows and show readable error reasons.", 7, "example_approved"],
  [3, "example_Export preview", "example_Preview a formatted export of the valid sample rows.", 9, "example_approved"],
  [4, "example_Search design", "example_Draft how users search the synthetic catalog and clear filters.", 16, "example_in_progress"],
  [4, "example_Category filters", "example_Show category totals and preserve the search query during filtering.", 22, "example_planned"],
  [4, "example_Catalog review", "example_Present the complete result list and empty state for review.", 27, "example_planned"],
  [5, "example_Welcome flow brief", "example_Agree on the first three steps of the welcome experience.", 8, "example_approved"],
  [5, "example_Checklist prototype", "example_Deliver the interactive sample member checklist.", 18, "example_in_review"],
  [5, "example_Completion screen", "example_Provide a concise confirmation summary.", 25, "example_planned"],
  [6, "example_Status card layout", "example_Review the visual hierarchy of the sample service cards.", 8, "example_approved"],
  [6, "example_Incident timeline", "example_Organize example incident updates by service and date.", 19, "example_in_progress"],
  [6, "example_Maintenance panel", "example_Design how upcoming maintenance appears in the summary.", 29, "example_planned"],
];

const deliverySamples: readonly [
  number, string, string, string, Delivery["example_status"], number, string?,
][] = [
  [1, "example_Approved dashboard brief", "example_Defined the weekly reporting audience and sample metrics.", "example_Overview: traffic, conversion, and active demos.", "example_approved", 6, "example_These metrics cover the demo review."],
  [2, "example_Filterable dashboard preview", "example_Added period and category filters with example totals.", "example_Overview: 24 demo events in the selected period.", "example_submitted", 9, "example_The category filter looks useful."],
  [4, "example_Mobile page draft", "example_Split the first view into welcome, schedule, and signup sections.", "example_Mobile preview: welcome heading above a schedule link.", "example_changes_requested", 8, "example_Move the workshop date above the signup action."],
  [7, "example_Approved field mapping", "example_Mapped item name, category, quantity, and location.", "example_Inventory export columns: item, category, quantity, location.", "example_approved", 4],
  [8, "example_Approved validation preview", "example_Flagged blank item names and negative quantities.", "example_Validation summary: 8 accepted rows and 2 examples to fix.", "example_approved", 6, "example_The invalid row reasons are clear."],
  [9, "example_Approved export sample", "example_Delivered a preview of the valid rows and header order.", "example_Export ready: 8 rows, four columns.", "example_approved", 8],
  [13, "example_Approved welcome steps", "example_Identified the welcome, account basics, and checklist screens.", "example_Welcome flow: three short steps before confirmation.", "example_approved", 6],
  [14, "example_Checklist first draft", "example_Grouped the steps under a single progress indicator.", "example_Progress: step 2 of 3.", "example_changes_requested", 8, "example_Show which checklist step is still required."],
  [14, "example_Checklist revision", "example_Marked required and optional checklist steps explicitly.", "example_Checklist: two steps completed, one required.", "example_submitted", 9, "example_The required step is easier to identify now."],
  [16, "example_Approved status cards", "example_Used distinct labels for operational and degraded demo services.", "example_Status: two operational services and one degraded service.", "example_approved", 7, "example_Approved the card hierarchy."],
];

export function createSeed(): Workspace {
  const requests: IntakeRequest[] = requestSamples.map(([owner, title, description, targetDay, status], index) => ({
    example_id: numbered("request", index),
    example_client_id: owner,
    example_title: title,
    example_description: description,
    example_target_date: date(targetDay),
    example_status: status,
    example_project_id: status === "example_accepted" ? numbered("project", index) : null,
    example_created_at: date(status === "example_accepted" ? 2 : 8, 8 + index),
  }));
  const projects: Project[] = requests.flatMap((request) => request.example_project_id ? [{
    example_id: request.example_project_id,
    example_client_id: request.example_client_id,
    example_request_id: request.example_id,
    example_title: request.example_title,
    example_description: request.example_description,
    example_target_date: request.example_target_date,
    example_created_at: request.example_created_at + 60 * 60 * 1000,
  }] : []);
  const milestones: Milestone[] = milestoneSamples.map(([project, title, description, day, status], index) => ({
    example_id: numbered("milestone", index),
    example_project_id: projects[project - 1].example_id,
    example_title: title,
    example_description: description,
    example_due_date: date(day),
    example_status: status,
    example_created_at: projects[project - 1].example_created_at + 60 * 60 * 1000,
  }));
  const deliveries: Delivery[] = deliverySamples.map(([milestone, title, notes, preview, status, day, comment], index) => ({
    example_id: numbered("delivery", index),
    example_milestone_id: milestones[milestone - 1].example_id,
    example_title: title,
    example_release_notes: notes,
    example_preview: preview,
    example_status: status,
    example_submitted_at: date(day),
    example_comments: comment ? [{
      example_id: numbered("comment", index),
      example_author_id: projects[milestoneSamples[milestone - 1][0] - 1].example_client_id,
      example_text: comment,
      example_kind: status === "example_changes_requested" ? "example_request_changes"
        : status === "example_approved" ? "example_approve" : "example_comment",
      example_created_at: date(day, 13),
    }] : [],
  }));

  return {
    example_users: users.map((user) => ({ ...user })),
    example_requests: requests,
    example_projects: projects,
    example_milestones: milestones,
    example_deliveries: deliveries,
  };
}
