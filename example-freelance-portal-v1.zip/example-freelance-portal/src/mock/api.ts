import type { Delivery, IntakeRequest, Milestone, Project, Role, User, Workspace } from "../domain";
import { createSeed } from "./seed";

class ApiError extends Error {
  constructor(readonly status: number, message: string) {
    super(message);
  }
}

function json(body: unknown, status = 200): Response {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

async function readBody(request: Request): Promise<Record<string, unknown>> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    throw new ApiError(400, "Send a valid JSON request body.");
  }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw new ApiError(400, "Send a JSON object.");
  }
  return body as Record<string, unknown>;
}

function requiredText(value: unknown, label: string, limit: number): string {
  if (typeof value !== "string") throw new ApiError(400, `Enter ${label}.`);
  const text = value.trim().replace(/^(?:example_\s*)+/, "").trim();
  if (!text || text.length > limit) throw new ApiError(400, `${label} must contain 1 to ${limit} characters.`);
  return `example_${text}`;
}

function dateValue(value: unknown, label: string): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || Math.abs(value) > 8.64e15) {
    throw new ApiError(400, `Choose a valid ${label}.`);
  }
  return value;
}

function findRecord<T extends { example_id: string }>(records: T[], id: unknown, label: string): T {
  if (typeof id !== "string" || !id.startsWith("example_")) throw new ApiError(400, `Choose a valid ${label}.`);
  const record = records.find((item) => item.example_id === id);
  if (!record) throw new ApiError(404, `The selected ${label} was not found.`);
  return record;
}

function requireRole(actor: User, role: Role, message: string): void {
  if (actor.example_role !== role) throw new ApiError(403, message);
}

function snapshot(state: Workspace, actor: User): Workspace {
  if (actor.example_role === "example_freelancer") return state;
  const owned = (item: { example_client_id: string }) => item.example_client_id === actor.example_id;
  const projects = state.example_projects.filter(owned);
  const projectIds = new Set(projects.map((project) => project.example_id));
  const milestones = state.example_milestones.filter((milestone) => projectIds.has(milestone.example_project_id));
  const milestoneIds = new Set(milestones.map((milestone) => milestone.example_id));
  return {
    example_users: state.example_users,
    example_requests: state.example_requests.filter(owned),
    example_projects: projects,
    example_milestones: milestones,
    example_deliveries: state.example_deliveries.filter((delivery) => milestoneIds.has(delivery.example_milestone_id)),
  };
}

export function createMockApi(): (request: Request) => Promise<Response> {
  const state = createSeed();
  const sequences = { request: 0, project: 0, milestone: 0, delivery: 0, comment: 0 };
  const nextId = (type: keyof typeof sequences) => `example_${type}_new_${++sequences[type]}`;
  let time = Date.UTC(2026, 10, 10, 12);
  const nextTime = () => ++time;

  function addRequest(actor: User, body: Record<string, unknown>): IntakeRequest {
    const title = requiredText(body.example_title, "Request title", 100);
    const description = requiredText(body.example_description, "Brief", 1200);
    const target = dateValue(body.example_target_date, "target date");
    const entry: IntakeRequest = {
      example_id: nextId("request"),
      example_client_id: actor.example_id,
      example_title: title,
      example_description: description,
      example_target_date: target,
      example_status: "example_submitted",
      example_project_id: null,
      example_created_at: nextTime(),
    };
    state.example_requests.push(entry);
    return entry;
  }

  function decideRequest(entry: IntakeRequest, action: unknown): IntakeRequest {
    if (action !== "example_accept" && action !== "example_decline") {
      throw new ApiError(400, "Choose whether to accept or decline this request.");
    }
    if (entry.example_status !== "example_submitted") {
      throw new ApiError(409, "This request already has a decision.");
    }
    if (action === "example_decline") {
      entry.example_status = "example_declined";
    } else {
      const project: Project = {
        example_id: nextId("project"),
        example_client_id: entry.example_client_id,
        example_request_id: entry.example_id,
        example_title: entry.example_title,
        example_description: entry.example_description,
        example_target_date: entry.example_target_date,
        example_created_at: nextTime(),
      };
      state.example_projects.push(project);
      entry.example_project_id = project.example_id;
      entry.example_status = "example_accepted";
    }
    return entry;
  }

  function addMilestone(body: Record<string, unknown>): Milestone {
    const project = findRecord(state.example_projects, body.example_project_id, "project");
    const title = requiredText(body.example_title, "Milestone title", 100);
    const description = requiredText(body.example_description, "Milestone description", 800);
    const due = dateValue(body.example_due_date, "due date");
    const milestone: Milestone = {
      example_id: nextId("milestone"),
      example_project_id: project.example_id,
      example_title: title,
      example_description: description,
      example_due_date: due,
      example_status: "example_planned",
      example_created_at: nextTime(),
    };
    state.example_milestones.push(milestone);
    return milestone;
  }

  function addDelivery(body: Record<string, unknown>): Delivery {
    const milestone = findRecord(state.example_milestones, body.example_milestone_id, "milestone");
    if (milestone.example_status !== "example_in_progress") {
      throw new ApiError(409, "Start the milestone before submitting a delivery.");
    }
    const title = requiredText(body.example_title, "Delivery title", 100);
    const notes = requiredText(body.example_release_notes, "Release notes", 800);
    const preview = requiredText(body.example_preview, "Preview text", 1600);
    const delivery: Delivery = {
      example_id: nextId("delivery"),
      example_milestone_id: milestone.example_id,
      example_title: title,
      example_release_notes: notes,
      example_preview: preview,
      example_status: "example_submitted",
      example_submitted_at: nextTime(),
      example_comments: [],
    };
    state.example_deliveries.push(delivery);
    milestone.example_status = "example_in_review";
    return delivery;
  }

  function reviewDelivery(actor: User, delivery: Delivery, body: Record<string, unknown>): Delivery {
    const milestone = findRecord(state.example_milestones, delivery.example_milestone_id, "milestone");
    const project = findRecord(state.example_projects, milestone.example_project_id, "project");
    if (project.example_client_id !== actor.example_id) {
      throw new ApiError(403, "Only the project's client can review this delivery.");
    }
    const action = body.example_action;
    if (action !== "example_comment" && action !== "example_request_changes" && action !== "example_approve") {
      throw new ApiError(400, "Choose a valid review action.");
    }
    if (delivery.example_status !== "example_submitted" || milestone.example_status !== "example_in_review") {
      throw new ApiError(409, "This delivery has already been reviewed.");
    }
    const value = body.example_note;
    const hasOptionalNote = value != null && (typeof value !== "string" || Boolean(value.trim()));
    const note = action !== "example_approve" || hasOptionalNote ? requiredText(value, "Review note", 800) : null;
    if (note) {
      delivery.example_comments.push({
        example_id: nextId("comment"),
        example_author_id: actor.example_id,
        example_text: note,
        example_kind: action,
        example_created_at: nextTime(),
      });
    }
    if (action === "example_request_changes") {
      delivery.example_status = "example_changes_requested";
      milestone.example_status = "example_in_progress";
    } else if (action === "example_approve") {
      delivery.example_status = "example_approved";
      milestone.example_status = "example_approved";
    }
    return delivery;
  }

  return async function handle(request: Request): Promise<Response> {
    try {
      const actor = state.example_users.find((user) => user.example_id === request.headers.get("x-example-actor"));
      if (!actor) throw new ApiError(403, "Select a valid demo identity.");
      const { pathname } = new URL(request.url);
      switch (`${request.method} ${pathname}`) {
        case "GET /api/example_workspace":
          return json(snapshot(state, actor));
        case "POST /api/example_requests":
          requireRole(actor, "example_client", "Switch to a client to submit a request.");
          return json(addRequest(actor, await readBody(request)), 201);
        case "POST /api/example_milestones":
          requireRole(actor, "example_freelancer", "Switch to the freelancer to add milestones.");
          return json(addMilestone(await readBody(request)), 201);
        case "POST /api/example_deliveries":
          requireRole(actor, "example_freelancer", "Switch to the freelancer to submit a delivery.");
          return json(addDelivery(await readBody(request)), 201);
      }

      const match = pathname.match(/^\/api\/(example_requests|example_milestones|example_deliveries)\/([^/]+)$/);
      if (request.method !== "PATCH" || !match) throw new ApiError(404, "This portal endpoint was not found.");
      const [, collection, id] = match;
      if (collection === "example_requests") {
        requireRole(actor, "example_freelancer", "Switch to the freelancer to decide requests.");
        const body = await readBody(request);
        const entry = findRecord(state.example_requests, id, "request");
        return json(decideRequest(entry, body.example_action));
      }
      if (collection === "example_milestones") {
        requireRole(actor, "example_freelancer", "Switch to the freelancer to start a milestone.");
        const body = await readBody(request);
        const milestone = findRecord(state.example_milestones, id, "milestone");
        if (body.example_action !== "example_start") throw new ApiError(400, "Choose a valid milestone action.");
        if (milestone.example_status !== "example_planned") throw new ApiError(409, "Only a planned milestone can be started.");
        milestone.example_status = "example_in_progress";
        return json(milestone);
      }
      requireRole(actor, "example_client", "Switch to the client to review a delivery.");
      const body = await readBody(request);
      const delivery = findRecord(state.example_deliveries, id, "delivery");
      return json(reviewDelivery(actor, delivery, body));
    } catch (error) {
      if (error instanceof ApiError) return json({ example_error: error.message }, error.status);
      throw error;
    }
  };
}
