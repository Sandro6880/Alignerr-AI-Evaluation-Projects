import { useCallback, useEffect, useRef, useState } from "react";

import { get } from "./api-client";
import { clientId, type Page, type User, type Workspace } from "./domain";
import { Deliveries, Milestones, Requests } from "./ui/FlowViews";
import { Overview, Projects } from "./ui/OverviewProjects";

const pages: { id: Page; label: string; icon: string }[] = [
  { id: "overview", label: "Overview", icon: "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z" },
  { id: "requests", label: "Requests", icon: "M6 3h12v18H6zM9 8h6M9 12h6M9 16h4" },
  { id: "projects", label: "Projects", icon: "M3 6h7l2 2h9v11H3zM3 10h18" },
  { id: "milestones", label: "Milestones", icon: "M4 6h16M4 12h16M4 18h16M8 3v6M16 9v6M10 15v6" },
  { id: "deliveries", label: "Delivery review", icon: "M4 6h16v14H4zM4 10h16M8 6V3h8v3M9 15l2 2 4-4" },
];

function Icon({ path }: { path: string }) {
  return <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"
    strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={path} /></svg>;
}

export default function App() {
  const [actorId, setActorId] = useState(clientId);
  const [identities, setIdentities] = useState<User[]>([]);
  const [page, setPage] = useState<Page>("overview");
  const [projectId, setProjectId] = useState("");
  const [snapshot, setSnapshot] = useState<{ actorId: string; workspace: Workspace } | null>(null);
  const [loadError, setLoadError] = useState("");
  const currentActor = useRef(actorId);
  const requestVersion = useRef(0);

  const refresh = useCallback(async (identity: string) => {
    if (identity !== currentActor.current) return;
    const version = ++requestVersion.current;
    setLoadError("");
    try {
      const workspace = await get<Workspace>("example_workspace", identity);
      if (version === requestVersion.current) {
        setIdentities(workspace.example_users);
        setSnapshot({ actorId: identity, workspace });
      }
    } catch (error) {
      if (version === requestVersion.current) {
        setLoadError(error instanceof Error ? error.message : "Could not load the workspace.");
      }
    }
  }, []);

  useEffect(() => {
    void refresh(actorId);
    return () => { requestVersion.current += 1; };
  }, [actorId, refresh]);

  function switchIdentity(next: string) {
    if (next === actorId) return;
    currentActor.current = next;
    requestVersion.current += 1;
    setSnapshot(null);
    setLoadError("");
    setActorId(next);
  }

  const actor = identities.find((user) => user.example_id === actorId);
  const workspace = snapshot?.actorId === actorId ? snapshot.workspace : null;
  const selectedProject = workspace?.example_projects.some((project) => project.example_id === projectId) ? projectId : "";

  function navigate(next: Page, project?: string) {
    if (project !== undefined) setProjectId(project);
    setPage(next);
    window.scrollTo(0, 0);
  }

  function renderPage() {
    if (!workspace || !actor) return null;
    const props = {
      workspace, actor, projectId: selectedProject, onProject: setProjectId,
      onChanged: () => refresh(actorId), onNavigate: navigate,
    };
    switch (page) {
      case "overview": return <Overview key={actorId} {...props} />;
      case "requests": return <Requests key={actorId} {...props} />;
      case "projects": return <Projects key={actorId} {...props} />;
      case "milestones": return <Milestones key={actorId} {...props} />;
      case "deliveries": return <Deliveries key={actorId} {...props} />;
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <span className="brand-mark"><Icon path="M4 7h16v13H4zM8 7V4h8v3M4 12h16M10 12v3h4v-3" /></span>
          <div className="brand-text">Freelance Portal<small>Projects and delivery</small></div>
        </div>
        <p className="nav-label">Workspace</p>
        <nav className="sidebar-nav" aria-label="Project navigation">
          {pages.map((item) => (
            <button type="button" key={item.id} className={`nav-item ${item.id === page ? "is-active" : ""}`}
              aria-current={item.id === page ? "page" : undefined} onClick={() => navigate(item.id)}>
              <Icon path={item.icon} /><span>{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <p className="demo-note"><strong>Demo workspace</strong><br />Refreshing the page restores example records.</p>
        </div>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <div className="topbar-title">Project and delivery workspace
            <small>{actor?.example_role === "example_freelancer" ? "Freelancer view" : "Client view"}</small>
          </div>
          <label className="identity-switch">
            <span>Demo identity</span>
            <select name="example_actor_id" aria-label="Demo identity" value={actorId} disabled={!identities.length}
              onChange={(event) => switchIdentity(event.currentTarget.value)}>
              {identities.length ? identities.map((user) => (
                <option value={user.example_id} key={user.example_id}>
                  {user.example_name} · {user.example_role === "example_freelancer" ? "Freelancer" : "Client"}
                </option>
              )) : <option value={clientId}>Loading identities…</option>}
            </select>
          </label>
        </header>

        <main className="main-content">
          {!workspace && !loadError && <p className="notice" role="status">Loading the workspace…</p>}
          {loadError && (
            <div className="notice notice-error" role="alert">
              <span>{loadError}</span>
              <button className="button button-secondary" type="button" onClick={() => void refresh(actorId)}>Retry</button>
            </div>
          )}
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
