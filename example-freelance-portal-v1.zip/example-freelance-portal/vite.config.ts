import type { IncomingMessage, ServerResponse } from "node:http";
import { defineConfig } from "vite";
import type { Plugin } from "vite";
import { createMockApi } from "./src/mock/api";

const MAX_SESSIONS = 64;
const MAX_BODY_BYTES = 64 * 1024;

function mockApiPlugin(): Plugin {
  const sessions = new Map<string, ReturnType<typeof createMockApi>>();

  function apiForSession(session: string) {
    let api = sessions.get(session);
    if (api) {
      sessions.delete(session);
    } else {
      api = createMockApi();
      if (sessions.size === MAX_SESSIONS) {
        const oldest = sessions.keys().next().value;
        if (oldest !== undefined) sessions.delete(oldest);
      }
    }
    sessions.set(session, api);
    return api;
  }

  function writeError(response: ServerResponse, status: number, message: string) {
    response.writeHead(status, {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    });
    response.end(JSON.stringify({ example_error: message }));
  }

  async function handle(request: IncomingMessage, response: ServerResponse, url: URL) {
    const session = request.headers["x-example-session"];
    if (typeof session !== "string" || !/^example_session_[a-zA-Z0-9-]{8,64}$/.test(session)) {
      writeError(response, 400, "Start a valid demo session before using the mock API.");
      return;
    }

    const method = request.method ?? "GET";
    let body: string | undefined;
    if (method === "POST" || method === "PATCH") {
      const chunks: Buffer[] = [];
      let size = 0;
      for await (const chunk of request.iterator({ destroyOnReturn: false })) {
        size += chunk.length;
        if (size > MAX_BODY_BYTES) {
          request.resume();
          writeError(response, 413, "The request is too large.");
          return;
        }
        chunks.push(chunk);
      }
      body = Buffer.concat(chunks).toString("utf8");
    }

    const actor = request.headers["x-example-actor"];
    const mockRequest = new Request(url, {
      method,
      headers: { "x-example-actor": typeof actor === "string" ? actor : "" },
      body,
    });
    const mockResponse = await apiForSession(session)(mockRequest);
    response.writeHead(mockResponse.status, Object.fromEntries(mockResponse.headers));
    response.end(await mockResponse.text());
  }

  function middleware(request: IncomingMessage, response: ServerResponse, next: () => void) {
    const url = new URL(request.url ?? "/", "http://example_mock_api.invalid");
    if (!url.pathname.startsWith("/api/")) {
      next();
      return;
    }
    void handle(request, response, url).catch(() => {
      if (!response.headersSent) writeError(response, 500, "The mock request could not be completed.");
      else response.end();
    });
  }

  return {
    name: "example-freelance-mock-api",
    configureServer(server) {
      server.middlewares.use(middleware);
    },
    configurePreviewServer(server) {
      server.middlewares.use(middleware);
    },
  };
}

export default defineConfig({
  plugins: [mockApiPlugin()],
  server: { allowedHosts: ["terminal.local"] },
});
