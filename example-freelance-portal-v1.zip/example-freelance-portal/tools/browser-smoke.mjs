import assert from "node:assert/strict";
import { once } from "node:events";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { createServer } from "vite";

const title = "example_Browser smoke project";
const milestone = "example_Browser smoke milestone";
const delivery = "example_Browser smoke delivery";
const review = "example_Preview confirmed in the demo.";
const server = await createServer({
  root: fileURLToPath(new URL("../", import.meta.url)),
  server: { hmr: false },
  logLevel: "warn",
});
let browser;

try {
  assert.ok(server.httpServer, "The mock API needs an HTTP server.");
  const listening = once(server.httpServer, "listening");
  server.httpServer.listen(0, "127.0.0.1");
  await listening;
  const address = server.httpServer.address();
  assert.ok(address && typeof address === "object");

  browser = await chromium.launch({ executablePath: process.env.EXAMPLE_CHROMIUM_EXECUTABLE || undefined });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  page.setDefaultTimeout(10_000);
  await page.goto(`http://127.0.0.1:${address.port}/`);

  const button = (name) => page.getByRole("button", { name, exact: true });
  const textBox = (name) => page.getByRole("textbox", { name, exact: true });
  const select = (name) => page.getByRole("combobox", { name, exact: true });
  const card = (name) => page.getByRole("article", { name, exact: true });
  const status = (text) => page.getByRole("status").getByText(text, { exact: true }).waitFor();

  await button("Requests").click();
  await button("New request").click();
  await textBox("Request title").fill(title);
  await textBox("Brief").fill("example_Build a small demo handover.");
  await page.getByLabel("Target date", { exact: true }).fill("2026-12-03");
  await button("Submit request").click();
  await status("Request submitted.");

  await select("Demo identity").selectOption("example_freelancer_01");
  await card(title).getByRole("button", { name: "Accept request", exact: true }).click();
  await status("Request accepted. Project created.");
  await button("Milestones").click();
  await select("Project").selectOption({ label: title });
  await button("Add milestone").click();
  await textBox("Milestone title").fill(milestone);
  await textBox("Description").fill("example_Show the delivery preview.");
  await page.getByLabel("Due date", { exact: true }).fill("2026-11-27");
  await button("Create milestone").click();
  await status("Milestone created.");
  await card(milestone).getByRole("button", { name: "Start milestone", exact: true }).click();
  await status("Milestone started.");

  await button("Delivery review").click();
  await select("Project").selectOption({ label: title });
  await button("Submit delivery").click();
  await select("Milestone").selectOption({ label: milestone });
  await textBox("Delivery title").fill(delivery);
  await textBox("Release notes").fill("example_Demo release notes.");
  await textBox("Preview text").fill("example_Ready for review.");
  await button("Publish delivery").click();
  await status("Delivery submitted for review.");

  await select("Demo identity").selectOption("example_client_01");
  await select("Project").selectOption({ label: title });
  await card(delivery).getByRole("textbox", { name: "Review note", exact: true }).fill(review);
  await card(delivery).getByRole("button", { name: "Post comment", exact: true }).click();
  await card(delivery).getByText(review, { exact: true }).waitFor();
  await card(delivery).getByRole("button", { name: "Approve delivery", exact: true }).click();
  await status("Delivery approved. Milestone completed.");
  await button("Milestones").click();
  await select("Project").selectOption({ label: title });
  await card(milestone).getByText("Approved", { exact: true }).waitFor();
  await button("Projects").click();
  await page.getByRole("region", { name: "Project details", exact: true }).getByText("1 / 1 approved", { exact: true }).waitFor();

  await page.reload();
  await button("Requests").click();
  await button("New request").waitFor();
  assert.equal(await card(title).count(), 0, "A refresh restores the seed.");

  await page.setViewportSize({ width: 390, height: 844 });
  await button("Projects").click();
  await page.getByRole("heading", { name: "Projects", exact: true }).waitFor();
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  console.log("Freelance portal browser smoke test passed.");
} finally {
  try {
    await browser?.close();
  } finally {
    await server.close();
  }
}
