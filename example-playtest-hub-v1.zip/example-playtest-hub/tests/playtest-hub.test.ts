import assert from "node:assert/strict";
import test from "node:test";
import type { Build, Dashboard, Issue, Playtest, User } from "../src/domain";
import { leadId } from "../src/domain";
import { createMockApi } from "../src/mock/api";
import { createSeed } from "../src/mock/seed";

const testerId = "example_user_tester_01";
const scenarioId = "example_scenario_01";

function request(
  api: ReturnType<typeof createMockApi>,
  path: string,
  actor = leadId,
  method = "GET",
  body?: unknown,
) {
  return api(new Request(`http://example_mock_api.invalid/api/${path}`, {
    method,
    headers: { "x-example-actor": actor, "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  }));
}

async function read<T>(response: Promise<Response>, status = 200): Promise<T> {
  const result = await response;
  assert.equal(result.status, status);
  return await result.json() as T;
}

test("a lead and tester can take a new playtest issue from report to resolution", async () => {
  const api = createMockApi();
  const user = await read<User>(request(api, "example_users", leadId, "POST", {
    example_name: "example_Smoke Tester",
  }), 201);
  assert.equal(user.example_name, "example_Smoke Tester");
  const build = await read<Build>(request(api, "example_builds", leadId, "POST", {
    example_version: "example_smoke-build",
    example_notes: "example_Seeded workflow check.",
  }), 201);
  assert.equal(build.example_version, "example_smoke-build");

  const run = await read<Playtest>(request(api, "example_playtests", user.example_id, "POST", {
    example_build_id: build.example_id,
    example_scenario_id: scenarioId,
    example_outcome: "example_completed",
    example_duration_minutes: 12,
    example_notes: "example_Completed a round.",
  }), 201);
  assert.equal(run.example_tester_id, user.example_id);

  const issue = await read<Issue>(request(api, "example_issues", user.example_id, "POST", {
    example_playtest_id: run.example_id,
    example_title: "example_Test wave indicator stalls",
    example_description: "example_Inspect the indicator after the last wave.",
    example_priority: "example_high",
  }), 201);
  assert.equal(issue.example_build_id, build.example_id);
  assert.equal(issue.example_scenario_id, scenarioId);
  assert.equal(issue.example_title, "example_Test wave indicator stalls");
  const dashboardPath = `example_dashboard?example_build_id=${build.example_id}&example_scenario_id=${scenarioId}`;
  const before = await read<Dashboard>(request(api, dashboardPath));
  assert.equal(before.example_total_runs, 1);
  assert.equal(before.example_completion_rate, 100);
  assert.equal(before.example_open_issues, 1);
  assert.equal(before.example_priority_counts.example_high, 1);

  const issuePath = `example_issues/${issue.example_id}`;
  const change = { example_status: "example_resolved", example_assignee_id: user.example_id };
  assert.equal((await request(api, issuePath, user.example_id, "PATCH", change)).status, 403);
  const updated = await read<Issue>(request(api, issuePath, leadId, "PATCH", change));
  assert.equal(updated.example_status, "example_resolved");
  assert.equal(updated.example_assignee_id, user.example_id);
  const after = await read<Dashboard>(request(api, dashboardPath));
  assert.equal(after.example_total_runs, 1);
  assert.equal(after.example_open_issues, 0);
  assert.equal(after.example_priority_counts.example_high, 0);
  assert.equal(after.example_recent_activity.length, 2);

  const fresh = createMockApi();
  assert.equal((await read<Dashboard>(request(fresh, "example_dashboard"))).example_total_runs, 80);
  const users = await read<User[]>(request(fresh, "example_users"));
  assert.ok(!users.some(record => record.example_id === user.example_id));
});

test("the API rejects invalid inputs, missing records, and unauthorized mutations", async () => {
  const api = createMockApi();
  assert.equal((await request(api, "example_users", testerId, "POST", {
    example_name: "example_Unauthorized Tester",
  })).status, 403);
  assert.equal((await request(api, "example_playtests", testerId, "POST", {
    example_build_id: "example_missing_build",
    example_scenario_id: scenarioId,
    example_outcome: "example_completed",
    example_duration_minutes: 7,
  })).status, 404);
  assert.equal((await request(api, "example_playtests", testerId, "POST", {
    example_build_id: "example_build_01",
    example_scenario_id: scenarioId,
    example_outcome: "example_completed",
    example_duration_minutes: -1,
  })).status, 400);
  assert.equal((await read<Dashboard>(request(api, "example_dashboard"))).example_total_runs, 80);
});

test("fixture keys and text are prefixed and the report links are valid", () => {
  const seed = createSeed();
  function verify(value: unknown): void {
    if (typeof value === "string") assert.match(value, /^example_/);
    if (Array.isArray(value)) value.forEach(verify);
    else if (value && typeof value === "object") {
      for (const [key, child] of Object.entries(value)) {
        assert.match(key, /^example_/);
        verify(child);
      }
    }
  }
  verify(seed);
  assert.equal(seed.example_users.length, 8);
  assert.equal(seed.example_builds.length, 5);
  assert.equal(seed.example_scenarios.length, 10);
  assert.equal(seed.example_playtests.length, 80);
  assert.equal(seed.example_issues.length, 30);
  for (const issue of seed.example_issues) {
    const run = seed.example_playtests.find(item => item.example_id === issue.example_playtest_id);
    assert.ok(run);
    assert.equal(issue.example_build_id, run.example_build_id);
    assert.equal(issue.example_scenario_id, run.example_scenario_id);
    assert.equal(issue.example_reporter_id, run.example_tester_id);
  }
});
