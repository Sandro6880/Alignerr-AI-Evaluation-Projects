import { useEffect, useState } from "react";

import { get } from "../api-client";
import { outcomes, priorities, type Build, type Dashboard, type Scenario, type User } from "../domain";
import { Badge, DateText, Icon, type IconName } from "./shared";

interface OverviewProps {
  actor: User;
  builds: Build[];
  scenarios: Scenario[];
  users: User[];
  onOpenPlaytests: () => void;
  onOpenIssues: () => void;
  onSelectRun: (id: string) => void;
  onSelectIssue: (id: string) => void;
}

function StatCard({ label, value, caption, icon, tone }: {
  label: string;
  value: string | number;
  caption: string;
  icon: IconName;
  tone: string;
}) {
  return (
    <article className="stat-card">
      <div className="stat-head">
        <span className="stat-label">{label}</span>
        <span className={`stat-icon tone-${tone}`}><Icon name={icon} /></span>
      </div>
      <strong className="stat-value">{value}</strong>
      <p className="stat-caption">{caption}</p>
    </article>
  );
}

export function Overview({
  actor, builds, scenarios, users, onOpenPlaytests, onOpenIssues, onSelectRun, onSelectIssue,
}: OverviewProps) {
  const [buildId, setBuildId] = useState("");
  const [scenarioId, setScenarioId] = useState("");
  const [summary, setSummary] = useState<Dashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    const query: Record<string, string> = {};
    if (buildId) query.example_build_id = buildId;
    if (scenarioId) query.example_scenario_id = scenarioId;
    get<Dashboard>("example_dashboard", actor.example_id, query).then(
      (data) => {
        if (!active) return;
        setSummary(data);
        setLoading(false);
      },
      (reason: Error) => {
        if (!active) return;
        setError(reason.message);
        setLoading(false);
      },
    );
    return () => { active = false; };
  }, [actor.example_id, buildId, scenarioId, attempt]);

  return (
    <>
      <header className="page-heading">
        <div>
          <p className="eyebrow">Playtest operations</p>
          <h1>Playtest overview</h1>
          <p className="page-description">Review runs and issue health across builds and scenarios.</p>
        </div>
        <div className="page-actions">
          {actor.example_role === "example_tester" ? (
            <button className="button button-primary" onClick={onOpenPlaytests}>
              <Icon name="play" /> Open playtests
            </button>
          ) : (
            <button className="button button-primary" onClick={onOpenIssues}>
              <Icon name="issue" /> View issue board
            </button>
          )}
        </div>
      </header>

      <section className="panel filter-bar filters" aria-label="Overview filters">
        <span className="filter-label"><Icon name="filter" size={16} /> Filter workspace</span>
        <label className="field">
          <span>Build</span>
          <select name="example_build_id" aria-label="Build filter" value={buildId} onChange={(event) => setBuildId(event.target.value)}>
            <option value="">All builds</option>
            {builds.map((build) => (
              <option value={build.example_id} key={build.example_id}>{build.example_version}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Scenario</span>
          <select name="example_scenario_id" aria-label="Scenario filter" value={scenarioId} onChange={(event) => setScenarioId(event.target.value)}>
            <option value="">All scenarios</option>
            {scenarios.map((scenario) => (
              <option value={scenario.example_id} key={scenario.example_id}>{scenario.example_name}</option>
            ))}
          </select>
        </label>
        {(buildId || scenarioId) && (
          <button className="button button-quiet" onClick={() => { setBuildId(""); setScenarioId(""); }}>
            Reset filters
          </button>
        )}
      </section>

      {loading && <p className="notice" role="status">Loading overview…</p>}
      {error && (
        <div className="notice notice-error" role="alert">
          <span>{error}</span>
          <button className="button button-secondary" onClick={() => setAttempt((value) => value + 1)}>Retry</button>
        </div>
      )}
      {summary && !loading && !error && (
        <>
          <section className="stats-grid" aria-label="Playtest metrics">
            <StatCard label="Playtest runs" value={summary.example_total_runs} caption="Recorded in this view" icon="play" tone="tester" />
            <StatCard label="Completion rate" value={`${summary.example_completion_rate}%`} caption={`${summary.example_completed_runs} completed ${summary.example_completed_runs === 1 ? "run" : "runs"}`} icon="check" tone="completed" />
            <StatCard label="Open issues" value={summary.example_open_issues} caption="Awaiting resolution" icon="issue" tone="medium" />
            <StatCard label="Critical issues" value={summary.example_priority_counts.example_critical} caption="Unresolved critical reports" icon="activity" tone="critical" />
          </section>

          <div className="dashboard-grid">
            <section className="panel" aria-labelledby="activity-heading">
              <div className="panel-heading">
                <div>
                  <p className="panel-kicker">Run and issue history</p>
                  <h2 id="activity-heading">Recent activity</h2>
                </div>
                <Icon name="activity" />
              </div>
              {summary.example_recent_activity.length ? (
                <ul className="activity-list">
                  {summary.example_recent_activity.map((entry) => {
                    const isIssue = entry.example_kind === "example_issue";
                    const by = users.find((user) => user.example_id === entry.example_actor_id)?.example_name ?? entry.example_actor_id;
                    const build = builds.find((item) => item.example_id === entry.example_build_id)?.example_version ?? entry.example_build_id;
                    return (
                      <li className="activity-item" key={entry.example_id}>
                        <span className={`activity-icon tone-${isIssue ? "medium" : "tester"}`}>
                          <Icon name={isIssue ? "issue" : "play"} size={16} />
                        </span>
                        <div className="activity-detail">
                          <button
                            className="link-button"
                            onClick={() => (isIssue ? onSelectIssue : onSelectRun)(entry.example_id)}
                          >
                            {entry.example_label}
                          </button>
                          <span className="muted">{by} · {build}</span>
                        </div>
                        <span className="muted activity-time"><DateText value={entry.example_at} /></span>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p className="empty-state">No activity matches these filters.</p>
              )}
            </section>

            <section className="panel" aria-labelledby="outcomes-heading">
              <div className="panel-heading">
                <div>
                  <p className="panel-kicker">Run distribution</p>
                  <h2 id="outcomes-heading">Playtest outcomes</h2>
                </div>
                <Icon name="layers" />
              </div>
              <div className="panel-body outcome-bars">
                {outcomes.map((outcome) => {
                  const count = summary.example_outcome_counts[outcome];
                  const width = summary.example_total_runs ? (count / summary.example_total_runs) * 100 : 0;
                  return (
                    <div className="outcome-row" key={outcome}>
                      <div><Badge value={outcome} /><strong>{count}</strong></div>
                      <div className="bar-track" aria-hidden="true">
                        <div className={`bar-fill tone-${outcome.slice("example_".length)}`} style={{ width: `${width}%` }} />
                      </div>
                    </div>
                  );
                })}
                <div className="priority-breakdown">
                  <h3>Unresolved issues by priority</h3>
                  <ul className="priority-list">
                    {[...priorities].reverse().map((priority) => (
                      <li key={priority}><Badge value={priority} /><strong>{summary.example_priority_counts[priority]}</strong></li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>
          </div>
        </>
      )}
    </>
  );
}
