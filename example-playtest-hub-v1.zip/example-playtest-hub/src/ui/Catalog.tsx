import { useState, type FormEvent } from "react";

import { post } from "../api-client";
import type { Build, Scenario, User } from "../domain";
import { Badge, DateText, Icon } from "./shared";

interface CatalogProps {
  actor: User;
  builds: Build[];
  scenarios: Scenario[];
  onChanged: () => void;
}

export function Catalog({ actor, builds, scenarios, onChanged }: CatalogProps) {
  const [tab, setTab] = useState<"builds" | "scenarios">("builds");
  const [selectedBuild, setSelectedBuild] = useState("");
  const [selectedScenario, setSelectedScenario] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState("");
  const lead = actor.example_role === "example_lead";
  const build = builds.find((item) => item.example_id === selectedBuild) ?? builds[0];
  const scenario = scenarios.find((item) => item.example_id === selectedScenario) ?? scenarios[0];

  async function submitBuild(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    setCreated("");
    try {
      const result = await post<Build>("example_builds", actor.example_id, {
        example_version: fields.get("example_version"),
        example_notes: fields.get("example_notes"),
      });
      setSelectedBuild(result.example_id);
      setCreated(result.example_version);
      setShowForm(false);
      onChanged();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not create the build.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <header className="page-heading">
        <div>
          <p className="eyebrow">Test catalog</p>
          <h1>Builds & scenarios</h1>
          <p className="page-description">Review candidate builds and the scenarios testers can run against them.</p>
        </div>
        {lead && (
          <div className="page-actions">
            <button className="button button-primary" onClick={() => { setTab("builds"); setShowForm(true); setError(""); setCreated(""); }}>
              <Icon name="plus" /> Add build
            </button>
          </div>
        )}
      </header>

      {created && <p className="notice notice-success" role="status">Created {created}.</p>}
      {showForm && lead && (
        <section className="panel form-panel" aria-labelledby="build-form-heading">
          <div className="panel-heading">
            <h2 id="build-form-heading">Add build</h2>
            <Icon name="box" />
          </div>
          <form className="panel-body" onSubmit={submitBuild}>
            <div className="form-grid">
              <label className="field">
                <span>Build version</span>
                <input name="example_version" required maxLength={58} placeholder="example_v0.9.0" />
              </label>
              <label className="field">
                <span>Release notes</span>
                <textarea name="example_notes" maxLength={1008} rows={3} placeholder="example_Short note about what changed" />
              </label>
            </div>
            {error && <p className="notice notice-error" role="alert">{error}</p>}
            <div className="form-actions">
              <button type="button" className="button button-secondary" disabled={saving} onClick={() => setShowForm(false)}>Cancel</button>
              <button className="button button-primary" disabled={saving}>{saving ? "Creating…" : "Create build"}</button>
            </div>
          </form>
        </section>
      )}

      <div className="catalog-tabs" aria-label="Catalog sections">
        <button className={`catalog-tab ${tab === "builds" ? "is-active" : ""}`} aria-pressed={tab === "builds"} onClick={() => setTab("builds")}>
          <Icon name="box" size={17} /> Builds <span className="nav-count">{builds.length}</span>
        </button>
        <button className={`catalog-tab ${tab === "scenarios" ? "is-active" : ""}`} aria-pressed={tab === "scenarios"} onClick={() => setTab("scenarios")}>
          <Icon name="layers" size={17} /> Scenarios <span className="nav-count">{scenarios.length}</span>
        </button>
      </div>

      <div className="catalog-layout">
        <section className="panel" aria-labelledby="catalog-list-heading">
          <div className="panel-heading"><h2 id="catalog-list-heading">{tab === "builds" ? "Build catalog" : "Scenario library"}</h2></div>
          {tab === "builds" ? (
            builds.length ? (
              <ul className="catalog-list">
                {builds.map((item) => (
                  <li key={item.example_id}>
                    <button className={`catalog-list-item ${build?.example_id === item.example_id ? "is-active" : ""}`} aria-pressed={build?.example_id === item.example_id} onClick={() => setSelectedBuild(item.example_id)}>
                      <span><strong>{item.example_version}</strong><span className="muted"><DateText value={item.example_created_at} /></span></span>
                      <Icon name="chevron" size={16} />
                    </button>
                  </li>
                ))}
              </ul>
            ) : <p className="empty-state">No builds yet.</p>
          ) : (
            scenarios.length ? (
              <ul className="catalog-list">
                {scenarios.map((item) => (
                  <li key={item.example_id}>
                    <button className={`catalog-list-item ${scenario?.example_id === item.example_id ? "is-active" : ""}`} aria-pressed={scenario?.example_id === item.example_id} onClick={() => setSelectedScenario(item.example_id)}>
                      <span><strong>{item.example_name}</strong><span className="muted">{item.example_category}</span></span>
                      <Icon name="chevron" size={16} />
                    </button>
                  </li>
                ))}
              </ul>
            ) : <p className="empty-state">No scenarios yet.</p>
          )}
        </section>

        <section className="panel catalog-detail" aria-labelledby="catalog-detail-heading">
          <div className="panel-heading"><h2 id="catalog-detail-heading">{tab === "builds" ? "Build details" : "Scenario details"}</h2></div>
          {tab === "builds" && build && (
            <div className="panel-body catalog-summary">
              <p className="record-label mono">{build.example_id}</p>
              <h3 className="item-title">{build.example_version}</h3>
              <p className="muted"><DateText value={build.example_created_at} /></p>
              <h4>Release notes</h4>
              <p>{build.example_notes ?? "No release notes were provided."}</p>
            </div>
          )}
          {tab === "scenarios" && scenario && (
            <div className="panel-body catalog-summary">
              <p className="record-label mono">{scenario.example_id}</p>
              <h3 className="item-title">{scenario.example_name}</h3>
              <Badge value={scenario.example_category} />
              <h4>Test instructions</h4>
              <p>{scenario.example_instructions}</p>
            </div>
          )}
          {((tab === "builds" && !build) || (tab === "scenarios" && !scenario)) && (
            <p className="empty-state">Select a record to see its details.</p>
          )}
        </section>
      </div>
    </>
  );
}
