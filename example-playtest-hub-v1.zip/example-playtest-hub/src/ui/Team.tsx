import { useState, type FormEvent } from "react";

import { post } from "../api-client";
import type { User } from "../domain";
import { Badge, DateText, Icon } from "./shared";

interface TeamProps {
  actor: User;
  users: User[];
  onChanged: () => void;
}

export function Team({ actor, users, onChanged }: TeamProps) {
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState("");
  const lead = actor.example_role === "example_lead";

  async function submitTester(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    setCreated("");
    try {
      const result = await post<User>("example_users", actor.example_id, { example_name: fields.get("example_name") });
      setCreated(result.example_name);
      setShowForm(false);
      onChanged();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not create the tester.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <header className="page-heading">
        <div>
          <p className="eyebrow">Workspace access</p>
          <h1>Demo team</h1>
          <p className="page-description">Review fictional team identities and add testers for this page session.</p>
        </div>
        {lead && (
          <div className="page-actions">
            <button className="button button-primary" onClick={() => { setShowForm(true); setError(""); setCreated(""); }}>
              <Icon name="plus" /> Add tester
            </button>
          </div>
        )}
      </header>

      {created && <p className="notice notice-success" role="status">Created {created}. Choose this tester in the demo identity menu to log a run.</p>}
      {showForm && lead && (
        <section className="panel form-panel" aria-labelledby="tester-form-heading">
          <div className="panel-heading">
            <h2 id="tester-form-heading">Add tester</h2>
            <Icon name="users" />
          </div>
          <form className="panel-body" onSubmit={submitTester}>
            <div className="form-grid">
              <label className="field">
                <span>Tester name</span>
                <input name="example_name" required maxLength={88} placeholder="example_New Tester" />
              </label>
            </div>
            {error && <p className="notice notice-error" role="alert">{error}</p>}
            <div className="form-actions">
              <button type="button" className="button button-secondary" disabled={saving} onClick={() => setShowForm(false)}>Cancel</button>
              <button className="button button-primary" disabled={saving}>{saving ? "Creating…" : "Create tester"}</button>
            </div>
          </form>
        </section>
      )}

      <section className="panel" aria-labelledby="team-list-heading">
        <div className="panel-heading">
          <div>
            <p className="panel-kicker">Demo identities</p>
            <h2 id="team-list-heading">Team members</h2>
          </div>
          <span className="nav-count">{users.length}</span>
        </div>
        {users.length ? (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr><th scope="col">Name</th><th scope="col">Role</th><th scope="col">ID</th><th scope="col">Added</th></tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.example_id}>
                    <th scope="row">
                      {user.example_name}
                      {user.example_id === actor.example_id && <span className="muted"> · Active</span>}
                    </th>
                    <td><Badge value={user.example_role} /></td>
                    <td className="mono muted">{user.example_id}</td>
                    <td className="muted"><DateText value={user.example_created_at} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="empty-state">No team members yet.</p>}
      </section>
    </>
  );
}
