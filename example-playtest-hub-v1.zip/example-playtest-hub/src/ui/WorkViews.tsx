import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { get, patch, post } from "../api-client";
import {
  outcomes,
  priorities,
  statuses,
  type Build,
  type Issue,
  type Playtest,
  type Scenario,
  type User,
} from "../domain";
import { Badge, DateText, Icon } from "./shared";

interface WorkProps {
  actor: User;
  builds: Build[];
  scenarios: Scenario[];
  users: User[];
  selectedRunId?: string;
  selectedIssueId?: string;
  onSelectRun: (id: string) => void;
  onSelectIssue: (id: string) => void;
}

const noQuery: Record<string, string> = {};
const pageSize = 12;

function useRecords<T>(
  resource: "example_playtests" | "example_issues",
  actorId: string,
  query = noQuery,
) {
  const [records, setRecords] = useState<T[]>([]);
  const [pending, setPending] = useState(true);
  const [error, setError] = useState("");
  const [revision, setRevision] = useState(0);

  useEffect(() => {
    let active = true;
    setPending(true);
    setError("");
    get<T[]>(resource, actorId, query)
      .then((next) => {
        if (active) setRecords(next);
      })
      .catch((failure: unknown) => {
        if (active) setError(failure instanceof Error ? failure.message : "The request failed.");
      })
      .finally(() => {
        if (active) setPending(false);
      });
    return () => { active = false; };
  }, [resource, actorId, query, revision]);

  return { records, pending, error, reload: () => setRevision((current) => current + 1) };
}

function useSubmit() {
  const active = useRef(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    active.current = true;
    return () => { active.current = false; };
  }, []);

  async function submit<T>(request: () => Promise<T>, onSuccess: (record: T) => void) {
    setError("");
    setBusy(true);
    try {
      const record = await request();
      if (active.current) onSuccess(record);
    } catch (failure) {
      if (active.current) setError(failure instanceof Error ? failure.message : "The request failed.");
    } finally {
      if (active.current) setBusy(false);
    }
  }

  return { busy, error, submit };
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="field"><span>{label}</span>{children}</label>;
}

function TextOptions({ values }: { values: readonly string[] }) {
  return <>{values.map((value) => <option key={value} value={value}>{value}</option>)}</>;
}

function BuildOptions({ builds }: { builds: Build[] }) {
  return <>{builds.map((build) => (
    <option key={build.example_id} value={build.example_id}>{build.example_version}</option>
  ))}</>;
}

function ScenarioOptions({ scenarios }: { scenarios: Scenario[] }) {
  return <>{scenarios.map((scenario) => (
    <option key={scenario.example_id} value={scenario.example_id}>{scenario.example_name}</option>
  ))}</>;
}

function UserOptions({ users }: { users: User[] }) {
  return <>{users.map((user) => (
    <option key={user.example_id} value={user.example_id}>{user.example_name}</option>
  ))}</>;
}

function useRunFilters() {
  const [buildId, setBuildId] = useState("");
  const [scenarioId, setScenarioId] = useState("");
  return { buildId, setBuildId, scenarioId, setScenarioId };
}

type RunFilterValues = ReturnType<typeof useRunFilters>;

function RunFilters({
  filters, builds, scenarios, onChange,
}: {
  filters: RunFilterValues;
  builds: Build[];
  scenarios: Scenario[];
  onChange: () => void;
}) {
  return <>
    <Field label="Build">
      <select aria-label="Filter by build" value={filters.buildId} onChange={(event) => {
        filters.setBuildId(event.target.value);
        onChange();
      }}>
        <option value="">All builds</option>
        <BuildOptions builds={builds} />
      </select>
    </Field>
    <Field label="Scenario">
      <select aria-label="Filter by scenario" value={filters.scenarioId} onChange={(event) => {
        filters.setScenarioId(event.target.value);
        onChange();
      }}>
        <option value="">All scenarios</option>
        <ScenarioOptions scenarios={scenarios} />
      </select>
    </Field>
  </>;
}

function makeQuery(filters: Record<string, string>): Record<string, string> {
  return Object.fromEntries(Object.entries(filters).filter(([, value]) => value !== ""));
}

function PagedTable({
  headers, rows, page, setPage, count,
}: {
  headers: string[];
  rows: ReactNode;
  page: number;
  setPage: (value: number) => void;
  count: number;
}) {
  const lastPage = Math.max(1, Math.ceil(count / pageSize));
  return <>
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr>{headers.map((header) => <th key={header} scope="col">{header}</th>)}</tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
    {lastPage > 1 && (
      <div className="pagination">
        <span className="muted">Showing {(page - 1) * pageSize + 1} to {Math.min(page * pageSize, count)} of {count}</span>
        <div className="pagination-actions">
          <button className="button button-secondary" disabled={page === 1} onClick={() => setPage(page - 1)}>
            Previous
          </button>
          <button className="button button-secondary" disabled={page === lastPage} onClick={() => setPage(page + 1)}>
            Next
          </button>
        </div>
      </div>
    )}
  </>;
}

function Results({
  pending, error, count, empty, children,
}: {
  pending: boolean;
  error: string;
  count: number;
  empty: string;
  children: ReactNode;
}) {
  if (error) return <p className="notice notice-error" role="alert">{error}</p>;
  if (pending && count === 0) return <p className="empty-state" role="status">Loading records…</p>;
  if (count === 0) return <p className="empty-state">{empty}</p>;
  return <div aria-busy={pending}>{children}</div>;
}

function Detail({ label, children }: { label: string; children: ReactNode }) {
  return <div className="detail-item"><dt>{label}</dt><dd>{children}</dd></div>;
}

function DetailHeading({ id, children }: { id: string; children: ReactNode }) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => { heading.current?.focus(); }, []);
  return <h2 ref={heading} id={id} tabIndex={-1}>{children}</h2>;
}

function resolveNames(builds: Build[], scenarios: Scenario[], users: User[]) {
  return {
    build: (id: string) => builds.find((entry) => entry.example_id === id)?.example_version ?? id,
    scenario: (id: string) => scenarios.find((entry) => entry.example_id === id)?.example_name ?? id,
    user: (id: string) => users.find((entry) => entry.example_id === id)?.example_name ?? id,
  };
}

function RunForm({
  actorId, builds, scenarios, buildId, scenarioId, onSaved, onClose,
}: {
  actorId: string;
  builds: Build[];
  scenarios: Scenario[];
  buildId: string;
  scenarioId: string;
  onSaved: (run: Playtest) => void;
  onClose: () => void;
}) {
  const { busy, error, submit } = useSubmit();

  function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    void submit(() => post<Playtest>("example_playtests", actorId, {
      example_build_id: fields.get("example_build_id"),
      example_scenario_id: fields.get("example_scenario_id"),
      example_outcome: fields.get("example_outcome"),
      example_duration_minutes: Number(fields.get("example_duration_minutes")),
      example_notes: fields.get("example_notes"),
    }), onSaved);
  }

  return (
    <section className="panel form-panel" aria-labelledby="record-playtest-heading">
      <div className="panel-heading">
        <div><h2 id="record-playtest-heading">Record a playtest</h2><p className="muted">Connect the result to the exact build and test scenario.</p></div>
      </div>
      <form className="panel-body" onSubmit={save}>
        <div className="form-grid">
          <Field label="Build"><select name="example_build_id" defaultValue={buildId} required>
            <option value="">Choose a build</option><BuildOptions builds={builds} />
          </select></Field>
          <Field label="Scenario"><select name="example_scenario_id" defaultValue={scenarioId} required>
            <option value="">Choose a scenario</option><ScenarioOptions scenarios={scenarios} />
          </select></Field>
          <Field label="Outcome"><select name="example_outcome" defaultValue="example_completed">
            <TextOptions values={outcomes} />
          </select></Field>
          <Field label="Duration (minutes)"><input name="example_duration_minutes" type="number" min={1} max={1440} step={1} required /></Field>
        </div>
        <Field label="Notes"><textarea name="example_notes" rows={3} placeholder="What happened during the run?" maxLength={1000} /></Field>
        {error && <p className="notice notice-error" role="alert">{error}</p>}
        <div className="form-actions">
          <button type="button" className="button button-secondary" onClick={onClose} disabled={busy}>Cancel</button>
          <button className="button button-primary" disabled={busy}>{busy ? "Saving…" : "Save playtest"}</button>
        </div>
      </form>
    </section>
  );
}

function ReportForm({
  actorId, runId, onSaved, onClose,
}: {
  actorId: string;
  runId: string;
  onSaved: (issue: Issue) => void;
  onClose: () => void;
}) {
  const { busy, error, submit } = useSubmit();

  function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    void submit(() => post<Issue>("example_issues", actorId, {
      example_playtest_id: runId,
      example_title: fields.get("example_title"),
      example_description: fields.get("example_description"),
      example_priority: fields.get("example_priority"),
    }), onSaved);
  }

  return (
    <form className="form-panel report-form" aria-labelledby="report-issue-heading" onSubmit={save}>
      <h3 id="report-issue-heading">File an issue</h3>
      <div className="form-grid">
        <Field label="Issue title"><input name="example_title" required maxLength={120} /></Field>
        <Field label="Priority"><select name="example_priority" defaultValue="example_medium">
          <TextOptions values={priorities} />
        </select></Field>
      </div>
      <Field label="Description"><textarea name="example_description" rows={3} required maxLength={2000} /></Field>
      {error && <p className="notice notice-error" role="alert">{error}</p>}
      <div className="form-actions">
        <button type="button" className="button button-secondary" onClick={onClose} disabled={busy}>Cancel</button>
        <button className="button button-primary" disabled={busy}>{busy ? "Submitting…" : "Submit issue"}</button>
      </div>
    </form>
  );
}

function RunDetail({
  run, actor, names, onSelectIssue,
}: {
  run: Playtest;
  actor: User;
  names: ReturnType<typeof resolveNames>;
  onSelectIssue: (id: string) => void;
}) {
  const query = useMemo(() => ({
    example_build_id: run.example_build_id,
    example_scenario_id: run.example_scenario_id,
  }), [run.example_build_id, run.example_scenario_id]);
  const issues = useRecords<Issue>("example_issues", actor.example_id, query);
  const linkedIssues = issues.records.filter((issue) => issue.example_playtest_id === run.example_id);
  const [showReport, setShowReport] = useState(false);
  const [saved, setSaved] = useState("");
  const canReport = actor.example_role === "example_tester" && actor.example_id === run.example_tester_id;

  return (
    <section className="panel" aria-labelledby="run-detail-heading">
      <div className="panel-heading">
        <div>
          <DetailHeading id="run-detail-heading">Playtest details</DetailHeading>
          <p className="mono muted">{run.example_id}</p>
        </div>
        {canReport && !showReport && (
          <button className="button button-primary" onClick={() => { setSaved(""); setShowReport(true); }}>
            <Icon name="plus" size={16} /> File issue
          </button>
        )}
      </div>
      <div className="panel-body">
        <dl className="details-grid">
          <Detail label="Build">{names.build(run.example_build_id)}</Detail>
          <Detail label="Scenario">{names.scenario(run.example_scenario_id)}</Detail>
          <Detail label="Tester">{names.user(run.example_tester_id)}</Detail>
          <Detail label="Outcome"><Badge value={run.example_outcome} /></Detail>
          <Detail label="Duration">{run.example_duration_minutes} min</Detail>
          <Detail label="Recorded"><DateText value={run.example_created_at} /></Detail>
        </dl>
        {run.example_notes && <p className="record-notes">{run.example_notes}</p>}
        <div className="linked-records">
          <h3>Linked issues</h3>
          {issues.error && <p className="notice notice-error" role="alert">{issues.error}</p>}
          {issues.pending && linkedIssues.length === 0 && <p className="muted" role="status">Loading issues…</p>}
          {!issues.pending && !issues.error && linkedIssues.length === 0 && <p className="muted">No issues reported for this run.</p>}
          {linkedIssues.length > 0 && (
            <ul className="linked-record-list">
              {linkedIssues.map((issue) => (
                <li key={issue.example_id}>
                  <button className="link-button" onClick={() => onSelectIssue(issue.example_id)}>{issue.example_title}</button>
                  <Badge value={issue.example_status} />
                </li>
              ))}
            </ul>
          )}
        </div>
        {saved && <p className="notice notice-success" role="status">Issue filed. <button className="link-button" onClick={() => onSelectIssue(saved)}>View {saved}</button></p>}
        {showReport && (
          <ReportForm actorId={actor.example_id} runId={run.example_id} onClose={() => setShowReport(false)}
            onSaved={(issue) => {
              setShowReport(false);
              setSaved(issue.example_id);
              issues.reload();
            }}
          />
        )}
      </div>
    </section>
  );
}

export function PlaytestsView(props: WorkProps) {
  const { actor, builds, scenarios, users, selectedRunId, onSelectRun, onSelectIssue } = props;
  const names = resolveNames(builds, scenarios, users);
  const filters = useRunFilters();
  const [page, setPage] = useState(1);
  const [showRunForm, setShowRunForm] = useState(false);
  const [saved, setSaved] = useState("");
  const query = useMemo(() => makeQuery({
    example_build_id: filters.buildId,
    example_scenario_id: filters.scenarioId,
  }), [filters.buildId, filters.scenarioId]);
  const { records, pending, error, reload } = useRecords<Playtest>("example_playtests", actor.example_id, query);
  const selected = records.find((run) => run.example_id === selectedRunId);
  const visiblePage = Math.min(page, Math.max(1, Math.ceil(records.length / pageSize)));
  const visibleRuns = records.slice((visiblePage - 1) * pageSize, visiblePage * pageSize);
  const tester = actor.example_role === "example_tester";

  return <>
    <header className="page-heading">
      <div><p className="eyebrow">Playtest workspace</p><h1>Playtest log</h1>
        <p className="page-description">Review runs by build and scenario, and file issues against a specific playtest.</p>
      </div>
      {tester && !showRunForm && (
        <div className="page-actions"><button className="button button-primary" onClick={() => setShowRunForm(true)}>
          <Icon name="plus" size={16} /> Record playtest
        </button></div>
      )}
    </header>
    {!tester && <p className="notice">Switch to a tester identity to record a playtest or file a report.</p>}
    {saved && <p className="notice notice-success" role="status">Playtest saved. {saved}</p>}
    {tester && showRunForm && (
      <RunForm actorId={actor.example_id} builds={builds} scenarios={scenarios} buildId={filters.buildId}
        scenarioId={filters.scenarioId} onClose={() => setShowRunForm(false)} onSaved={(run) => {
          setSaved(run.example_id);
          setShowRunForm(false);
          filters.setBuildId("");
          filters.setScenarioId("");
          setPage(1);
          onSelectRun(run.example_id);
          reload();
        }}
      />
    )}
    {selected && <RunDetail key={selected.example_id} run={selected} actor={actor} names={names} onSelectIssue={onSelectIssue} />}
    <section className="panel" aria-labelledby="playtest-list-heading">
      <div className="panel-heading"><div><h2 id="playtest-list-heading">Runs</h2><p className="muted">Select a run to inspect its results and reports.</p></div></div>
      <div className="filters"><RunFilters filters={filters} builds={builds} scenarios={scenarios} onChange={() => setPage(1)} /></div>
      <Results pending={pending} error={error} count={records.length} empty="No playtests match these filters.">
        <PagedTable headers={["Scenario", "Build", "Tester", "Outcome", "Duration", "Recorded"]} page={visiblePage}
          setPage={setPage} count={records.length} rows={visibleRuns.map((run) => (
            <tr key={run.example_id} className={run.example_id === selectedRunId ? "is-selected" : undefined}>
              <th scope="row"><button className="link-button" onClick={() => onSelectRun(run.example_id)}>
                {names.scenario(run.example_scenario_id)}
              </button><span className="table-subtitle mono muted">{run.example_id}</span></th>
              <td>{names.build(run.example_build_id)}</td>
              <td>{names.user(run.example_tester_id)}</td>
              <td><Badge value={run.example_outcome} /></td>
              <td>{run.example_duration_minutes} min</td>
              <td><DateText value={run.example_created_at} /></td>
            </tr>
          ))}
        />
      </Results>
    </section>
  </>;
}

function TriageForm({
  issue, actorId, users, onSaved,
}: {
  issue: Issue;
  actorId: string;
  users: User[];
  onSaved: () => void;
}) {
  const { busy, error, submit } = useSubmit();

  function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    void submit(() => patch<Issue>("example_issues", actorId, issue.example_id, {
      example_status: fields.get("example_status"),
      example_priority: fields.get("example_priority"),
      example_assignee_id: fields.get("example_assignee_id") || null,
    }), onSaved);
  }

  return (
    <form className="form-panel triage-form" aria-labelledby="triage-heading" onSubmit={save}>
      <h3 id="triage-heading">Triage issue</h3>
      <div className="form-grid">
        <Field label="Status"><select name="example_status" defaultValue={issue.example_status}><TextOptions values={statuses} /></select></Field>
        <Field label="Priority"><select name="example_priority" defaultValue={issue.example_priority}><TextOptions values={priorities} /></select></Field>
        <Field label="Assignee"><select name="example_assignee_id" defaultValue={issue.example_assignee_id ?? ""}>
          <option value="">Unassigned</option><UserOptions users={users} />
        </select></Field>
      </div>
      {error && <p className="notice notice-error" role="alert">{error}</p>}
      <div className="form-actions"><button className="button button-primary" disabled={busy}>{busy ? "Saving…" : "Save triage"}</button></div>
    </form>
  );
}

function IssueDetail({
  issue, actor, users, names, onSelectRun, onSaved,
}: {
  issue: Issue;
  actor: User;
  users: User[];
  names: ReturnType<typeof resolveNames>;
  onSelectRun: (id: string) => void;
  onSaved: () => void;
}) {
  return (
    <section className="panel" aria-labelledby="issue-detail-heading">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Issue details</p>
          <DetailHeading id="issue-detail-heading">{issue.example_title}</DetailHeading>
          <p className="mono muted">{issue.example_id}</p>
        </div>
        <Badge value={issue.example_status} />
      </div>
      <div className="panel-body">
        <p className="record-notes">{issue.example_description}</p>
        <dl className="details-grid">
          <Detail label="Build">{names.build(issue.example_build_id)}</Detail>
          <Detail label="Scenario">{names.scenario(issue.example_scenario_id)}</Detail>
          <Detail label="Reporter">{names.user(issue.example_reporter_id)}</Detail>
          <Detail label="Priority"><Badge value={issue.example_priority} /></Detail>
          <Detail label="Assignee">{issue.example_assignee_id ? names.user(issue.example_assignee_id) : "Unassigned"}</Detail>
          <Detail label="Last updated"><DateText value={issue.example_updated_at} /></Detail>
          <Detail label="Playtest"><button className="link-button" onClick={() => onSelectRun(issue.example_playtest_id)}>{issue.example_playtest_id}</button></Detail>
        </dl>
        {actor.example_role === "example_lead" && (
          <TriageForm issue={issue} actorId={actor.example_id} users={users} onSaved={onSaved} />
        )}
      </div>
    </section>
  );
}

export function IssuesView(props: WorkProps) {
  const { actor, builds, scenarios, users, selectedIssueId, onSelectRun, onSelectIssue } = props;
  const names = resolveNames(builds, scenarios, users);
  const filters = useRunFilters();
  const [priority, setPriority] = useState("");
  const [status, setStatus] = useState("");
  const [assignee, setAssignee] = useState("");
  const [page, setPage] = useState(1);
  const [saved, setSaved] = useState("");
  const query = useMemo(() => makeQuery({
    example_build_id: filters.buildId,
    example_scenario_id: filters.scenarioId,
    example_priority: priority,
    example_status: status,
    example_assignee_id: assignee,
  }), [filters.buildId, filters.scenarioId, priority, status, assignee]);
  const { records, pending, error, reload } = useRecords<Issue>("example_issues", actor.example_id, query);
  const selected = records.find((issue) => issue.example_id === selectedIssueId);
  const visiblePage = Math.min(page, Math.max(1, Math.ceil(records.length / pageSize)));
  const visibleIssues = records.slice((visiblePage - 1) * pageSize, visiblePage * pageSize);

  return <>
    <header className="page-heading">
      <div><p className="eyebrow">Playtest workspace</p><h1>Issue board</h1>
        <p className="page-description">Inspect reports, prioritize fixes, and trace each issue to the run that produced it.</p>
      </div>
    </header>
    {saved && <p className="notice notice-success" role="status">Triage saved. {saved}</p>}
    {selected && (
      <IssueDetail key={`${selected.example_id}:${selected.example_updated_at}`} issue={selected} actor={actor} users={users}
        names={names} onSelectRun={onSelectRun} onSaved={() => { setSaved(selected.example_id); reload(); }}
      />
    )}
    <section className="panel" aria-labelledby="issue-list-heading">
      <div className="panel-heading"><div><h2 id="issue-list-heading">Reports</h2><p className="muted">Select an issue to inspect it. Testers can file reports from their own runs.</p></div></div>
      <div className="filters">
        <RunFilters filters={filters} builds={builds} scenarios={scenarios} onChange={() => setPage(1)} />
        <Field label="Priority"><select aria-label="Filter by priority" value={priority} onChange={(event) => { setPriority(event.target.value); setPage(1); }}>
          <option value="">All priorities</option><TextOptions values={priorities} />
        </select></Field>
        <Field label="Status"><select aria-label="Filter by status" value={status} onChange={(event) => { setStatus(event.target.value); setPage(1); }}>
          <option value="">All statuses</option><TextOptions values={statuses} />
        </select></Field>
        <Field label="Assignee"><select aria-label="Filter by assignee" value={assignee} onChange={(event) => { setAssignee(event.target.value); setPage(1); }}>
          <option value="">All assignees</option><option value="example_unassigned">Unassigned</option><UserOptions users={users} />
        </select></Field>
      </div>
      <Results pending={pending} error={error} count={records.length} empty="No reports match these filters.">
        <PagedTable headers={["Issue", "Build", "Priority", "Status", "Assignee", "Updated"]} page={visiblePage}
          setPage={setPage} count={records.length} rows={visibleIssues.map((issue) => (
            <tr key={issue.example_id} className={issue.example_id === selectedIssueId ? "is-selected" : undefined}>
              <th scope="row"><button className="link-button" onClick={() => onSelectIssue(issue.example_id)}>
                {issue.example_title}
              </button><span className="table-subtitle mono muted">{issue.example_id}</span></th>
              <td>{names.build(issue.example_build_id)}</td>
              <td><Badge value={issue.example_priority} /></td>
              <td><Badge value={issue.example_status} /></td>
              <td>{issue.example_assignee_id ? names.user(issue.example_assignee_id) : "Unassigned"}</td>
              <td><DateText value={issue.example_updated_at} /></td>
            </tr>
          ))}
        />
      </Results>
    </section>
  </>;
}
