import { useEffect, useState } from "react";

import { get } from "./api-client";
import { leadId, type Build, type Scenario, type User } from "./domain";
import { Catalog } from "./ui/Catalog";
import { Overview } from "./ui/Overview";
import { Team } from "./ui/Team";
import { IssuesView, PlaytestsView } from "./ui/WorkViews";
import { Icon, type IconName } from "./ui/shared";

type Page = "overview" | "catalog" | "playtests" | "issues" | "team";

const pages: { id: Page; label: string; icon: IconName }[] = [
  { id: "overview", label: "Overview", icon: "dashboard" },
  { id: "catalog", label: "Builds & scenarios", icon: "layers" },
  { id: "playtests", label: "Playtests", icon: "play" },
  { id: "issues", label: "Issue board", icon: "issue" },
  { id: "team", label: "Demo team", icon: "users" },
];

interface ReferenceData {
  users: User[];
  builds: Build[];
  scenarios: Scenario[];
}

export default function App() {
  const [actorId, setActorId] = useState(leadId);
  const [page, setPage] = useState<Page>("overview");
  const [selectedRunId, setSelectedRunId] = useState<string>();
  const [selectedIssueId, setSelectedIssueId] = useState<string>();
  const [reference, setReference] = useState<ReferenceData | null>(null);
  const [referenceError, setReferenceError] = useState("");
  const [referenceVersion, setReferenceVersion] = useState(0);

  useEffect(() => {
    let active = true;
    setReferenceError("");
    Promise.all([
      get<User[]>("example_users", actorId),
      get<Build[]>("example_builds", actorId),
      get<Scenario[]>("example_scenarios", actorId),
    ]).then(
      ([users, builds, scenarios]) => {
        if (active) setReference({ users, builds, scenarios });
      },
      (reason: Error) => {
        if (active) setReferenceError(reason.message);
      },
    );
    return () => { active = false; };
  }, [actorId, referenceVersion]);

  const actor = reference?.users.find((user) => user.example_id === actorId);
  const refresh = () => setReferenceVersion((version) => version + 1);

  function navigate(next: Page, recordId?: string) {
    setPage(next);
    setSelectedRunId(next === "playtests" ? recordId : undefined);
    setSelectedIssueId(next === "issues" ? recordId : undefined);
    window.scrollTo(0, 0);
  }

  const onSelectRun = (id: string) => navigate("playtests", id);
  const onSelectIssue = (id: string) => navigate("issues", id);

  function renderPage() {
    if (!reference || !actor) return null;

    const { users, builds, scenarios } = reference;
    const work = { actor, users, builds, scenarios, selectedRunId, selectedIssueId, onSelectRun, onSelectIssue };
    switch (page) {
      case "overview":
        return <Overview key={actorId} {...work} onOpenPlaytests={() => navigate("playtests")} onOpenIssues={() => navigate("issues")} />;
      case "catalog":
        return <Catalog key={actorId} actor={actor} builds={builds} scenarios={scenarios} onChanged={refresh} />;
      case "playtests":
        return <PlaytestsView key={actorId} {...work} />;
      case "issues":
        return <IssuesView key={actorId} {...work} />;
      case "team":
        return <Team key={actorId} actor={actor} users={users} onChanged={refresh} />;
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <span className="brand-mark"><Icon name="flask" size={22} /></span>
          <div className="brand-text">Playtest Hub<small>Studio QA workspace</small></div>
        </div>
        <p className="nav-label">Workspace</p>
        <nav className="sidebar-nav" aria-label="Workspace navigation">
          {pages.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${item.id === page ? "is-active" : ""}`}
              aria-current={item.id === page ? "page" : undefined}
              onClick={() => navigate(item.id)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <p className="demo-note"><strong>Demo workspace</strong><br />Example records reset on page refresh.</p>
        </div>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <div className="topbar-title">
            Studio workspace
            <small>{actor?.example_role === "example_tester" ? "Tester view" : "Lead view"}</small>
          </div>
          <label className="identity-switch">
            <span className="identity-avatar" aria-hidden="true"><Icon name="users" size={15} /></span>
            <span>Demo identity</span>
            <select
              name="example_actor_id"
              value={actorId}
              disabled={!reference}
              onChange={(event) => setActorId(event.target.value)}
            >
              {reference ? reference.users.map((user) => (
                <option value={user.example_id} key={user.example_id}>{user.example_name} · {user.example_role}</option>
              )) : <option value={leadId}>Loading identities…</option>}
            </select>
          </label>
        </header>

        <main className="main-content">
          {!reference && !referenceError && <p className="notice" role="status">Loading the workspace…</p>}
          {referenceError && (
            <div className="notice notice-error" role="alert">
              <span>{referenceError}</span>
              <button className="button button-secondary" onClick={refresh}>Retry</button>
            </div>
          )}
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
