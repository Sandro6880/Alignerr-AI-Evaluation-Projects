export const outcomes = ["example_completed", "example_failed", "example_abandoned"] as const;
export const priorities = ["example_low", "example_medium", "example_high", "example_critical"] as const;
export const statuses = ["example_open", "example_triaged", "example_resolved"] as const;
export const leadId = "example_user_lead";

export type Role = "example_lead" | "example_tester";
export type Outcome = (typeof outcomes)[number];
export type Priority = (typeof priorities)[number];
export type IssueStatus = (typeof statuses)[number];

export interface User {
  example_id: string;
  example_name: string;
  example_role: Role;
  example_created_at: number;
}

export interface Build {
  example_id: string;
  example_version: string;
  example_notes: string | null;
  example_created_at: number;
}

export interface Scenario {
  example_id: string;
  example_name: string;
  example_category: string;
  example_instructions: string;
}

export interface Playtest {
  example_id: string;
  example_build_id: string;
  example_scenario_id: string;
  example_tester_id: string;
  example_outcome: Outcome;
  example_duration_minutes: number;
  example_notes: string | null;
  example_created_at: number;
}

export interface Issue {
  example_id: string;
  example_playtest_id: string;
  example_build_id: string;
  example_scenario_id: string;
  example_reporter_id: string;
  example_title: string;
  example_description: string;
  example_priority: Priority;
  example_status: IssueStatus;
  example_assignee_id: string | null;
  example_created_at: number;
  example_updated_at: number;
}

export interface Activity {
  example_id: string;
  example_kind: "example_playtest" | "example_issue";
  example_label: string;
  example_build_id: string;
  example_scenario_id: string;
  example_actor_id: string;
  example_at: number;
}

export interface Dashboard {
  example_total_runs: number;
  example_completed_runs: number;
  example_completion_rate: number;
  example_open_issues: number;
  example_priority_counts: Record<Priority, number>;
  example_outcome_counts: Record<Outcome, number>;
  example_recent_activity: Activity[];
}

export interface SeedData {
  example_users: User[];
  example_builds: Build[];
  example_scenarios: Scenario[];
  example_playtests: Playtest[];
  example_issues: Issue[];
}
