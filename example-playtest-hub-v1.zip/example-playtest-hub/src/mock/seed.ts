import { leadId, priorities, statuses } from "../domain";
import type { Build, Issue, Outcome, Playtest, Scenario, SeedData, User } from "../domain";

const minute = 60_000;
const hour = 60 * minute;
const day = 24 * hour;
const october = Date.UTC(2026, 9, 1);

const testerNames = [
  "example_Rill Vossin",
  "example_Mica Sablewing",
  "example_Tovan Driftroot",
  "example_Edda Kestrelune",
  "example_Ivo Brackenspark",
  "example_Zuri Cinderwell",
  "example_Sol Arcloom",
];

const buildNotes = [
  "example_First integration build with the Hollow Array, Skywell route, and survey results screen.",
  "example_Adjusted docking cues, relay timing, and equipment slot feedback.",
  "example_Improved controller prompts and checkpoint recovery after falls.",
  "example_Rebalanced the beacon wave and revised the post-run summary layout.",
  "example_Candidate build with quieter alert transitions and revised survey objectives.",
];

const scenarioFixtures = [
  {
    example_name: "example_Hollow Array docking",
    example_category: "example_Onboarding",
    example_instructions: "example_Start a new pilot profile. Follow the approach markers, match the docking ring, and verify the launch tutorial hands off to the survey map.",
    example_estimate_minutes: 9,
    example_success_note: "example_Docking prompts cleared and the survey map opened after the handoff.",
    example_issue_title: "example_Alignment prompt remains after docking",
    example_issue_description: "example_Dock on the first pass, then open the survey map. The alignment prompt still covers the top marker until the map closes.",
  },
  {
    example_name: "example_Skywell ridge traversal",
    example_category: "example_Navigation",
    example_instructions: "example_Reach the third ridge marker, deliberately fall from the narrow crossing, and follow the restored route from the last checkpoint.",
    example_estimate_minutes: 17,
    example_success_note: "example_Fall recovery restored the ridge checkpoint and resumed the route correctly.",
    example_issue_title: "example_Ridge marker points back after checkpoint recovery",
    example_issue_description: "example_Fall after the third ridge marker. On recovery the marker points to the completed crossing instead of the next waypoint.",
  },
  {
    example_name: "example_Beacon ring defense",
    example_category: "example_Combat",
    example_instructions: "example_Defend the ring through two drone waves. Leave one drone alive long enough to test the next-wave countdown, then finish the encounter.",
    example_estimate_minutes: 23,
    example_success_note: "example_Wave counter and beacon health matched the encounter summary.",
    example_issue_title: "example_Wave counter advances with a drone still active",
    example_issue_description: "example_Leave the shield drone active outside the ring when the countdown starts. The HUD advances even though the current wave remains active.",
  },
  {
    example_name: "example_Salvage crate handoff",
    example_category: "example_Inventory",
    example_instructions: "example_Fill the equipment belt, collect a spare charge, and hand in the salvage crate. Check which slots are available after the handoff.",
    example_estimate_minutes: 14,
    example_success_note: "example_Handoff freed the crate slot and left the spare charge in the belt.",
    example_issue_title: "example_Empty equipment slot remains unavailable",
    example_issue_description: "example_Hand in a crate while the equipment belt is full. The crate disappears, but the slot still refuses another item until inventory is reopened.",
  },
  {
    example_name: "example_Quiet relay bypass",
    example_category: "example_Stealth",
    example_instructions: "example_Take the lower relay route, interrupt the middle switch, and return to the first switch after the alert fades.",
    example_estimate_minutes: 19,
    example_success_note: "example_Alert settled before the relay prompts returned.",
    example_issue_title: "example_Relay interaction flashes during alert recovery",
    example_issue_description: "example_Stand in range of the first switch as the alert fades. Its interaction label alternates between locked and ready for several seconds.",
  },
  {
    example_name: "example_Alternate controller layout",
    example_category: "example_Controls",
    example_instructions: "example_Swap the scan and dash buttons. Test both bindings in the practice lane and reopen the controls screen to compare the prompts.",
    example_estimate_minutes: 12,
    example_success_note: "example_Both bindings persisted and the practice prompts reflected the swap.",
    example_issue_title: "example_Practice prompt uses the previous scan binding",
    example_issue_description: "example_Swap scan and dash in the settings menu. The new binding works, but the practice lane still displays the original scan button.",
  },
  {
    example_name: "example_Canopy survey circuit",
    example_category: "example_Progression",
    example_instructions: "example_Collect the three survey signatures out of order. Open the objectives panel after each signature and compare the final survey total.",
    example_estimate_minutes: 21,
    example_success_note: "example_All three signatures appeared in the objectives panel regardless of collection order.",
    example_issue_title: "example_Survey total skips the first out-of-order signature",
    example_issue_description: "example_Collect the high canopy signature before the ground marker. The objective list records it, but the progress total stays unchanged until the next pickup.",
  },
  {
    example_name: "example_Reduced motion survey",
    example_category: "example_Accessibility",
    example_instructions: "example_Enable reduced motion and large HUD text before the ridge launch. Check the boost effect, objective banner, and paused map at each setting.",
    example_estimate_minutes: 15,
    example_success_note: "example_Boost effect and banners respected reduced motion and HUD text settings.",
    example_issue_title: "example_Large text wraps over the objective icon",
    example_issue_description: "example_Enable large HUD text and reach the second objective on the ridge. Its banner wraps across the icon at the narrow HUD width.",
  },
  {
    example_name: "example_Twin lift synchronization",
    example_category: "example_Co-op",
    example_instructions: "example_Activate the twin lifts with two pilots. Have the second pilot arrive late on the first attempt, then test a synchronized start.",
    example_estimate_minutes: 24,
    example_success_note: "example_Late arrival reset the lift prompts and the second attempt synchronized.",
    example_issue_title: "example_Second lift keeps a stale ready signal",
    example_issue_description: "example_Activate one lift and wait past the pairing window. The other pilot still sees the first lift as ready on the next attempt.",
  },
  {
    example_name: "example_Expedition results review",
    example_category: "example_Results",
    example_instructions: "example_Finish an expedition with one optional objective incomplete. Compare the results screen with the mission log, then reopen both screens.",
    example_estimate_minutes: 20,
    example_success_note: "example_Results preserved the objective total, elapsed time, and optional objective state.",
    example_issue_title: "example_Optional objective badge changes after reopening results",
    example_issue_description: "example_Finish without the optional survey tag and reopen results from the mission log. The optional badge appears complete in the reopened view.",
  },
];

export function createSeed(): SeedData {
  const lead: User = {
    example_id: leadId,
    example_name: "example_Nova Prismveil",
    example_role: "example_lead",
    example_created_at: october,
  };
  const testers: User[] = testerNames.map((example_name, index) => ({
    example_id: `example_user_tester_${String(index + 1).padStart(2, "0")}`,
    example_name,
    example_role: "example_tester",
    example_created_at: october + (index + 1) * hour,
  }));
  const builds: Build[] = buildNotes.map((example_notes, index) => ({
    example_id: `example_build_${String(index + 1).padStart(2, "0")}`,
    example_version: `example_0.8.${index}`,
    example_notes,
    example_created_at: october + (1 + index * 5) * day + 9 * hour,
  }));
  const scenarios: Scenario[] = scenarioFixtures.map((fixture, index) => ({
    example_id: `example_scenario_${String(index + 1).padStart(2, "0")}`,
    example_name: fixture.example_name,
    example_category: fixture.example_category,
    example_instructions: fixture.example_instructions,
  }));

  const playtests: Playtest[] = [];
  const issues: Issue[] = [];

  builds.forEach((build, buildIndex) => {
    const buildPlaytests = Array.from({ length: 16 }, (_, runIndex): Playtest => {
      // Rotate the eight available scenarios and leave two intentionally untested on each build.
      const scenarioIndex = (runIndex % 8 + buildIndex * 2) % scenarios.length;
      const scenario = scenarios[scenarioIndex];
      const fixture = scenarioFixtures[scenarioIndex];
      const tester = testers[(runIndex + buildIndex * 3) % testers.length];
      const roll = (runIndex * 7 + buildIndex * 5) % 16;

      let outcome: Outcome = "example_completed";
      let duration = fixture.example_estimate_minutes + roll % 5;
      let notes = fixture.example_success_note;
      if (roll < 2) {
        outcome = "example_abandoned";
        duration = 4 + runIndex % 4;
        notes = "example_Stopped early after attempting the checkpoint twice.";
      } else if (roll < 8 - buildIndex) {
        outcome = "example_failed";
        duration += 5;
        notes = fixture.example_issue_description;
      }

      return {
        example_id: `example_playtest_${String(buildIndex * 16 + runIndex + 1).padStart(3, "0")}`,
        example_build_id: build.example_id,
        example_scenario_id: scenario.example_id,
        example_tester_id: tester.example_id,
        example_outcome: outcome,
        example_duration_minutes: duration,
        example_notes: notes,
        example_created_at: build.example_created_at + (runIndex + 1) * 4 * hour,
      };
    });

    playtests.push(...buildPlaytests);
    const notableRuns = buildPlaytests.filter((run) => run.example_outcome !== "example_completed");
    const completedRuns = buildPlaytests.filter((run) => run.example_outcome === "example_completed");
    const reportedRuns = [...notableRuns, ...completedRuns].slice(0, 6);

    reportedRuns.forEach((run, reportIndex) => {
      const fixture = scenarioFixtures[scenarios.findIndex((scenario) => scenario.example_id === run.example_scenario_id)];
      const priority = priorities[(reportIndex + buildIndex) % priorities.length];
      const status = statuses[(reportIndex + 2 * buildIndex) % statuses.length];
      const assignedTester = testers[(reportIndex * 2 + buildIndex) % testers.length];
      const createdAt = run.example_created_at + (run.example_duration_minutes + 5) * minute;

      issues.push({
        example_id: `example_issue_${String(issues.length + 1).padStart(3, "0")}`,
        example_playtest_id: run.example_id,
        example_build_id: run.example_build_id,
        example_scenario_id: run.example_scenario_id,
        example_reporter_id: run.example_tester_id,
        example_title: fixture.example_issue_title,
        example_description: fixture.example_issue_description,
        example_priority: priority,
        example_status: status,
        example_assignee_id: status === "example_open" ? null : assignedTester.example_id,
        example_created_at: createdAt,
        example_updated_at: status === "example_open" ? createdAt : createdAt + (reportIndex + 2) * hour,
      });
    });
  });

  return {
    example_users: [lead, ...testers],
    example_builds: builds,
    example_scenarios: scenarios,
    example_playtests: playtests,
    example_issues: issues,
  };
}
