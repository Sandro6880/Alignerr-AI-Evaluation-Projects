import { outcomes, priorities, statuses } from '../domain'
import type { Activity, Build, Dashboard, Issue, Playtest, Role, SeedData, User } from '../domain'
import { createSeed } from './seed'

class MockApiError extends Error {
  constructor(readonly status: number, message: string) {
    super(message)
  }
}

function json(payload: unknown, status = 200): Response {
  return Response.json(payload, { status, headers: { 'cache-control': 'no-store' } })
}

async function readBody(request: Request): Promise<Record<string, unknown>> {
  let payload: unknown
  try {
    payload = await request.json()
  } catch {
    throw new MockApiError(400, 'Send a valid JSON request body.')
  }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new MockApiError(400, 'The request body must be a JSON object.')
  }
  return payload as Record<string, unknown>
}

function findRecord<T extends { example_id: string }>(records: T[], id: unknown, label: string): T {
  if (typeof id !== 'string' || !id.startsWith('example_')) {
    throw new MockApiError(400, `Choose a valid ${label}.`)
  }
  const record = records.find(item => item.example_id === id)
  if (!record) throw new MockApiError(404, `The selected ${label} was not found.`)
  return record
}

function choice<T extends string>(value: unknown, choices: readonly T[], label: string): T {
  const match = choices.find(item => item === value)
  if (!match) throw new MockApiError(400, `Choose a valid ${label}.`)
  return match
}

function demoText(value: unknown, label: string, limit: number): string {
  if (typeof value !== 'string') throw new MockApiError(400, `Enter ${label}.`)
  const clean = value.trim().replace(/^(?:example_\s*)+/, '').trim()
  if (!clean || clean.length > limit) {
    throw new MockApiError(400, `${label} must contain 1–${limit} characters.`)
  }
  return `example_${clean}`
}

function durationMinutes(value: unknown): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 1 || value > 1440) {
    throw new MockApiError(400, 'Duration must be a whole number from 1 to 1,440 minutes.')
  }
  return value
}

function optionalText(value: unknown, label: string, limit: number): string | null {
  if (value === undefined || value === null || (typeof value === 'string' && !value.trim())) {
    return null
  }
  return demoText(value, label, limit)
}

function requireRole(user: User, role: Role, message: string): void {
  if (user.example_role !== role) throw new MockApiError(403, message)
}

function contextFilter(state: SeedData, query: URLSearchParams) {
  const buildId = query.get('example_build_id')
  const scenarioId = query.get('example_scenario_id')
  if (buildId) findRecord(state.example_builds, buildId, 'build')
  if (scenarioId) findRecord(state.example_scenarios, scenarioId, 'scenario')

  return (record: Playtest | Issue): boolean =>
    (!buildId || record.example_build_id === buildId) &&
    (!scenarioId || record.example_scenario_id === scenarioId)
}

function filterIssues(state: SeedData, query: URLSearchParams): Issue[] {
  const matchContext = contextFilter(state, query)
  const status = query.get('example_status')
  const priority = query.get('example_priority')
  const assigneeId = query.get('example_assignee_id')

  if (status) choice(status, statuses, 'issue status')
  if (priority) choice(priority, priorities, 'issue priority')
  if (assigneeId && assigneeId !== 'example_unassigned') {
    findRecord(state.example_users, assigneeId, 'assignee')
  }

  return state.example_issues.filter(issue =>
    matchContext(issue) &&
    (!status || issue.example_status === status) &&
    (!priority || issue.example_priority === priority) &&
    (!assigneeId || (issue.example_assignee_id ?? 'example_unassigned') === assigneeId),
  )
}

function dashboard(state: SeedData, query: URLSearchParams): Dashboard {
  const matchContext = contextFilter(state, query)
  const runs = state.example_playtests.filter(matchContext)
  const issues = state.example_issues.filter(matchContext)
  const unresolved = issues.filter(issue => issue.example_status !== 'example_resolved')
  const outcomeCounts = { example_completed: 0, example_failed: 0, example_abandoned: 0 }
  const priorityCounts = { example_low: 0, example_medium: 0, example_high: 0, example_critical: 0 }
  const scenarioNames = new Map(
    state.example_scenarios.map(scenario => [scenario.example_id, scenario.example_name]),
  )

  for (const run of runs) outcomeCounts[run.example_outcome]++
  for (const issue of unresolved) priorityCounts[issue.example_priority]++

  const activity: Activity[] = [
    ...runs.map((run): Activity => ({
      example_id: run.example_id,
      example_kind: 'example_playtest',
      example_label: scenarioNames.get(run.example_scenario_id) ?? run.example_scenario_id,
      example_build_id: run.example_build_id,
      example_scenario_id: run.example_scenario_id,
      example_actor_id: run.example_tester_id,
      example_at: run.example_created_at,
    })),
    ...issues.map((issue): Activity => ({
      example_id: issue.example_id,
      example_kind: 'example_issue',
      example_label: issue.example_title,
      example_build_id: issue.example_build_id,
      example_scenario_id: issue.example_scenario_id,
      example_actor_id: issue.example_reporter_id,
      example_at: issue.example_updated_at,
    })),
  ]
  activity.sort((left, right) =>
    right.example_at - left.example_at || left.example_id.localeCompare(right.example_id),
  )

  return {
    example_total_runs: runs.length,
    example_completed_runs: outcomeCounts.example_completed,
    example_completion_rate: runs.length ? Math.round(100 * outcomeCounts.example_completed / runs.length) : 0,
    example_open_issues: unresolved.length,
    example_priority_counts: priorityCounts,
    example_outcome_counts: outcomeCounts,
    example_recent_activity: activity.slice(0, 8),
  }
}

function patchIssue(state: SeedData, id: string, body: Record<string, unknown>): Issue {
  const issue = findRecord(state.example_issues, id, 'issue')
  const allowed = ['example_status', 'example_priority', 'example_assignee_id']
  const fields = Object.keys(body)
  if (!fields.length || fields.some(field => !allowed.includes(field))) {
    throw new MockApiError(400, 'Send a status, priority, or assignee change.')
  }

  const status = 'example_status' in body
    ? choice(body.example_status, statuses, 'issue status')
    : issue.example_status
  const priority = 'example_priority' in body
    ? choice(body.example_priority, priorities, 'issue priority')
    : issue.example_priority
  let assigneeId = issue.example_assignee_id
  if ('example_assignee_id' in body) {
    assigneeId = body.example_assignee_id === null
      ? null
      : findRecord(state.example_users, body.example_assignee_id, 'assignee').example_id
  }

  // Apply changes together after validating every field.
  if (status !== issue.example_status || priority !== issue.example_priority || assigneeId !== issue.example_assignee_id) {
    Object.assign(issue, {
      example_status: status,
      example_priority: priority,
      example_assignee_id: assigneeId,
      example_updated_at: Date.now(),
    })
  }
  return issue
}

export function createMockApi(): (request: Request) => Promise<Response> {
  const state = createSeed()
  let nextId = 1
  const newId = (resource: string) => `example_${resource}_new_${String(nextId++).padStart(3, '0')}`

  return async function handleRequest(request: Request): Promise<Response> {
    try {
      const actor = state.example_users.find(user => user.example_id === request.headers.get('x-example-actor'))
      if (!actor) throw new MockApiError(403, 'Select a valid demo identity.')
      const { pathname, searchParams } = new URL(request.url)

      switch (`${request.method} ${pathname}`) {
        case 'GET /api/example_dashboard':
          return json(dashboard(state, searchParams))
        case 'GET /api/example_users':
          return json(state.example_users)
        case 'GET /api/example_builds':
          return json(state.example_builds)
        case 'GET /api/example_scenarios':
          return json(state.example_scenarios)
        case 'GET /api/example_playtests':
          return json(state.example_playtests.filter(contextFilter(state, searchParams)))
        case 'GET /api/example_issues':
          return json(filterIssues(state, searchParams))
        case 'POST /api/example_users': {
          requireRole(actor, 'example_lead', 'Only a lead can add demo testers.')
          const body = await readBody(request)
          const name = demoText(body.example_name, 'Tester name', 80)
          const user: User = {
            example_id: newId('user'),
            example_name: name,
            example_role: 'example_tester',
            example_created_at: Date.now(),
          }
          state.example_users.unshift(user)
          return json(user, 201)
        }
        case 'POST /api/example_builds': {
          requireRole(actor, 'example_lead', 'Only a lead can add builds.')
          const body = await readBody(request)
          const version = demoText(body.example_version, 'Build version', 50)
          const notes = optionalText(body.example_notes, 'Build notes', 1000)
          if (state.example_builds.some(build => build.example_version.toLowerCase() === version.toLowerCase())) {
            throw new MockApiError(409, 'That build version already exists.')
          }
          const build: Build = {
            example_id: newId('build'),
            example_version: version,
            example_notes: notes,
            example_created_at: Date.now(),
          }
          state.example_builds.unshift(build)
          return json(build, 201)
        }
        case 'POST /api/example_playtests': {
          requireRole(actor, 'example_tester', 'Switch to a tester to record a playtest.')
          const body = await readBody(request)
          const build = findRecord(state.example_builds, body.example_build_id, 'build')
          const scenario = findRecord(state.example_scenarios, body.example_scenario_id, 'scenario')
          const outcome = choice(body.example_outcome, outcomes, 'playtest outcome')
          const duration = durationMinutes(body.example_duration_minutes)
          const notes = optionalText(body.example_notes, 'Playtest notes', 1000)
          const run: Playtest = {
            example_id: newId('playtest'),
            example_build_id: build.example_id,
            example_scenario_id: scenario.example_id,
            example_tester_id: actor.example_id,
            example_outcome: outcome,
            example_duration_minutes: duration,
            example_notes: notes,
            example_created_at: Date.now(),
          }
          state.example_playtests.unshift(run)
          return json(run, 201)
        }
        case 'POST /api/example_issues': {
          requireRole(actor, 'example_tester', 'Switch to a tester to report an issue.')
          const body = await readBody(request)
          const run = findRecord(state.example_playtests, body.example_playtest_id, 'playtest')
          if (run.example_tester_id !== actor.example_id) {
            throw new MockApiError(403, 'Report an issue from one of your own playtests.')
          }
          const title = demoText(body.example_title, 'Issue title', 120)
          const description = demoText(body.example_description, 'Issue description', 2000)
          const priority = choice(body.example_priority, priorities, 'issue priority')
          const now = Date.now()
          const issue: Issue = {
            example_id: newId('issue'),
            example_playtest_id: run.example_id,
            example_build_id: run.example_build_id,
            example_scenario_id: run.example_scenario_id,
            example_reporter_id: actor.example_id,
            example_title: title,
            example_description: description,
            example_priority: priority,
            example_status: 'example_open',
            example_assignee_id: null,
            example_created_at: now,
            example_updated_at: now,
          }
          state.example_issues.unshift(issue)
          return json(issue, 201)
        }
      }

      const issuePath = pathname.match(/^\/api\/example_issues\/([^/]+)$/)
      if (request.method === 'PATCH' && issuePath) {
        requireRole(actor, 'example_lead', 'Only a lead can update issue triage.')
        const body = await readBody(request)
        return json(patchIssue(state, issuePath[1], body))
      }
      return json({ example_error: 'That mock API route does not exist.' }, 404)
    } catch (error) {
      if (error instanceof MockApiError) return json({ example_error: error.message }, error.status)
      return json({ example_error: 'The mock API could not complete the request.' }, 500)
    }
  }
}
