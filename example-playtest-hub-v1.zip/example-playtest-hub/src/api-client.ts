type Resource =
  | "example_dashboard"
  | "example_users"
  | "example_builds"
  | "example_scenarios"
  | "example_playtests"
  | "example_issues";

type Query = Record<string, string | undefined>;

const sessionBytes = crypto.getRandomValues(new Uint8Array(16));
const sessionId = `example_session_${Array.from(sessionBytes, (byte) => byte.toString(16).padStart(2, "0")).join("")}`;

async function request<T>(
  method: "GET" | "POST" | "PATCH",
  resource: Resource,
  actor: string,
  options: { id?: string; query?: Query; body?: unknown } = {},
): Promise<T> {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(options.query ?? {})) {
    if (value) params.set(key, value);
  }

  const item = options.id ? `/${encodeURIComponent(options.id)}` : "";
  const query = params.size ? `?${params}` : "";
  const response = await fetch(`/api/${resource}${item}${query}`, {
    method,
    headers: {
      "x-example-session": sessionId,
      "x-example-actor": actor,
      ...(options.body === undefined ? {} : { "content-type": "application/json" }),
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  const result = await response.json();
  if (!response.ok) {
    throw new Error(result.example_error ?? "The mock API could not complete the request.");
  }
  return result as T;
}

export function get<T>(resource: Resource, actor: string, query?: Query): Promise<T> {
  return request<T>("GET", resource, actor, { query });
}

export function post<T>(resource: Resource, actor: string, body: unknown): Promise<T> {
  return request<T>("POST", resource, actor, { body });
}

export function patch<T>(resource: Resource, actor: string, id: string, body: unknown): Promise<T> {
  return request<T>("PATCH", resource, actor, { id, body });
}
