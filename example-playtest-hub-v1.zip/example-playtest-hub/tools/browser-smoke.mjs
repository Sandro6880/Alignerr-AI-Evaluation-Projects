import assert from "node:assert/strict";
import { once } from "node:events";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { createServer } from "vite";

const tester = "example_Browser Smoke Tester";
const report = "example_Browser Smoke Report";
const server = await createServer({
  root: fileURLToPath(new URL("../", import.meta.url)),
  server: { hmr: false },
  logLevel: "warn",
});
let browser;

try {
  assert.ok(server.httpServer, "Vite must provide an HTTP server.");
  const listening = once(server.httpServer, "listening");
  server.httpServer.listen(0, "127.0.0.1");
  await listening;
  const address = server.httpServer.address();
  assert.ok(address && typeof address === "object", "Vite must listen on a TCP port.");
  browser = await chromium.launch({ executablePath: process.env.EXAMPLE_CHROMIUM_EXECUTABLE || undefined });
  const page = await browser.newPage();
  page.setDefaultTimeout(10_000);
  await page.goto(`http://127.0.0.1:${address.port}/`);

  const button = (name) => page.getByRole("button", { name, exact: true });
  const identity = page.getByRole("combobox", { name: "Demo identity", exact: true });
  await button("Demo team").click();
  await button("Add tester").click();
  await page.getByRole("textbox", { name: "Tester name", exact: true }).fill(tester);
  await button("Create tester").click();
  await identity.selectOption({ label: `${tester} · example_tester` });

  await button("Playtests").click();
  await button("Record playtest").click();
  const run = page.getByRole("region", { name: "Record a playtest", exact: true });
  await run.getByRole("combobox", { name: "Build", exact: true }).selectOption("example_build_05");
  await run.getByRole("combobox", { name: "Scenario", exact: true }).selectOption("example_scenario_03");
  await run.getByRole("spinbutton", { name: "Duration (minutes)", exact: true }).fill("14");
  await button("Save playtest").click();

  await button("File issue").click();
  const issue = page.getByRole("form", { name: "File an issue", exact: true });
  await issue.getByRole("textbox", { name: "Issue title", exact: true }).fill(report);
  await issue.getByRole("textbox", { name: "Description", exact: true }).fill("example_The example wave marker stays visible.");
  await button("Submit issue").click();
  await page.getByRole("region", { name: "Playtest details", exact: true })
    .getByRole("button", { name: report, exact: true }).click();

  await identity.selectOption("example_user_lead");
  const triage = page.getByRole("form", { name: "Triage issue", exact: true });
  await triage.getByRole("combobox", { name: "Status", exact: true }).selectOption("example_resolved");
  await button("Save triage").click();
  await page.getByRole("row").filter({ hasText: report })
    .getByText("example_resolved", { exact: true }).waitFor();

  await page.reload();
  await page.getByRole("region", { name: "Playtest metrics", exact: true })
    .getByText("80", { exact: true }).waitFor();
  assert.equal(await identity.getByRole("option", { name: `${tester} · example_tester` }).count(), 0);
  console.log("Playtest Hub browser smoke test passed.");
} finally {
  try {
    await browser?.close();
  } finally {
    await server.close();
  }
}
