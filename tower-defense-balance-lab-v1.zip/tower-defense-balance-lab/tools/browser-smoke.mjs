import { spawn } from "node:child_process";
import { once } from "node:events";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

function waitForDashboard(server) {
  return new Promise((resolve, reject) => {
    let output = "";
    const timer = setTimeout(() => finish(new Error("Timed out waiting for the dashboard.")), 10_000);

    function finish(error, url) {
      clearTimeout(timer);
      server.stdout.off("data", readOutput);
      server.off("error", finish);
      server.off("exit", handleExit);
      if (error) reject(error);
      else resolve(url);
    }

    function readOutput(chunk) {
      output += chunk;
      const match = output.match(/^Tower Defense Balance Lab at (http:\/\/127\.0\.0\.1:\d+\/)\r?\n/m);
      if (match) finish(null, match[1]);
    }

    function handleExit(code, signal) {
      finish(new Error(`The dashboard exited before startup (${signal ?? code}).`));
    }

    server.stdout.setEncoding("utf8").on("data", readOutput);
    server.once("error", finish);
    server.once("exit", handleExit);
  });
}

function expectMetric(page, label, value) {
  return page.getByRole("article").filter({ has: page.getByText(label, { exact: true }) })
    .getByText(value, { exact: true }).waitFor({ state: "visible" });
}

const server = spawn(
  process.env.PYTHON || "python",
  ["-B", "-m", "balance_lab", "serve", "--host", "127.0.0.1", "--port", "0"],
  { cwd: fileURLToPath(new URL("..", import.meta.url)), stdio: ["ignore", "pipe", "inherit"] },
);
const serverClosed = once(server, "close").catch(() => {});
let browser;
try {
  const url = await waitForDashboard(server);
  browser = await chromium.launch({ executablePath: process.env.EXAMPLE_CHROMIUM_EXECUTABLE });
  const page = await browser.newPage();
  page.setDefaultTimeout(10_000);
  await page.goto(url);
  await page.getByRole("heading", { name: "example_Two Mites" }).waitFor();

  const run = page.getByRole("button", { name: "Run comparison" });
  await run.click();
  await expectMetric(page, "Kills", "0 → 2");
  await expectMetric(page, "Leaks", "2 → 0");

  await page.getByRole("combobox", { name: "Tower for example_a", exact: true }).selectOption("");
  await page.getByText("Custom cost 0", { exact: true }).waitFor();
  await run.click();
  await expectMetric(page, "Leaks", "2 → 2");
  await expectMetric(page, "Cost", "4 → 0");
  console.log("Balance lab browser smoke test passed.");
} finally {
  try {
    await browser?.close();
  } finally {
    server.kill();
    await serverClosed;
  }
}
