const byId = (id) => document.getElementById(id);
const content = byId("example_main");
const scenarioList = byId("example_scenario_list");
const searchInput = byId("example_search");
const familySelect = byId("example_family");
const setSelect = byId("example_set");
const previousButton = byId("example_prev");
const nextButton = byId("example_next");
const pageSize = 12;

const state = {
  index: [],
  catalog: null,
  scenario: null,
  selectedId: "",
  reference: "",
  preset: "",
  placements: {},
  page: 0,
  compareRevision: 0,
  scenarioRevision: 0,
};

function element(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value !== null && value !== undefined) node.setAttribute(key, value);
  }
  node.append(...children);
  return node;
}

function svgElement(tag, attributes) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, value);
  return node;
}

function option(value, label = value) {
  return element("option", { value }, label);
}

function notice(message, error = false) {
  return element("p", { class: error ? "notice notice-error" : "notice", role: error ? "alert" : "status" }, message);
}

async function api(path, body) {
  const response = await fetch(`/api/${path}`, body === undefined ? {} : {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const details = await response.json().catch(() => ({}));
    throw new Error(details.example_error ?? `Request failed (${response.status}).`);
  }
  return response.json();
}

function renderLibrary() {
  const query = searchInput.value.trim().toLocaleLowerCase();
  const family = familySelect.value;
  const set = setSelect.value;
  const matches = state.index.filter((scenario) => {
    if (set === "example_curated" && scenario.example_is_variant) return false;
    if (set === "example_variant" && !scenario.example_is_variant) return false;
    if (family && !scenario.example_tags.includes(family)) return false;
    return !query || [
      scenario.example_name, scenario.example_description, scenario.example_id, ...scenario.example_tags,
    ].some((value) => value.toLocaleLowerCase().includes(query));
  });

  const lastPage = Math.max(0, Math.ceil(matches.length / pageSize) - 1);
  state.page = Math.min(state.page, lastPage);
  const start = state.page * pageSize;
  const entries = matches.slice(start, start + pageSize);
  const count = byId("example_count");
  count.textContent = matches.length
    ? `Showing ${start + 1}–${start + entries.length} of ${matches.length}`
    : "No scenarios match these filters.";
  byId("example_library_footer").hidden = lastPage === 0;
  previousButton.disabled = state.page === 0;
  nextButton.disabled = state.page === lastPage;

  scenarioList.replaceChildren(...entries.map((scenario) => {
    const selected = state.selectedId === scenario.example_id;
    const button = element("button", {
      class: `scenario-choice${selected ? " is-active" : ""}`,
      type: "button",
      "aria-current": selected ? "true" : null,
    },
    element("span", { class: "choice-name" }, scenario.example_name),
    element("span", { class: "choice-meta" },
      `${scenario.example_wave_count} ${scenario.example_wave_count === 1 ? "wave" : "waves"} · ${scenario.example_slot_count} ${scenario.example_slot_count === 1 ? "slot" : "slots"}`));
    button.addEventListener("click", () => { void selectScenario(scenario.example_id); });
    return element("li", {}, button);
  }));
}

for (const control of [searchInput, familySelect, setSelect]) {
  control.addEventListener(control === searchInput ? "input" : "change", () => {
    state.page = 0;
    renderLibrary();
  });
}
previousButton.addEventListener("click", () => { state.page -= 1; renderLibrary(); });
nextButton.addEventListener("click", () => { state.page += 1; renderLibrary(); });

function panel(title, meta, body) {
  return element("section", { class: "panel" },
    element("header", { class: "panel-header" },
      element("h2", {}, title),
      meta ? element("span", { class: "panel-meta" }, meta) : ""),
    element("div", { class: "panel-body" }, body));
}

function field(title, control) {
  return element("label", { class: "field", for: control.id }, element("span", {}, title), control);
}

function renderMap() {
  const map = byId("example_route_map");
  const route = state.scenario.example_route;
  const slots = Object.entries(state.scenario.example_slots);
  const points = [...route, ...slots.map(([, point]) => point)];
  const xs = points.map(([x]) => x);
  const ys = points.map(([, y]) => y);
  const minX = Math.min(...xs);
  const minY = Math.min(...ys);
  const spanX = Math.max(...xs) - minX;
  const spanY = Math.max(...ys) - minY;
  const width = 660;
  const height = 350;
  const padding = 49;
  const scale = Math.min(
    (width - padding * 2) / Math.max(spanX, 1),
    (height - padding * 2) / Math.max(spanY, 1),
  );
  const project = ([x, y]) => [
    (width - spanX * scale) / 2 + (x - minX) * scale,
    (height + spanY * scale) / 2 - (y - minY) * scale,
  ];

  const svg = svgElement("svg", {
    class: "route-map", viewBox: `0 0 ${width} ${height}`,
    role: "img", "aria-label": "Enemy route from spawn to exit with numbered build slots",
  });
  for (let x = 20; x < width; x += 25) {
    svg.append(svgElement("line", { class: "map-grid-line", x1: x, y1: 0, x2: x, y2: height }));
  }
  for (let y = 20; y < height; y += 25) {
    svg.append(svgElement("line", { class: "map-grid-line", x1: 0, y1: y, x2: width, y2: y }));
  }
  const routePoints = route.map((point) => project(point).join(",")).join(" ");
  svg.append(
    svgElement("polyline", { class: "map-path-under", points: routePoints }),
    svgElement("polyline", { class: "map-path", points: routePoints }),
  );
  [[route[0], "Spawn"], [route.at(-1), "Exit"]].forEach(([point, label]) => {
    const [x, y] = project(point);
    const marker = svgElement("circle", { class: "map-endpoint", cx: x, cy: y, r: 8 });
    const text = svgElement("text", { class: "map-endpoint-label", x, y: y + 24, "text-anchor": "middle" });
    text.textContent = label;
    svg.append(marker, text);
  });
  slots.forEach(([id, point], index) => {
    const [x, y] = project(point);
    const occupied = Boolean(state.placements[id]);
    const group = svgElement("g", {});
    const tooltip = svgElement("title", {});
    tooltip.textContent = `${id} · ${state.catalog.example_towers[state.placements[id]]?.example_name ?? "Empty"}`;
    const marker = svgElement("circle", {
      class: `map-slot${occupied ? " is-occupied" : ""}`, cx: x, cy: y, r: 12,
    });
    const label = svgElement("text", {
      class: "map-slot-label", x, y, "text-anchor": "middle", "dominant-baseline": "central",
    });
    label.textContent = String(index + 1);
    group.append(tooltip, marker, label);
    svg.append(group);
  });
  map.replaceChildren(svg);
}

function mapLegend(label, modifier) {
  return element("span", { class: `map-key ${modifier}` }, label);
}

function lineupCost() {
  return Object.values(state.placements).reduce(
    (total, towerId) => total + state.catalog.example_towers[towerId].example_cost, 0,
  );
}

function renderCost() {
  byId("example_lineup_cost").textContent = `Custom cost ${lineupCost()}`;
}

function invalidateComparison() {
  state.compareRevision += 1;
  const run = byId("example_run");
  run.disabled = false;
  run.textContent = "Run comparison";
  byId("example_results").replaceChildren(
    element("p", { class: "empty-state" }, "Run the comparison to measure this lineup against the reference."),
  );
}

function towerDetails(towerId) {
  const profile = state.catalog.example_towers[towerId];
  return profile
    ? `Cost ${profile.example_cost} · Damage ${profile.example_damage} · Range ${profile.example_range} · Cooldown ${profile.example_cooldown_ticks}`
    : "No tower placed";
}

function renderLineup() {
  const scenario = state.scenario;
  const presetIds = Object.keys(scenario.example_loadouts);
  const reference = element("select", { id: "example_reference", name: "example_reference" },
    ...presetIds.map((id) => option(id)));
  reference.value = state.reference;
  reference.addEventListener("change", () => {
    state.reference = reference.value;
    invalidateComparison();
  });

  const preset = element("select", { id: "example_preset", name: "example_preset" },
    option("", "Custom edits"), ...presetIds.map((id) => option(id)), option("example_empty", "Empty lineup"));
  preset.value = state.preset;
  const slots = element("div", { class: "slot-list" });
  const controls = Object.entries(scenario.example_slots).map(([slotId, [x, y]], index) => {
    const id = `example_slot_${index + 1}`;
    const select = element("select", { id, name: id, "aria-label": `Tower for ${slotId}` },
      option("", "Empty slot"), ...Object.entries(state.catalog.example_towers).map(([towerId, profile]) =>
        option(towerId, `${profile.example_name} · ${profile.example_cost}`)));
    select.value = state.placements[slotId] ?? "";
    const meta = element("span", { class: "slot-meta" }, towerDetails(select.value));
    const row = element("div", { class: "slot-row" },
      element("span", { class: "slot-index", "aria-hidden": "true" }, String(index + 1)),
      element("div", { class: "slot-control" },
        element("label", { class: "field", for: id },
          element("span", {}, slotId, element("small", { class: "subtle mono" }, ` (${x}, ${y})`)), select),
        meta));
    slots.append(row);
    select.addEventListener("change", () => {
      if (select.value) state.placements[slotId] = select.value;
      else delete state.placements[slotId];
      state.preset = "";
      preset.value = "";
      meta.textContent = towerDetails(select.value);
      renderCost();
      renderMap();
      invalidateComparison();
    });
    return { slotId, select, meta };
  });
  if (controls.length === 0) slots.append(element("p", { class: "empty-state" }, "This scenario has no build slots."));

  preset.addEventListener("change", () => {
    if (!preset.value) return;
    state.preset = preset.value;
    state.placements = { ...scenario.example_loadouts[state.preset] };
    for (const { slotId, select, meta } of controls) {
      select.value = state.placements[slotId] ?? "";
      meta.textContent = towerDetails(select.value);
    }
    renderCost();
    renderMap();
    invalidateComparison();
  });

  const run = element("button", { class: "button button-primary", id: "example_run", type: "button" }, "Run comparison");
  run.addEventListener("click", () => { void compare(); });
  return element("div", {},
    element("div", { class: "lineup-options" },
      field("Reference loadout", reference), field("Start from preset", preset)),
    slots,
    element("div", { class: "run-bar" },
      element("strong", { id: "example_lineup_cost", class: "loadout-cost" }), run));
}

function table(headers, rows) {
  const heading = element("thead", {},
    element("tr", {}, ...headers.map((label) => element("th", { scope: "col" }, label))));
  const body = element("tbody", {}, ...rows.map((row) =>
    element("tr", {}, ...row.map((cell) => element("td", {}, String(cell))))));
  return element("div", { class: "table-wrap" }, element("table", { class: "data-table" }, heading, body));
}

function spawnSchedule() {
  const waves = state.scenario.example_waves.flatMap((wave) =>
    wave.example_spawns.map((group) => [
      wave.example_id,
      state.catalog.example_enemies[group.example_enemy].example_name,
      group.example_count,
      group.example_start_tick,
      group.example_interval_ticks,
    ]));
  return table(["Wave", "Enemy", "Count", "Start tick", "Interval"], waves);
}

function catalogDetails() {
  const towers = Object.values(state.catalog.example_towers).map((tower) => [
    tower.example_name, tower.example_cost, tower.example_damage, tower.example_range, tower.example_cooldown_ticks,
  ]);
  const enemies = Object.values(state.catalog.example_enemies).map((enemy) => [
    enemy.example_name, enemy.example_health, enemy.example_speed,
  ]);
  return element("details", { class: "panel catalog-panel" },
    element("summary", { class: "panel-header" }, "Profile catalog"),
    element("div", { class: "panel-body details-grid" },
      element("section", {},
        element("h3", {}, "Towers"),
        table(["Tower", "Cost", "Damage", "Range", "Cooldown"], towers)),
      element("section", {},
        element("h3", {}, "Enemies"),
        table(["Enemy", "Health", "Speed"], enemies))));
}

function renderScenario() {
  const scenario = state.scenario;
  const tags = scenario.example_tags.map((tag) => element("span", { class: "tag" }, tag));
  const map = element("div", { id: "example_route_map" });
  const results = element("div", { id: "example_results" },
    element("p", { class: "empty-state" }, "Run the comparison to measure this lineup against the reference."));
  content.replaceChildren(
    element("header", { class: "scenario-header" },
      element("p", { class: "section-kicker" }, "Active scenario"),
      element("div", { class: "title-row" },
        element("h1", {}, scenario.example_name), element("div", { class: "tags" }, ...tags)),
      element("p", { class: "subtle" }, scenario.example_description)),
    element("div", { class: "experiment-grid" },
      panel("Route and build slots",
        `${scenario.example_route.length} waypoints · ${Object.keys(scenario.example_slots).length} ${Object.keys(scenario.example_slots).length === 1 ? "slot" : "slots"}`,
        element("div", {}, map, element("div", { class: "map-legend" },
          mapLegend("Enemy route", "is-route"), mapLegend("Occupied slot", "is-occupied"), mapLegend("Empty slot", "")))),
      panel("Loadout builder", "Reference vs custom", renderLineup())),
    panel("Comparison results", "Custom minus reference", results),
    panel("Spawn schedule", `${scenario.example_waves.length} ${scenario.example_waves.length === 1 ? "wave" : "waves"}`, spawnSchedule()),
    catalogDetails(),
  );
  renderMap();
  renderCost();
}

async function selectScenario(id) {
  const focusChoice = scenarioList.contains(document.activeElement);
  const revision = ++state.scenarioRevision;
  state.compareRevision += 1;
  state.scenario = null;
  state.selectedId = id;
  renderLibrary();
  if (focusChoice) scenarioList.querySelector("[aria-current='true']")?.focus({ preventScroll: true });
  content.replaceChildren(notice("Loading scenario…"));
  try {
    const scenario = await api(`example_scenarios/${encodeURIComponent(id)}`);
    if (revision !== state.scenarioRevision) return;
    state.scenario = scenario;
    const ids = Object.keys(scenario.example_loadouts);
    state.reference = ids.includes("example_baseline") ? "example_baseline" : ids[0];
    state.preset = ids.find((preset) => preset !== state.reference) ?? state.reference;
    state.placements = { ...scenario.example_loadouts[state.preset] };
    renderScenario();
  } catch (error) {
    if (revision !== state.scenarioRevision) return;
    content.replaceChildren(notice(error.message, true));
  }
}

function metricCard(label, key, preferredSign, result) {
  const delta = result.example_delta[key];
  const tone = delta === 0 || preferredSign === 0 ? "" : delta * preferredSign > 0 ? " is-good" : " is-bad";
  return element("article", { class: "metric-card" },
    element("span", { class: "subtle" }, label),
    element("strong", { class: "metric-values" }, `${result.example_left[key]} → ${result.example_right[key]}`),
    element("span", { class: `metric-delta${tone}` }, `${delta > 0 ? "+" : ""}${delta} vs reference`));
}

function resultsBody(result) {
  const left = result.example_left;
  const right = result.example_right;
  const waveRows = Object.entries(left.example_waves).map(([waveId, wave]) => [
    waveId, wave.example_spawned, wave.example_kills, right.example_waves[waveId].example_kills,
    wave.example_leaks, right.example_waves[waveId].example_leaks,
  ]);
  const slotIds = new Set([...Object.keys(left.example_towers), ...Object.keys(right.example_towers)]);
  const slotRows = [...slotIds].map((slotId) => {
    const referenceTower = left.example_towers[slotId];
    const customTower = right.example_towers[slotId];
    const name = (tower) => state.catalog.example_towers[tower?.example_tower_id]?.example_name ?? "Empty";
    return [
      slotId, name(referenceTower), name(customTower),
      referenceTower?.example_shots ?? 0, customTower?.example_shots ?? 0,
      referenceTower?.example_damage ?? 0, customTower?.example_damage ?? 0,
    ];
  });
  const summary = element("p", { class: "subtle result-context", role: "status" },
    `${left.example_loadout_id} → ${right.example_loadout_id} · ${left.example_spawned} enemies · ${left.example_ticks_elapsed} → ${right.example_ticks_elapsed} ticks`);
  return [
    summary,
    element("div", { class: "results-grid" },
      metricCard("Kills", "example_kills", 1, result),
      metricCard("Leaks", "example_leaks", -1, result),
      metricCard("Cost", "example_cost", -1, result),
      metricCard("Damage", "example_damage", 0, result)),
    element("section", { class: "comparison-detail" }, element("h3", {}, "Wave outcomes"),
      table(["Wave", "Spawned", "Reference kills", "Custom kills", "Reference leaks", "Custom leaks"], waveRows)),
    element("section", { class: "comparison-detail" }, element("h3", {}, "Tower performance"),
      slotRows.length
        ? table(["Slot", "Reference tower", "Custom tower", "Reference shots", "Custom shots", "Reference damage", "Custom damage"], slotRows)
        : element("p", { class: "subtle" }, "Neither lineup has placed towers.")),
  ];
}

async function compare() {
  const revision = ++state.compareRevision;
  const run = byId("example_run");
  const results = byId("example_results");
  run.disabled = true;
  run.textContent = "Running…";
  results.replaceChildren(notice("Running comparison…"));
  try {
    const result = await api("example_compare", {
      example_scenario_id: state.scenario.example_id,
      example_left: { example_loadout_id: state.reference },
      example_right: { example_placements: state.placements },
    });
    if (revision !== state.compareRevision) return;
    results.replaceChildren(...resultsBody(result));
  } catch (error) {
    if (revision !== state.compareRevision) return;
    results.replaceChildren(notice(error.message, true));
  } finally {
    if (revision === state.compareRevision) {
      run.disabled = false;
      run.textContent = "Run comparison";
    }
  }
}

async function boot() {
  try {
    [state.catalog, state.index] = await Promise.all([api("example_catalog"), api("example_scenarios")]);
    const families = [...new Set(state.index.flatMap((entry) => entry.example_tags))].sort();
    familySelect.append(...families.map((family) => option(family)));
    const smoke = state.index.find((entry) => entry.example_id === "example_smoke");
    if (smoke) state.index = [smoke, ...state.index.filter((entry) => entry !== smoke)];
    const first = smoke ?? state.index.find((entry) => !entry.example_is_variant) ?? state.index[0];
    if (!first) {
      renderLibrary();
      content.replaceChildren(notice("No scenarios are available.", true));
      return;
    }
    await selectScenario(first.example_id);
  } catch (error) {
    byId("example_count").textContent = "Scenario list unavailable.";
    content.replaceChildren(notice(error.message, true));
  }
}

void boot();
