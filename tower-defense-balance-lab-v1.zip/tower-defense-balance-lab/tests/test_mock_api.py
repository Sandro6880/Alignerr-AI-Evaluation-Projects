from http.client import HTTPConnection
import json
from pathlib import Path
from threading import Thread
import unittest

from balance_lab.server import create_server


ROOT = Path(__file__).resolve().parents[1]
SMOKE_ID = "example_smoke"
BASELINE_ID = "example_baseline"


class MockApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(port=0)
        cls.thread = Thread(target=cls.server.serve_forever, kwargs={"poll_interval": 0.05})
        cls.thread.start()
        cls.addClassCleanup(cls.server.server_close)
        cls.addClassCleanup(cls.thread.join)
        cls.addClassCleanup(cls.server.shutdown)

    def request(self, method, path, payload=None):
        conn = HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            body = None if payload is None else json.dumps(payload)
            conn.request(method, path, body=body, headers={"Content-Type": "application/json"})
            response = conn.getresponse()
            content = response.read()
            if response.getheader("Content-Type", "").startswith("application/json"):
                content = json.loads(content)
            return response.status, content
        finally:
            conn.close()

    def test_bundled_data_and_dashboard_are_available(self):
        status, html = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"Tower Defense", html)

        status, catalog = self.request("GET", "/api/example_catalog")
        self.assertEqual(status, 200)
        self.assertEqual(len(catalog["example_towers"]), 10)
        self.assertEqual(len(catalog["example_enemies"]), 12)

        status, scenarios = self.request("GET", "/api/example_scenarios")
        self.assertEqual(status, 200)
        self.assertEqual(len(scenarios), 264)
        self.assertEqual(sum(entry["example_is_variant"] for entry in scenarios), 240)

    def test_manual_loadout_comparison_does_not_change_the_fixtures(self):
        path = f"/api/example_scenarios/{SMOKE_ID}"
        status, before = self.request("GET", path)
        self.assertEqual(status, 200)
        status, result = self.request("POST", "/api/example_compare", {
            "example_scenario_id": SMOKE_ID,
            "example_left": {"example_loadout_id": BASELINE_ID},
            "example_right": {"example_placements": {"example_a": "example_bolt"}},
        })
        self.assertEqual(status, 200, result)
        self.assertEqual(result["example_left"]["example_leaks"], 2)
        self.assertEqual(result["example_right"]["example_leaks"], 0)
        self.assertEqual(result["example_right"]["example_waves"]["example_w1"]["example_kills"], 2)
        self.assertEqual(result["example_delta"]["example_cost"], 2)
        self.assertEqual(self.request("GET", path), (200, before))

    def test_invalid_placement_is_rejected(self):
        status, error = self.request("POST", "/api/example_simulate", {
            "example_scenario_id": SMOKE_ID,
            "example_placements": {"example_a": "example_unknown_tower"},
        })
        self.assertEqual(status, 400)
        self.assertIn("example_error", error)
        status, run = self.request("POST", "/api/example_simulate", {
            "example_scenario_id": SMOKE_ID,
            "example_loadout_id": BASELINE_ID,
        })
        self.assertEqual(status, 200)
        self.assertEqual(run["example_leaks"], 2)


class FixtureConventionTests(unittest.TestCase):
    def test_all_fixture_names_keys_and_text_are_prefixed(self):
        def check(value):
            if isinstance(value, str):
                self.assertTrue(value.startswith("example_"), value)
            elif isinstance(value, list):
                for child in value:
                    check(child)
            elif isinstance(value, dict):
                for key, child in value.items():
                    check(key)
                    check(child)

        paths = list((ROOT / "data").rglob("*.json"))
        self.assertEqual(len(paths), 265)
        for path in paths:
            with self.subTest(path=path.name):
                self.assertTrue(path.name.startswith("example_"))
                check(json.loads(path.read_text(encoding="utf-8")))
