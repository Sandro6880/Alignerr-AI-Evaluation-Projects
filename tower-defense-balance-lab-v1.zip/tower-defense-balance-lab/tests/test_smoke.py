from pathlib import Path
import unittest

from balance_lab.schema import load_catalog, load_scenario
from balance_lab.simulation import simulate


DATA_DIR = Path(__file__).resolve().parents[1] / "data"


class SmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = load_catalog(DATA_DIR / "example_catalog.json")
        cls.scenario = load_scenario(DATA_DIR / "scenarios" / "example_smoke.json", cls.catalog)

    def test_picket_leaks_both_enemies(self):
        # Each 5 HP enemy takes two 2 damage shots before leaving the route.
        result = simulate(self.catalog, self.scenario, "example_baseline")

        self.assertEqual((result.spawned, result.kills, result.leaks), (2, 0, 2))
        self.assertEqual((result.cost, result.damage, result.ticks_elapsed), (4, 8, 9))
        self.assertEqual(result.towers["example_a"].shots, 4)
        self.assertEqual(result.waves["example_w1"].leaks, 2)

    def test_bolt_stops_both_enemies(self):
        # Each 5 HP enemy takes 3 damage, then only its remaining 2 HP.
        result = simulate(self.catalog, self.scenario, "example_alternate")

        self.assertEqual((result.spawned, result.kills, result.leaks), (2, 2, 0))
        self.assertEqual((result.cost, result.damage, result.ticks_elapsed), (6, 10, 8))
        self.assertEqual(result.towers["example_a"].shots, 4)
        self.assertEqual(result.towers["example_a"].kills, 2)
        self.assertEqual(result.waves["example_w1"].kills, 2)
