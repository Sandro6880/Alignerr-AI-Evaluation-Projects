import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from balance_lab.schema import DataError, load_catalog, load_scenario, parse_catalog, parse_scenario
from balance_lab.simulation import simulate


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
CATALOG_PATH = DATA_DIR / "example_catalog.json"
SMOKE_PATH = DATA_DIR / "scenarios" / "example_smoke.json"


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "balance_lab", *args],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )


class SchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = load_catalog(CATALOG_PATH)

    def test_catalog_rejects_boolean_numeric_stats(self):
        document = read_json(CATALOG_PATH)
        document["example_towers"]["example_picket"]["example_cost"] = True

        with self.assertRaises(DataError):
            parse_catalog(document)

    def test_scenario_rejects_bad_version_route_and_tower_reference(self):
        for field, value in (
            ("example_schema_version", 2),
            ("example_route", [[0, 0], [1, 1]]),
            ("example_route", [[0, 0], [0, 0], [4, 0]]),
            ("example_loadouts", {"example_baseline": {"example_a": "example_unknown-tower"}}),
            ("example_loadouts", {"example_baseline": {"example_unknown-slot": "example_picket"}}),
        ):
            with self.subTest(field=field, value=value):
                document = read_json(SMOKE_PATH)
                document[field] = value

                with self.assertRaises(DataError):
                    parse_scenario(document, self.catalog)

    def test_scenario_rejects_invalid_spawn_groups(self):
        for field, value in (
            ("example_enemy", "example_unknown-enemy"),
            ("example_start_tick", -1),
            ("example_count", 0),
            ("example_interval_ticks", -1),
        ):
            with self.subTest(field=field, value=value):
                document = read_json(SMOKE_PATH)
                document["example_waves"][0]["example_spawns"][0][field] = value

                with self.assertRaises(DataError):
                    parse_scenario(document, self.catalog)

    def test_curated_loadouts_have_consistent_report_totals(self):
        for path in sorted((DATA_DIR / "scenarios").glob("*.json")):
            scenario = load_scenario(path, self.catalog)
            for loadout_id in scenario.loadouts:
                with self.subTest(scenario=scenario.id, loadout=loadout_id):
                    result = simulate(self.catalog, scenario, loadout_id)

                    self.assertEqual(result.spawned, result.kills + result.leaks)
                    self.assertEqual(result.spawned, sum(wave.spawned for wave in result.waves.values()))
                    self.assertEqual(result.leaks, sum(wave.leaks for wave in result.waves.values()))
                    self.assertEqual(result.kills, sum(wave.kills for wave in result.waves.values()))
                    self.assertEqual(result.kills, sum(tower.kills for tower in result.towers.values()))
                    self.assertEqual(result.damage, sum(tower.damage for tower in result.towers.values()))
                    self.assertEqual(result.cost, sum(tower.cost for tower in result.towers.values()))


class CliTests(unittest.TestCase):
    def test_simulate_json_uses_baseline_by_default(self):
        process = run_cli("simulate", str(SMOKE_PATH), "--json")

        self.assertEqual(process.returncode, 0, process.stderr)
        report = json.loads(process.stdout)
        self.assertEqual(report["example_loadout_id"], "example_baseline")
        self.assertEqual(report["example_waves"]["example_w1"], {"example_spawned": 2, "example_kills": 0, "example_leaks": 2})

    def test_compare_json_deltas_are_right_minus_left(self):
        process = run_cli("compare", str(SMOKE_PATH), "example_baseline", "example_alternate", "--json")

        self.assertEqual(process.returncode, 0, process.stderr)
        report = json.loads(process.stdout)
        self.assertEqual(report["example_left"]["example_loadout_id"], "example_baseline")
        self.assertEqual(report["example_right"]["example_loadout_id"], "example_alternate")
        self.assertEqual(report["example_delta"], {
            "example_ticks_elapsed": -1,
            "example_spawned": 0,
            "example_kills": 2,
            "example_leaks": -2,
            "example_cost": 2,
            "example_damage": 2,
        })

    def test_validate_shipped_data(self):
        process = run_cli("validate")

        self.assertEqual(process.returncode, 0, process.stderr)

    def test_bad_json_and_unknown_loadout_return_clean_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            malformed = Path(directory) / "malformed.json"
            malformed.write_text("{", encoding="utf-8")
            invalid_json = run_cli("validate", str(malformed))
        invalid_loadout = run_cli("simulate", str(SMOKE_PATH), "--loadout", "example_missing")

        for process in (invalid_json, invalid_loadout):
            self.assertEqual(process.returncode, 2)
            self.assertTrue(process.stderr.strip())
            self.assertNotIn("Traceback", process.stderr)
