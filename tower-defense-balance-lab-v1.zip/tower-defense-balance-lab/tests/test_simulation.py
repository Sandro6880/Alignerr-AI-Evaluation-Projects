import unittest

from balance_lab.schema import parse_catalog, parse_scenario
from balance_lab.simulation import simulate


def make_catalog(*, tower_range, cooldown_ticks=1):
    return parse_catalog({
        "example_schema_version": 1,
        "example_towers": {
            "example_dart": {
                "example_name": "example_Dart",
                "example_cost": 3,
                "example_damage": 6,
                "example_range": tower_range,
                "example_cooldown_ticks": cooldown_ticks,
            },
        },
        "example_enemies": {
            "example_slow": {"example_name": "example_Slow", "example_health": 5, "example_speed": 1},
            "example_fast": {"example_name": "example_Fast", "example_health": 5, "example_speed": 2},
            "example_swift": {"example_name": "example_Swift", "example_health": 5, "example_speed": 3},
        },
    })


def single_spawn(wave_id, enemy="example_slow", start_tick=0):
    return {
        "example_id": wave_id,
        "example_spawns": [{
            "example_enemy": enemy,
            "example_start_tick": start_tick,
            "example_count": 1,
            "example_interval_ticks": 0,
        }],
    }


def make_scenario(catalog, *, route, slots, loadouts, waves):
    return parse_scenario({
        "example_schema_version": 1,
        "example_id": "example_unit_case",
        "example_name": "example_Unit case",
        "example_description": "example_Small combat rules fixture",
        "example_tags": [],
        "example_route": route,
        "example_slots": slots,
        "example_loadouts": loadouts,
        "waves": waves,
    }, catalog)


class SimulationTests(unittest.TestCase):
    def test_range_includes_exact_euclidean_boundary(self):
        catalog = make_catalog(tower_range=5)
        scenario = make_scenario(
            catalog,
            route=[[0, 0], [1, 0]],
            slots={"example_boundary": [3, 4], "example_outside": [4, 4]},
            loadouts={"example_in": {"example_boundary": "example_dart"}, "example_out": {"example_outside": "example_dart"}},
            waves=[single_spawn("example_first")],
        )

        inside = simulate(catalog, scenario, "example_in")
        outside = simulate(catalog, scenario, "example_out")

        self.assertEqual((inside.kills, inside.leaks, inside.damage), (1, 0, 5))
        self.assertEqual((outside.kills, outside.leaks, outside.damage), (0, 1, 0))
        self.assertEqual(inside.ticks_elapsed, 1)
        self.assertEqual(outside.ticks_elapsed, 1)

    def test_towers_fire_by_slot_id_without_shooting_dead_targets(self):
        catalog = make_catalog(tower_range=1)
        scenario = make_scenario(
            catalog,
            route=[[0, 0], [1, 0]],
            slots={"example_z": [0, -1], "example_a": [0, 1]},
            loadouts={"example_baseline": {"example_z": "example_dart", "example_a": "example_dart"}},
            waves=[single_spawn("example_first")],
        )

        result = simulate(catalog, scenario, "example_baseline")

        self.assertEqual((result.cost, result.kills, result.damage), (6, 1, 5))
        self.assertEqual((result.towers["example_a"].shots, result.towers["example_a"].kills), (1, 1))
        self.assertEqual((result.towers["example_z"].shots, result.towers["example_z"].kills), (0, 0))

    def test_targeting_prioritizes_progress_then_earliest_spawn(self):
        catalog = make_catalog(tower_range=3, cooldown_ticks=3)
        for later_enemy, killed_wave, leaked_wave in (
            ("example_fast", "example_early", "example_late"),
            ("example_swift", "example_late", "example_early"),
        ):
            with self.subTest(later_enemy=later_enemy):
                # The first shot is at tick 0. At the next ready tick (3),
                # the early enemy is at x=2 and the late enemy at x=2 or x=3.
                scenario = make_scenario(
                    catalog,
                    route=[[0, 0], [8, 0]],
                    slots={"example_a": [1, 1]},
                    loadouts={"example_baseline": {"example_a": "example_dart"}},
                    waves=[
                        single_spawn("example_bait"),
                        single_spawn("example_early", start_tick=1),
                        single_spawn("example_late", enemy=later_enemy, start_tick=2),
                    ],
                )

                result = simulate(catalog, scenario, "example_baseline")

                self.assertEqual((result.spawned, result.kills, result.leaks), (3, 2, 1))
                self.assertEqual(result.waves["example_bait"].kills, 1)
                self.assertEqual(result.waves[killed_wave].kills, 1)
                self.assertEqual(result.waves[leaked_wave].leaks, 1)

    def test_movement_can_cross_multiple_route_corners_in_one_tick(self):
        catalog = make_catalog(tower_range=1)
        scenario = make_scenario(
            catalog,
            route=[[0, 0], [1, 0], [1, 1], [4, 1]],
            slots={"example_a": [2, 2]},
            loadouts={"example_armed": {"example_a": "example_dart"}, "example_empty": {}},
            waves=[single_spawn("example_first", enemy="example_swift")],
        )

        armed = simulate(catalog, scenario, "example_armed")
        empty = simulate(catalog, scenario, "example_empty")

        # After one tick at speed 3, the enemy is at (2, 1).
        self.assertEqual((armed.kills, armed.leaks, armed.ticks_elapsed), (1, 0, 2))
        self.assertEqual((empty.kills, empty.leaks, empty.ticks_elapsed), (0, 1, 2))
        self.assertEqual((empty.cost, empty.damage, empty.towers), (0, 0, {}))
        self.assertEqual(simulate(catalog, scenario, "example_armed"), armed)

    def test_tower_stays_ready_during_idle_ticks(self):
        catalog = make_catalog(tower_range=1, cooldown_ticks=9)
        scenario = make_scenario(
            catalog,
            route=[[0, 0], [1, 0]],
            slots={"example_a": [0, 1]},
            loadouts={"example_baseline": {"example_a": "example_dart"}},
            waves=[single_spawn("example_late", start_tick=2)],
        )

        result = simulate(catalog, scenario, "example_baseline")

        self.assertEqual((result.kills, result.leaks, result.ticks_elapsed), (1, 0, 3))
