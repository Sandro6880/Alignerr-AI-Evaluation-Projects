"""Read and validate the version 1 catalog and scenario formats."""

from dataclasses import dataclass
import json
from pathlib import Path


Point = tuple[int, int]
SCHEMA_VERSION = 1
MAX_ENEMIES = 10_000
MAX_TICKS = 100_000


class DataError(ValueError):
    """An invalid catalog or scenario."""


@dataclass(frozen=True)
class Tower:
    name: str
    cost: int
    damage: int
    range: int
    cooldown_ticks: int


@dataclass(frozen=True)
class Enemy:
    name: str
    health: int
    speed: int


@dataclass(frozen=True)
class Catalog:
    towers: dict[str, Tower]
    enemies: dict[str, Enemy]


@dataclass(frozen=True)
class SpawnGroup:
    enemy: str
    start_tick: int
    count: int
    interval_ticks: int


@dataclass(frozen=True)
class Wave:
    id: str
    spawns: tuple[SpawnGroup, ...]


@dataclass(frozen=True)
class Scenario:
    id: str
    name: str
    description: str
    tags: tuple[str, ...]
    route: tuple[Point, ...]
    slots: dict[str, Point]
    loadouts: dict[str, dict[str, str]]
    waves: tuple[Wave, ...]


def _unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result = {}
    for key, value in pairs:
        if key in result:
            raise DataError(f"Duplicate JSON key {key!r}")
        result[key] = value
    return result


def _read_json(path: str | Path) -> object:
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=_unique_object)


def _object(value: object, label: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise DataError(f"{label} must be an object")
    for key in value:
        _text(key, f"{label} key")
    return value


def _fields(value: object, label: str, *required: str) -> dict[str, object]:
    original = _object(value, label)
    fields = {key.removeprefix("example_"): field for key, field in original.items()}
    if len(fields) != len(original):
        raise DataError(f"{label} repeats a field with and without the example_ prefix")
    missing = set(required) - fields.keys()
    if missing:
        raise DataError(f"{label} is missing {', '.join(sorted(missing))}")
    extra = fields.keys() - set(required)
    if extra:
        raise DataError(f"{label} has unknown fields: {', '.join(sorted(extra))}")
    return fields


def _array(value: object, label: str, minimum: int = 0) -> list[object]:
    if not isinstance(value, list) or len(value) < minimum:
        raise DataError(f"{label} must be an array with at least {minimum} entries")
    return value


def _text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise DataError(f"{label} must be a nonempty string")
    return value


def _integer(value: object, label: str, minimum: int | None = None) -> int:
    if type(value) is not int:
        raise DataError(f"{label} must be an integer")
    if minimum is not None and value < minimum:
        raise DataError(f"{label} must be at least {minimum}")
    return value


def _point(value: object, label: str) -> Point:
    coords = _array(value, label)
    if len(coords) != 2:
        raise DataError(f"{label} must have exactly two coordinates")
    return _integer(coords[0], f"{label} x"), _integer(coords[1], f"{label} y")


def _version(document: dict[str, object]) -> None:
    if _integer(document["schema_version"], "schema_version") != SCHEMA_VERSION:
        raise DataError(f"schema_version must be {SCHEMA_VERSION}")


def parse_catalog(document: object) -> Catalog:
    """Validate a decoded catalog."""
    data = _fields(document, "catalog", "schema_version", "towers", "enemies")
    _version(data)
    towers = {}
    for tower_id, value in _object(data["towers"], "towers").items():
        label = f"towers.{tower_id}"
        tower = _fields(value, label, "name", "cost", "damage", "range", "cooldown_ticks")
        towers[tower_id] = Tower(
            name=_text(tower["name"], f"{label}.name"),
            cost=_integer(tower["cost"], f"{label}.cost", 1),
            damage=_integer(tower["damage"], f"{label}.damage", 1),
            range=_integer(tower["range"], f"{label}.range", 1),
            cooldown_ticks=_integer(tower["cooldown_ticks"], f"{label}.cooldown_ticks", 1),
        )
    enemies = {}
    for enemy_id, value in _object(data["enemies"], "enemies").items():
        label = f"enemies.{enemy_id}"
        enemy = _fields(value, label, "name", "health", "speed")
        enemies[enemy_id] = Enemy(
            name=_text(enemy["name"], f"{label}.name"),
            health=_integer(enemy["health"], f"{label}.health", 1),
            speed=_integer(enemy["speed"], f"{label}.speed", 1),
        )
    if not towers or not enemies:
        raise DataError("catalog must define at least one tower and one enemy")
    return Catalog(towers, enemies)


def _route(value: object) -> tuple[tuple[Point, ...], int]:
    points = tuple(
        _point(point, f"route[{index}]")
        for index, point in enumerate(_array(value, "route", 2))
    )
    length = 0
    for index, (start, end) in enumerate(zip(points, points[1:])):
        dx = abs(start[0] - end[0])
        dy = abs(start[1] - end[1])
        if (dx == 0) == (dy == 0):
            raise DataError(f"route segment {index + 1} must be nonzero and axis-aligned")
        length += dx + dy
    return points, length


def _loadouts(
    value: object, slots: dict[str, Point], catalog: Catalog
) -> dict[str, dict[str, str]]:
    loadouts = {}
    for loadout_id, placements in _object(value, "loadouts").items():
        label = f"loadouts.{loadout_id}"
        selected = {}
        for slot_id, tower in _object(placements, label).items():
            if slot_id not in slots:
                raise DataError(f"{label} references unknown slot {slot_id!r}")
            tower_id = _text(tower, f"{label}.{slot_id}")
            if tower_id not in catalog.towers:
                raise DataError(f"{label}.{slot_id} references unknown tower {tower_id!r}")
            selected[slot_id] = tower_id
        loadouts[loadout_id] = selected
    if not loadouts:
        raise DataError("loadouts must define at least one loadout")
    return loadouts


def _waves(value: object, route_length: int, catalog: Catalog) -> tuple[Wave, ...]:
    waves = []
    wave_ids = set()
    enemy_count = 0
    for index, value in enumerate(_array(value, "waves", 1)):
        label = f"waves[{index}]"
        wave = _fields(value, label, "id", "spawns")
        wave_id = _text(wave["id"], f"{label}.id")
        if wave_id in wave_ids:
            raise DataError(f"{label} repeats wave ID {wave_id!r}")
        wave_ids.add(wave_id)
        groups = []
        for group_index, value in enumerate(_array(wave["spawns"], f"{label}.spawns", 1)):
            group_label = f"{label}.spawns[{group_index}]"
            group = _fields(value, group_label, "enemy", "start_tick", "count", "interval_ticks")
            enemy_id = _text(group["enemy"], f"{group_label}.enemy")
            if enemy_id not in catalog.enemies:
                raise DataError(f"{group_label} references unknown enemy {enemy_id!r}")
            start = _integer(group["start_tick"], f"{group_label}.start_tick", 0)
            count = _integer(group["count"], f"{group_label}.count", 1)
            interval = _integer(group["interval_ticks"], f"{group_label}.interval_ticks", 0)
            enemy_count += count
            if enemy_count > MAX_ENEMIES:
                raise DataError(f"scenario exceeds the {MAX_ENEMIES:,} enemy limit")
            speed = catalog.enemies[enemy_id].speed
            travel_ticks = (route_length + speed - 1) // speed
            if start + (count - 1) * interval + travel_ticks > MAX_TICKS:
                raise DataError(f"{group_label} could exceed the {MAX_TICKS:,} tick limit")
            groups.append(SpawnGroup(enemy_id, start, count, interval))
        waves.append(Wave(wave_id, tuple(groups)))
    return tuple(waves)


def parse_scenario(document: object, catalog: Catalog) -> Scenario:
    """Validate a decoded scenario against its catalog."""
    data = _fields(
        document, "scenario", "schema_version", "id", "name", "description",
        "tags", "route", "slots", "loadouts", "waves",
    )
    _version(data)
    route, route_length = _route(data["route"])
    slots = {
        slot_id: _point(point, f"slots.{slot_id}")
        for slot_id, point in _object(data["slots"], "slots").items()
    }
    return Scenario(
        id=_text(data["id"], "id"),
        name=_text(data["name"], "name"),
        description=_text(data["description"], "description"),
        tags=tuple(_text(tag, "tags entry") for tag in _array(data["tags"], "tags")),
        route=route,
        slots=slots,
        loadouts=_loadouts(data["loadouts"], slots, catalog),
        waves=_waves(data["waves"], route_length, catalog),
    )


def load_catalog(path: str | Path) -> Catalog:
    try:
        return parse_catalog(_read_json(path))
    except (OSError, ValueError) as exc:
        raise DataError(f"{path}: {exc}") from exc


def load_scenario(path: str | Path, catalog: Catalog) -> Scenario:
    try:
        return parse_scenario(_read_json(path), catalog)
    except (OSError, ValueError) as exc:
        raise DataError(f"{path}: {exc}") from exc
