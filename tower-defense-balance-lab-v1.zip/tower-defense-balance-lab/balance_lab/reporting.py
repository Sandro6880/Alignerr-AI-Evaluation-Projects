"""Readable summaries and signed differences for simulation results."""

from .simulation import SimulationResult


METRIC_LABELS = {
    "ticks_elapsed": "Elapsed ticks",
    "spawned": "Enemies",
    "kills": "Kills",
    "leaks": "Leaks",
    "cost": "Total cost",
    "damage": "Damage",
}



def example_keys(value):
    """Prefix public JSON fields while preserving already-prefixed record IDs."""
    if isinstance(value, dict):
        return {
            key if key.startswith("example_") else f"example_{key}": example_keys(field)
            for key, field in value.items()
        }
    if isinstance(value, list):
        return [example_keys(item) for item in value]
    return value


def compare_results(left: SimulationResult, right: SimulationResult) -> dict[str, int]:
    return {field: getattr(right, field) - getattr(left, field) for field in METRIC_LABELS}


def format_result(result: SimulationResult, scenario_name: str) -> str:
    lines = [f"{scenario_name} ({result.scenario_id}) / {result.loadout_id}"]
    for field, label in METRIC_LABELS.items():
        lines.append(f"  {label:<13} {getattr(result, field)}")

    lines.append("Waves")
    for wave_id, wave in result.waves.items():
        lines.append(f"  {wave_id} — {wave.spawned} enemies, {wave.kills} kills, {wave.leaks} leaks")

    lines.append("Towers")
    for slot_id, tower in result.towers.items():
        lines.append(
            f"  {slot_id} ({tower.tower_id}) — cost {tower.cost}, {tower.shots} shots, "
            f"{tower.damage} damage, {tower.kills} kills"
        )
    if not result.towers:
        lines.append("  Empty loadout")
    return "\n".join(lines)


def format_comparison(
    left: SimulationResult,
    right: SimulationResult,
    delta: dict[str, int],
    scenario_name: str,
) -> str:
    lines = [
        format_result(left, scenario_name),
        "",
        format_result(right, scenario_name),
        "",
        f"Change ({right.loadout_id} minus {left.loadout_id})",
    ]
    for field, label in METRIC_LABELS.items():
        lines.append(f"  {label:<13} {delta[field]:+d}")
    return "\n".join(lines)
