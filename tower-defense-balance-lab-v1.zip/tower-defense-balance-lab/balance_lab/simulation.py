"""Run fixed-route combat independently of file loading and reporting."""

from bisect import bisect_right
from dataclasses import dataclass
from itertools import accumulate

from .schema import Catalog, DataError, Point, Scenario, Tower


@dataclass
class WaveResult:
    spawned: int = 0
    kills: int = 0
    leaks: int = 0


@dataclass
class TowerResult:
    tower_id: str
    cost: int
    shots: int = 0
    damage: int = 0
    kills: int = 0


@dataclass(frozen=True)
class SimulationResult:
    scenario_id: str
    loadout_id: str
    ticks_elapsed: int
    spawned: int
    kills: int
    leaks: int
    cost: int
    damage: int
    waves: dict[str, WaveResult]
    towers: dict[str, TowerResult]


class _Route:
    def __init__(self, points: tuple[Point, ...]) -> None:
        self.points = points
        self.distances = [0, *accumulate(
            abs(end[0] - start[0]) + abs(end[1] - start[1])
            for start, end in zip(points, points[1:])
        )]
        self.length = self.distances[-1]

    def position_at(self, progress: int) -> Point:
        segment = bisect_right(self.distances, progress) - 1
        start_x, start_y = self.points[segment]
        end_x, end_y = self.points[segment + 1]
        offset = progress - self.distances[segment]
        if start_x == end_x:
            return start_x, start_y + offset if end_y > start_y else start_y - offset
        return start_x + offset if end_x > start_x else start_x - offset, start_y


@dataclass
class _EnemyState:
    wave_id: str
    health: int
    speed: int
    position: Point
    progress: int = 0


@dataclass
class _TowerState:
    profile: Tower
    position: Point
    result: TowerResult
    ready_tick: int = 0

    def can_hit(self, enemy: _EnemyState) -> bool:
        dx = self.position[0] - enemy.position[0]
        dy = self.position[1] - enemy.position[1]
        return enemy.health > 0 and dx * dx + dy * dy <= self.profile.range ** 2

    def fire(
        self, tick: int, enemies: list[_EnemyState], waves: dict[str, WaveResult]
    ) -> None:
        if tick < self.ready_tick:
            return
        # max selects the first match when progress ties. Active enemies
        # are kept in spawn order throughout the run.
        target = max(
            (enemy for enemy in enemies if self.can_hit(enemy)),
            key=lambda enemy: enemy.progress,
            default=None,
        )
        if target is None:
            return
        damage = min(target.health, self.profile.damage)
        target.health -= damage
        self.result.damage += damage
        self.result.shots += 1
        self.ready_tick = tick + self.profile.cooldown_ticks
        if target.health == 0:
            self.result.kills += 1
            waves[target.wave_id].kills += 1


def _spawn_schedule(scenario: Scenario) -> list[tuple[int, str, str]]:
    schedule = [
        (group.start_tick + index * group.interval_ticks, wave.id, group.enemy)
        for wave in scenario.waves
        for group in wave.spawns
        for index in range(group.count)
    ]
    schedule.sort(key=lambda spawn: spawn[0])
    return schedule


def simulate(catalog: Catalog, scenario: Scenario, loadout_id: str) -> SimulationResult:
    """Simulate one loadout with integer ticks and stable targeting rules."""
    if loadout_id not in scenario.loadouts:
        available = ", ".join(sorted(scenario.loadouts))
        raise DataError(f"unknown loadout {loadout_id!r}. Available loadouts: {available}")

    route = _Route(scenario.route)
    towers = {
        slot_id: _TowerState(
            catalog.towers[tower_id],
            scenario.slots[slot_id],
            TowerResult(tower_id, catalog.towers[tower_id].cost),
        )
        for slot_id, tower_id in sorted(scenario.loadouts[loadout_id].items())
    }
    waves = {wave.id: WaveResult() for wave in scenario.waves}
    schedule = _spawn_schedule(scenario)
    active: list[_EnemyState] = []
    spawn_index = 0
    tick = 0

    while active or spawn_index < len(schedule):
        if not active:
            tick = schedule[spawn_index][0]
        while spawn_index < len(schedule) and schedule[spawn_index][0] == tick:
            _, wave_id, enemy_id = schedule[spawn_index]
            enemy = catalog.enemies[enemy_id]
            active.append(_EnemyState(wave_id, enemy.health, enemy.speed, route.points[0]))
            waves[wave_id].spawned += 1
            spawn_index += 1

        for tower in towers.values():
            tower.fire(tick, active, waves)

        survivors = []
        for enemy in active:
            if enemy.health == 0:
                continue
            enemy.progress += enemy.speed
            if enemy.progress >= route.length:
                waves[enemy.wave_id].leaks += 1
            else:
                enemy.position = route.position_at(enemy.progress)
                survivors.append(enemy)
        active = survivors
        tick += 1

    return SimulationResult(
        scenario_id=scenario.id,
        loadout_id=loadout_id,
        ticks_elapsed=tick,
        spawned=sum(wave.spawned for wave in waves.values()),
        kills=sum(wave.kills for wave in waves.values()),
        leaks=sum(wave.leaks for wave in waves.values()),
        cost=sum(tower.result.cost for tower in towers.values()),
        damage=sum(tower.result.damage for tower in towers.values()),
        waves=waves,
        towers={slot_id: tower.result for slot_id, tower in towers.items()},
    )
