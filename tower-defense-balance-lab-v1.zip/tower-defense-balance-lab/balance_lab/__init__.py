"""A deterministic tower-defense simulator for balance experiments."""
