"""Command line entry point for running and comparing battle scenarios."""

import argparse
from collections.abc import Sequence
from dataclasses import asdict
import json
from pathlib import Path
import sys

from .reporting import compare_results, example_keys, format_comparison, format_result
from .schema import DataError, Scenario, load_catalog, load_scenario
from .simulation import simulate


DATA_DIRECTORY = Path(__file__).resolve().parent.parent / "data"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m balance_lab",
        description="Run deterministic tower-defense simulations from JSON scenarios.",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    catalog_options = argparse.ArgumentParser(add_help=False)
    catalog_options.add_argument(
        "--catalog",
        type=Path,
        default=DATA_DIRECTORY / "example_catalog.json",
        metavar="PATH",
        help="Tower and enemy catalog (defaults to the bundled catalog).",
    )

    run = commands.add_parser("simulate", parents=[catalog_options], help="Run one loadout.")
    run.add_argument("--loadout", metavar="ID", help="Loadout ID (defaults to baseline if present).")

    compare = commands.add_parser("compare", parents=[catalog_options], help="Compare two loadouts.")
    for command in (run, compare):
        command.add_argument("scenario", type=Path, metavar="SCENARIO", help="Scenario JSON file.")
        command.add_argument("--json", action="store_true", help="Print the result as JSON.")
    compare.add_argument("left", metavar="LEFT", help="Reference loadout ID.")
    compare.add_argument("right", metavar="RIGHT", help="Candidate loadout ID.")

    validate = commands.add_parser("validate", parents=[catalog_options], help="Validate scenario files.")
    validate.add_argument(
        "paths",
        type=Path,
        metavar="PATH",
        nargs="*",
        help="Scenario JSON files (defaults to all bundled scenarios and variants).",
    )

    dashboard = commands.add_parser("serve", help="Start the local dashboard and mock API.")
    dashboard.add_argument("--host", default="127.0.0.1")
    dashboard.add_argument("--port", default=8000, type=int)
    return parser


def bundled_path(path: Path) -> Path:
    fixture_directories = {DATA_DIRECTORY, DATA_DIRECTORY / "scenarios", DATA_DIRECTORY / "variants"}
    if path.parent.resolve() in fixture_directories and not path.exists():
        candidate = path.with_name(f"example_{path.name}")
        if candidate.is_file():
            return candidate
    return path


def resolve_loadout(scenario: Scenario, name: str) -> str:
    prefixed = f"example_{name}"
    if name not in scenario.loadouts and prefixed in scenario.loadouts:
        return prefixed
    return name


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "serve":
            from .server import serve

            serve(args.host, args.port)
            return 0

        catalog = load_catalog(bundled_path(args.catalog))
        if args.command == "validate":
            paths = args.paths or [
                path
                for directory in ("scenarios", "variants")
                for path in sorted((DATA_DIRECTORY / directory).glob("*.json"))
            ]
            if not paths:
                raise DataError(f"No bundled scenario files found under {DATA_DIRECTORY}.")
            for path in paths:
                load_scenario(bundled_path(path), catalog)
            print(f"Validated {len(paths)} scenario file(s).")
            return 0

        scenario = load_scenario(bundled_path(args.scenario), catalog)
        if args.command == "simulate":
            loadout = args.loadout
            if loadout is None:
                default = resolve_loadout(scenario, "baseline")
                loadout = default if default in scenario.loadouts else min(scenario.loadouts)
            result = simulate(catalog, scenario, resolve_loadout(scenario, loadout))
            payload = asdict(result) if args.json else format_result(result, scenario.name)
        else:
            left = simulate(catalog, scenario, resolve_loadout(scenario, args.left))
            right = simulate(catalog, scenario, resolve_loadout(scenario, args.right))
            delta = compare_results(left, right)
            payload = (
                {"left": asdict(left), "right": asdict(right), "delta": delta}
                if args.json
                else format_comparison(left, right, delta, scenario.name)
            )
        print(json.dumps(example_keys(payload), indent=2, sort_keys=True) if args.json else payload)
        return 0
    except (OSError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
