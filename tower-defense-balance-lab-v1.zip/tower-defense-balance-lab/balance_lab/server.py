"""Local dashboard and read-only mock API for balance experiments."""

from dataclasses import asdict
from functools import partial
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from urllib.parse import unquote, urlsplit

from .reporting import compare_results, example_keys
from .schema import DataError, Scenario, parse_catalog, parse_scenario
from .simulation import SimulationResult, simulate


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = PROJECT_ROOT / "data"
WEB_ROOT = PROJECT_ROOT / "web"
MAX_BODY_BYTES = 32 * 1024
STATIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
}


class _RequestError(ValueError):
    def __init__(self, status: HTTPStatus, message: str) -> None:
        super().__init__(message)
        self.status = status


class _DemoData:
    def __init__(self) -> None:
        self.catalog_document = json.loads(
            (DATA_ROOT / "example_catalog.json").read_text(encoding="utf-8")
        )
        self.catalog = parse_catalog(self.catalog_document)
        self.scenarios: dict[str, tuple[dict, Scenario]] = {}
        self.index = []

        for folder in ("scenarios", "variants"):
            for path in sorted((DATA_ROOT / folder).glob("example_*.json")):
                document = json.loads(path.read_text(encoding="utf-8"))
                scenario = parse_scenario(document, self.catalog)
                if scenario.id in self.scenarios:
                    raise DataError(f"Duplicate scenario ID {scenario.id!r}.")
                self.scenarios[scenario.id] = (document, scenario)
                self.index.append({
                    "example_id": scenario.id,
                    "example_name": scenario.name,
                    "example_description": scenario.description,
                    "example_tags": list(scenario.tags),
                    "example_wave_count": len(scenario.waves),
                    "example_slot_count": len(scenario.slots),
                    "example_is_variant": folder == "variants",
                })

    def lookup(self, scenario_id: object) -> tuple[dict, Scenario]:
        if not isinstance(scenario_id, str):
            raise DataError("Choose a scenario ID.")
        if scenario_id not in self.scenarios:
            raise _RequestError(HTTPStatus.NOT_FOUND, f"Unknown scenario {scenario_id!r}.")
        return self.scenarios[scenario_id]

    def run(
        self, document: dict, scenario: Scenario, selector: object,
    ) -> SimulationResult:
        if isinstance(selector, dict):
            if selector.keys() == {"example_loadout_id"}:
                loadout_id = selector["example_loadout_id"]
                if isinstance(loadout_id, str):
                    return simulate(self.catalog, scenario, loadout_id)
                raise DataError("Choose a loadout ID.")

            if selector.keys() == {"example_placements"}:
                loadouts = {
                    **document["example_loadouts"],
                    "example_custom": selector["example_placements"],
                }
                custom = parse_scenario({**document, "example_loadouts": loadouts}, self.catalog)
                return simulate(self.catalog, custom, "example_custom")

        raise DataError("Choose either example_loadout_id or example_placements.")


class _Handler(BaseHTTPRequestHandler):
    timeout = 10

    def __init__(self, *args, data: _DemoData, **kwargs) -> None:
        self.data = data
        super().__init__(*args, **kwargs)

    def _send(self, status: HTTPStatus, content_type: str, content: bytes) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(content)

    def _json(self, content: object, status: HTTPStatus = HTTPStatus.OK) -> None:
        self._send(status, "application/json; charset=utf-8", json.dumps(content).encode("utf-8"))

    def _error(self, error: ValueError) -> None:
        status = error.status if isinstance(error, _RequestError) else HTTPStatus.BAD_REQUEST
        self._json({"example_error": str(error)}, status)

    def _body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", ""))
        except ValueError as error:
            raise DataError("Send a JSON request with a content length.") from error
        if length < 1:
            raise DataError("Send a nonempty JSON request body.")
        if length > MAX_BODY_BYTES:
            raise _RequestError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "The request is too large.")
        try:
            value = json.loads(self.rfile.read(length))
        except (UnicodeDecodeError, ValueError, RecursionError) as error:
            raise DataError("Send a valid JSON request body.") from error
        if not isinstance(value, dict):
            raise DataError("Send a JSON object.")
        return value

    def do_GET(self) -> None:
        try:
            path = unquote(urlsplit(self.path).path)
            if path in STATIC_FILES:
                name, content_type = STATIC_FILES[path]
                try:
                    content = (WEB_ROOT / name).read_bytes()
                except FileNotFoundError as error:
                    raise _RequestError(HTTPStatus.NOT_FOUND, "The dashboard asset is missing.") from error
                self._send(HTTPStatus.OK, content_type, content)
            elif path == "/api/example_catalog":
                self._json(self.data.catalog_document)
            elif path == "/api/example_scenarios":
                self._json(self.data.index)
            elif path.startswith("/api/example_scenarios/"):
                document, _ = self.data.lookup(path.removeprefix("/api/example_scenarios/"))
                self._json(document)
            else:
                raise _RequestError(HTTPStatus.NOT_FOUND, "The requested route does not exist.")
        except ValueError as error:
            self._error(error)

    def do_POST(self) -> None:
        try:
            path = urlsplit(self.path).path
            if path not in ("/api/example_simulate", "/api/example_compare"):
                raise _RequestError(HTTPStatus.NOT_FOUND, "The requested route does not exist.")
            body = self._body()
            document, scenario = self.data.lookup(body.pop("example_scenario_id", None))
            if path == "/api/example_simulate":
                result = self.data.run(document, scenario, body)
                self._json(example_keys(asdict(result)))
            else:
                if body.keys() != {"example_left", "example_right"}:
                    raise DataError("Send example_left and example_right loadouts.")
                left = self.data.run(document, scenario, body["example_left"])
                right = self.data.run(document, scenario, body["example_right"])
                self._json(example_keys({
                    "left": asdict(left),
                    "right": asdict(right),
                    "delta": compare_results(left, right),
                }))
        except ValueError as error:
            self._error(error)


def create_server(host: str = "127.0.0.1", port: int = 8000) -> ThreadingHTTPServer:
    """Build a server whose requests share a read-only fixture catalog."""
    return ThreadingHTTPServer((host, port), partial(_Handler, data=_DemoData()))


def serve(host: str = "127.0.0.1", port: int = 8000) -> None:
    with create_server(host, port) as server:
        print(f"Tower Defense Balance Lab at http://{host}:{server.server_port}/", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
