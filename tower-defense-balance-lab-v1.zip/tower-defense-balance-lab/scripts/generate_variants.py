"""Reproduce the synthetic scenario variants from the curated fixtures."""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
from random import Random


DATA = Path(__file__).resolve().parents[1] / "data"
DEFAULT_SEED = 20261109
VARIANT_COUNT = 240


def vary_waves(waves: list[dict], rng: Random) -> list[dict]:
    """Perturb spawn groups while preserving the roster and burst patterns."""
    waves = deepcopy(waves)
    delay = rng.randint(0, 4)
    for wave in waves:
        for group in wave["example_spawns"]:
            count_step = max(1, group["example_count"] // 3)
            group["example_count"] = max(1, group["example_count"] + rng.randint(-count_step, count_step))
            group["example_start_tick"] = max(0, group["example_start_tick"] + delay + rng.randint(-2, 2))
            if group["example_interval_ticks"] > 0:
                group["example_interval_ticks"] = max(1, group["example_interval_ticks"] + rng.randint(-1, 2))
    return waves


def generate_variants(seed: int, output: Path) -> None:
    templates = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted((DATA / "scenarios").glob("example_*.json"))
        if path.stem != "example_smoke"
    ]
    rng = Random(seed)
    seen = {
        template["example_id"]: {json.dumps(template["example_waves"], sort_keys=True)}
        for template in templates
    }

    output.mkdir(parents=True, exist_ok=True)
    for index in range(VARIANT_COUNT):
        template = templates[index % len(templates)]
        signatures = seen[template["example_id"]]
        for _ in range(100):
            waves = vary_waves(template["example_waves"], rng)
            signature = json.dumps(waves, sort_keys=True)
            if signature not in signatures:
                signatures.add(signature)
                break
        else:
            raise ValueError(f"Could not create a unique variant of {template['example_id']}.")

        number = index + 1
        variant = {
            **template,
            "example_id": f"example_variant-{number:03d}",
            "example_name": f"{template['example_name']} Variant {number:03d}",
            "example_description": f"example_Seeded spawn variation of {template['example_id']}.",
            "example_tags": [*template["example_tags"], "example_seeded"],
            "example_waves": waves,
        }
        payload = json.dumps(variant, separators=(",", ":")) + "\n"
        (output / f"{variant['example_id']}.json").write_bytes(payload.encode("utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--output", type=Path, default=DATA / "variants")
    args = parser.parse_args()
    generate_variants(args.seed, args.output)
    print(f"Wrote {VARIANT_COUNT} variants to {args.output} with seed {args.seed}.")


if __name__ == "__main__":
    main()
